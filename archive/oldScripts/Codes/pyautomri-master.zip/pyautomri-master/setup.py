import pathlib
here = pathlib.Path(__file__).parent.resolve()

# Get the long description from the README file
long_description = (here / 'README.md').read_text(encoding='utf-8')

# https://github.com/pypa/sampleproject/blob/main/setup.py
from setuptools import setup
setup(
    name='pyautomri',
    version='0.1.0',
    author='Quentin Duche',
    author_email='quentin.duche@inria.fr',
    packages=['pyautomri'],
    scripts=[
        'bin/flip_nifti_volume.py',
        'bin/plot_stat_map.py'
    ],
    url='https://github.com/Inria-Visages/pyautomri/',
    license='LICENSE.txt',
    description='pyautomri allows to perform second level analyses and automated pdf reporting after pre-processing '
                'and first level analyses performed with automri.',
    long_description=long_description,
    keywords='fmri, processing',  # Optional
)