import nilearn
import sys
import matplotlib.pyplot as plt
import numpy as np
import nibabel as nib
from nilearn.plotting import plot_epi
from nilearn.maskers import input_data

CMAP_GRAY = plt.cm.gray
CMAP_SPECTRAL = plt.cm.nipy_spectral
SINGLE_MARKER_COL = 'r'


class TimeseriesPlot:
    def __init__(self, epi_file, out_file):
        self.epi_file = epi_file
        self.out_file = out_file
        # Default parameters
        self.detrend = False
        self.standardize = False
        self.low_pass = None  # low-pass
        self.high_pass = None  # high-pass
        self.tr = None  # repetition time
        #
        self.timeseries = None
        # Options for selecting roi
        self.sphere_centers = None
        self.radius = None
        self.mask = None
        self.roi_atlas = None
        #
        self.epi_cmap = CMAP_SPECTRAL  # epi colormap

    def set_spheres(self, sphere_centers, radius):
        self.sphere_centers = sphere_centers
        self.radius = radius

    def set_tr(self, tr):
        self.tr = tr

    def set_detrend(self, detrend):
        self.detrend = detrend

    def set_standardize(self, standardize):
        self.standardize = standardize

    def get_mask_mean_timeseries(self, mask):
        """Extract spatially averaged timeseries for a single mask"""
        masker = input_data.NiftiMasker(mask_img=mask, detrend=self.detrend, standardize=self.standardize,
                                        low_pass=self.low_pass, high_pass=self.high_pass, t_r=self.tr,
                                        memory_level=0)
        return np.mean(masker.fit_transform(self.epi_file), axis=1)

    def extract_timeseries(self):
        """
        Extract the timeseries for the provided options.
        If spheres were set use NiftiSpheresMasker, if
        :return:
        """
        if self.sphere_centers and self.radius:
            masker = input_data.NiftiSpheresMasker(self.sphere_centers, radius=self.radius, detrend=self.detrend,
                                                   standardize=self.standardize, low_pass=self.low_pass,
                                                   high_pass=self.high_pass, t_r=self.tr, memory_level=0)
            self.timeseries = masker.fit_transform(self.epi_file)
        elif self.mask:
            # todo maybe add an option to choose whether you average or not
            self.timeseries = self.get_mask_mean_timeseries(mask=self.mask)
        elif self.roi_atlas:
            epi_data = nib.load(self.epi_file)
            nvols = epi_data.shape[3]
            self.timeseries = np.zeros(shape=(nvols, self.roi_atlas.get_number_of_rois()))
            for r, roi in enumerate(self.roi_atlas.get_list_rois()):
                self.timeseries[:, r] = self.get_mask_mean_timeseries(mask=roi.get_file())

    def set_mask(self, mask_file):
        self.mask = mask_file

    def set_roi_atlas(self, roi_atlas):
        self.roi_atlas = roi_atlas

    def plot_anat_and_timeseries(self):
        pass

    def set_gray_epi_colormap(self):
        self.epi_cmap = CMAP_GRAY

    def plot_epi_and_timeseries(self, title=None, display_mode='ortho'):
        self.extract_timeseries()

        if display_mode == 'ortho':
            fig, axs = plt.subplots(nrows=2, ncols=1)
        elif display_mode in ['x', 'y', 'z']:
            fig, axs = plt.subplots(nrows=1, ncols=2)
        else:
            sys.exit('Unknown display mode {} for EPI and timeseries plot'.format(display_mode))

        if title:
            fig.suptitle(title)

        # Load fmri data
        mean_epi = nilearn.image.mean_img(self.epi_file)

        # Define cut coordinates
        if self.sphere_centers:
            if display_mode == 'ortho':
                cut_coords = (self.sphere_centers[0][0], self.sphere_centers[0][1], self.sphere_centers[0][2])
            elif display_mode == 'x':
                cut_coords = [self.sphere_centers[0][0]]
            elif display_mode == 'y':
                cut_coords = [self.sphere_centers[0][1]]
            elif display_mode == 'z':
                cut_coords = [self.sphere_centers[0][2]]
            else:
                cut_coords = None
        elif self.mask:
            print('Implement the ROIplot')
            cut_coords = None
            pass
        elif self.roi_atlas:
            # self.roi_atlas.plot(out_file, bg_img=MNI152TEMPLATE, alpha=1, dim=None, title=None, display_mode='ortho',
            #     cut_coords=None)
            print('Implement the ROIAtlasplot')
            cut_coords = None
        else:
            cut_coords = None

        # Perform the plotting
        d = plot_epi(epi_img=mean_epi, black_bg=True, cut_coords=cut_coords, draw_cross=False, axes=axs[0],
                     cmap=self.epi_cmap, display_mode=display_mode)
        if self.roi_atlas:
            self.roi_atlas.add_overlay_list_rois_to_display(display=d, alpha=0.8)

        # Adds markers
        if self.sphere_centers:
            for sphere_center in self.sphere_centers:
                d.add_markers([sphere_center], marker_color=SINGLE_MARKER_COL, marker_size=50)

        if self.sphere_centers or self.mask:
            axs[1].plot(self.timeseries)
        elif self.roi_atlas:
            for r in range(self.timeseries.shape[1]):
                axs[1].plot(self.timeseries[:, r], color=self.roi_atlas.get_roi(r).get_color())
            rois = [self.roi_atlas.get_roi(r).get_name() for r in range(self.roi_atlas.get_number_of_rois())]
            plt.legend(rois)

    def plot_timeseries_only(self):
        pass

    def save(self):
        plt.savefig(fname=self.out_file, dpi=300)
        plt.close()
