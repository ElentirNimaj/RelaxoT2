from os.path import exists as ope, join as opj
import os, numpy as np, sys

import PIL.Image
from PIL import Image, ImageFont, ImageDraw
from pathlib import Path

OPEN_SANS_BOLD_TTF = opj(Path(__file__).parent.parent.parent, 'resources', 'OpenSans-Bold.ttf')


class Montage1D:
    """
    Implements Montage of images
    """

    def __init__(self, list_images, output_file, delete_inputs=True):
        self.font_size = 30
        self.list_images = [img for img in list_images if ope(img)]
        self.n = len(self.list_images)
        self.output_file = output_file
        self.delete_inputs = delete_inputs
        self.title = None
        self.bg_color = (0, 0, 0)

    def set_delete_inputs(self, delete_inputs):
        """

        :param delete_inputs:
        :return:
        """
        self.delete_inputs = delete_inputs

    def set_background_color(self, color):
        self.bg_color = color

    def set_title(self, title, font_size=30):
        """

        :param title:
        :param font_size:
        :return:
        """
        self.set_fontsize(font_size=font_size)
        self.title = title

    def set_fontsize(self, font_size):
        """

        :param font_size:
        :return:
        """
        self.font_size = font_size

    def vertical_montage(self):
        """
        Concatenates input images vertically
        """
        Montage(list_images=self.list_images, output_file=self.output_file, n_rows=self.n, n_cols=1,
                bg_color=self.bg_color, delete_inputs=self.delete_inputs)
        if self.title:
            addHeaderToImage(text=self.title, image_file=self.output_file, fontsize=self.font_size)

    def get_widths_and_heights_images(self):
        """
        Retrieves widths and heights informations
        :return:
        """
        self.widths = np.empty((self.n), dtype=int)
        self.heights = np.empty((self.n), dtype=int)
        for i, image in enumerate(self.list_images):
            im = Image.open(image)
            (self.widths[i], self.heights[i]) = im.size

    def load_PIL_images(self):
        """
        Open the list of image inputs and stores them into a list of PIL images
        :return:
        """
        self.list_PIL_images = []
        for i, image in enumerate(self.list_images):
            self.list_PIL_images.append(Image.open(image))

    def vertical_montage_adjust_to_min_width(self):
        """
        Takes the list of images with different widths.
        Resize every image to min width of the list of images
        stack vertically
        """
        self.get_widths_and_heights_images()
        self.load_PIL_images()

        # get minimum size and adjust size of every image
        min_w = np.min(self.widths)
        new_heights = np.empty((self.n), dtype=int)
        for i in range(self.n):
            pc_w = min_w / float(self.widths[i])
            new_heights[i] = int(pc_w * self.heights[i])

        # Create the montage by pasting every resized image
        montage_size = (min_w, np.sum(new_heights))
        montage_img = Image.new('RGB', montage_size, color=self.bg_color)
        for i in range(self.n):
            im = self.list_PIL_images[i]
            img = im.resize((min_w, new_heights[i]), Image.ANTIALIAS)
            montage_img.paste(img, (0, np.sum(new_heights[:i])))

        # Save it to output file
        montage_img.save(self.output_file)

        if self.title:
            addHeaderToImage(text=self.title, image_file=self.output_file, fontsize=self.font_size)

        # If delete inputs then:
        if self.delete_inputs:
            for f in self.list_images:
                if ope(f):
                    os.remove(f)

    def vertical_montage_with_vertical_proportions(self, v_proportions):
        """
        Possibility to stack images vertically and assign a vertical proportion to each image in the list.
        Proportions must sum to one.
        :param v_proportions: list, elements must sum to 1.
        :return:
        """
        if len(v_proportions) != len(self.list_images):
            sys.exit('Vertical montage with vertical proportions can must have same number of proportions (here {0}) '
                     'than number of images ({1})'.format(len(v_proportions), len(self.list_images)))
        v_proportions = np.asarray(v_proportions)
        if not np.sum(v_proportions) == 1:
            sys.exit('Vertical proportions must sum to 1.')

        self.get_widths_and_heights_images()
        self.load_PIL_images()

        # Apply vertical proportions to widths and heights
        new_heights = np.sum(self.heights) * v_proportions
        new_widths = self.widths
        # Check if new heights are larger than previous heights
        if any(new_heights > self.heights):
            # Get index of maximum new heights and
            i = np.argmax(new_heights)
            p = self.heights[i]/new_heights[i]
            # ... and adjust in that case
            new_heights = new_heights * p
            # New width proportions
            width_proportions = new_heights/self.heights
            new_widths = new_widths * width_proportions
        # Convert heights and withs to int
        new_heights = new_heights.astype(int)
        new_widths = new_widths.astype(int)

        montage_size = (np.max(new_widths), np.sum(new_heights))
        montage_img = Image.new('RGB', montage_size, color=self.bg_color)
        for i in range(self.n):
            img = self.list_PIL_images[i].resize((new_widths[i], new_heights[i]), Image.ANTIALIAS)
            # Center on x
            x = int((np.max(new_widths) - new_widths[i])/2)
            montage_img.paste(img, (x, np.sum(new_heights[:i])))

        # Save it to output file
        montage_img.save(self.output_file)

        if self.title:
            addHeaderToImage(text=self.title, image_file=self.output_file, fontsize=self.font_size)

        # If delete inputs then:
        if self.delete_inputs:
            for f in self.list_images:
                if ope(f):
                    os.remove(f)


    def horizontal_montage(self):
        """
        Concatenates input images horizontally
        """
        Montage(list_images=self.list_images, output_file=self.output_file, n_rows=1, n_cols=self.n,
                delete_inputs=self.delete_inputs)
        if self.title:
            addHeaderToImage(text=self.title, image_file=self.output_file, fontsize=self.font_size)


def addHeaderToImage(text, image_file, fontsize=30):
    """
    Adds a title to an image by creating a black band above image
    :param text: text that must be typed at the top of the image file
    :param image_file:
    :return:
    """
    # Define font and measure the size of the text that will be typed
    font = ImageFont.truetype(OPEN_SANS_BOLD_TTF, fontsize)

    # Count lines
    n_lines = len(text.split('\n'))
    txt_height = n_lines * font.getsize(text)[1]

    # Input image file, open it and get width, height
    img = Image.open(image_file)
    img_w, img_h = img.size

    # Define header image that will contain the typed text only
    header_image = Image.new('RGB', (img_w, txt_height), color=(0, 0, 0))
    draw = ImageDraw.Draw(header_image)
    # Calculate size of the header for centering later
    w, h = draw.textsize(text, font=font)
    draw.text(((img_w - w) / 2, 0), text, (255, 255, 255), font=font)

    # Total image, new image, paste input image and header image
    total = Image.new('RGB', (img_w, img_h + txt_height), color=(0, 0, 0))
    total.paste(header_image)  # Past the title image at the beginning
    total.paste(img, box=(0, h))  # Paste the image just at the bottom of the title
    total.save(image_file)  # Save total image


class PILMontage:
    """

    """

    def __init__(self, list_images, output_file, n_rows, n_cols, valign='center', bg_color=(0, 0, 0), delete_inputs=False):
        if n_rows * n_cols < len(list_images):
            sys.exit('Not enough rows and columns to make a montage of {0} images'.format(len(list_images)))
        self.list_image_files = list_images
        self.out_file = output_file
        self.n = len(self.list_image_files)
        self.n_rows = n_rows
        self.n_cols = n_cols
        self.bg_color = bg_color
        self.valign = valign
        self.del_inputs = delete_inputs
        self.get_sizes()
        if self.n_rows == 1:
            self.n_cols = self.n  # should be the same but just making sure
            self.horizontal_montage()
        elif self.n_cols == 1:
            self.n_rows = self.n  # should be the same but just making sure
            self.vertical_montage()
        else:
            self.checkerboard_montage()
            print('Montage (>1) rows x (>1) columns not implemented yet')

    def get_sizes(self):
        sizes = []
        self.list_images = []
        for img_f in self.list_image_files:
            img = PIL.Image.open(img_f, 'r')
            self.list_images.append(img)
            sizes.append(img.size)
        self.sizes = np.asarray(sizes)
        self.widths = self.sizes[:, 0]
        self.heights = self.sizes[:, 1]

    def vertical_montage(self):
        self.w, self.h = np.max(self.widths), np.sum(self.heights)
        self.create_base_image()
        for i, img in enumerate(self.list_images):
            if self.valign == 'center':
                h_shift = int((self.w - self.widths[i])/2)
                self.montage_img.paste(img, box=(h_shift, int(np.sum(list(self.heights[:i])))))
            elif self.valign == 'left':
                self.montage_img.paste(img, box=(0, int(np.sum(list(self.heights[:i])))))
        self.save()

    def horizontal_montage(self):
        self.w, self.h = np.sum(self.widths), np.max(self.heights)
        self.create_base_image()
        for i, img in enumerate(self.list_images):
            self.montage_img.paste(img, box=(int(np.sum(list(self.widths[:i]))), 0))
        self.save()

    def create_base_image(self):
        self.montage_img = Image.new('RGB', (self.w, self.h), color=self.bg_color)

    def checkerboard_montage(self):
        for i in []:
            for j in []:
                pass
        print('PIL Checkerboard Montage not yet implemented')

    def save(self):
        self.montage_img.save(self.out_file, 'PNG')
        if self.del_inputs:
            for img_f in self.list_image_files:
                if ope(img_f):
                    os.remove(img_f)


def Montage(list_images, output_file, n_rows, n_cols, valign='center', bg_color=(0,0,0), delete_inputs=False):
    """
    :param valign:
    :param bg_color:
    :param list_images: list of image paths
    :param output_file: output image file (path)
    :param n_rows: number of rows to the montage
    :param n_cols: number of columns of the montage
    :param delete_inputs: boolean, delete input files after montage is performed
    """
    # montage_imagemagick(list_images, output_file, n_rows, n_cols, delete_inputs)
    PILMontage(list_images, output_file, n_rows, n_cols, valign, bg_color, delete_inputs)


def montage_imagemagick(list_images, output_file, n_rows, n_cols, delete_inputs=False):
    if not ope(output_file):
        options = ' -geometry +0+0 -background black -tile {0}x{1} '.format(n_cols, n_rows)
        cmd = 'montage ' + ' '.join(list_images) + options + output_file
        os.system(cmd)
    if delete_inputs:
        for img in list_images:
            if ope(img):
                os.remove(img)
