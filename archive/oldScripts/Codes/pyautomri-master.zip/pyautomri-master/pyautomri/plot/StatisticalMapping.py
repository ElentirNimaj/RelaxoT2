import sys, time, warnings
import matplotlib.pyplot as plt
import numpy as np

# Filtering these warnings
warnings.filterwarnings("ignore", message="Fetchers from the nilearn.datasets module will be updated in version 0.9"
                                          " to return python strings instead of bytes and Pandas dataframes"
                                          " instead of Numpy arrays.")
warnings.filterwarnings("ignore", message="No contour levels were found within the data range")
from PIL import Image
from matplotlib.colors import ListedColormap
from matplotlib import colorbar, colors
from nilearn.plotting import plot_stat_map, plot_roi, plot_glass_brain
from nilearn.plotting.img_plotting import MNI152TEMPLATE
from os.path import join as opj, exists as ope, dirname as opd, basename as opb
from pyautomri.plot.Montages import Montage1D
from pyautomri.utils.utils import convert_duration_to_nice_duration_string
from pyautomri.roi.Atlas import ROIAtlas

DEFAULT_X_SLICES = [-40, -30, -20, -10, 0, 10, 20, 30, 40]
DEFAULT_Y_SLICES = [-80, -60, -40, -20, 0, 20, 40, 60]
DEFAULT_Z_SLICES = [-20, -10, 0, 10, 20, 30, 40, 50]
DEFAULT_SLICES_DM = {'x': DEFAULT_X_SLICES,
                     'y': DEFAULT_Y_SLICES,
                     'z': DEFAULT_Z_SLICES,
                     'ortho': [0, 0, 0]}

# Default MosaicPlot parameters
MOSAIC_DEFAULT_X = list(range(-60, 61, 15))  # sagittal
MOSAIC_DEFAULT_Y = list(range(-80, 61, 15))  # coronal
MOSAIC_DEFAULT_Z = list(range(-30, 61, 10))  # axial
DEFAULT_MOSAIC_PARAMETERS = {'x': MOSAIC_DEFAULT_X,
                             'y': MOSAIC_DEFAULT_Y,
                             'z': MOSAIC_DEFAULT_Z,
                             'atlas_lw': 2}


class ActivationPlot:
    """
    Class to create a statistical map
    """

    def __init__(self, stat_map, output_file):
        self.stat_map = stat_map
        self.outfile = output_file
        # set default parameters
        self.back_img = MNI152TEMPLATE
        self.display_mode = 'z'
        self.cut_coords = DEFAULT_Z_SLICES
        self.annotate = True
        self.draw_cross = False
        self.black_bg = True
        self.title = ''
        self.colorbar = False
        self.threshold = 0
        self.vmax = None
        self.dim = 'auto'
        self.ax = None

    def set_view_mode(self, display_mode, cut_coords):
        self.set_display_mode(dm=display_mode)
        self.set_cut_coords(cut_coords=cut_coords)

    def set_color_bar(self, colorbar):
        self.colorbar = colorbar

    def set_cut_coords(self, cut_coords):
        self.cut_coords = cut_coords

    def set_display_mode(self, dm):
        vals = ['x', 'y', 'z', 'ortho']
        if not dm in vals:
            sys.exit('ActivationPlot ERROR. Set display mode to one of the following values\n\t-' + '\n\t-'.join(vals))
        if dm == 'ortho':
            self.cut_coords = None
        self.display_mode = dm

    def set_vmax(self, vmax):
        self.vmax = vmax

    def set_black_background(self, black_bg):
        self.black_bg = black_bg

    def set_draw_cross(self, draw_cross):
        self.draw_cross = draw_cross

    def set_annotate(self, annotate):
        self.annotate = annotate

    def set_ax(self, ax):
        self.ax = ax

    def set_background_image(self, bg_img):
        if isinstance(bg_img, str):
            # In this case, the user may pass a normalised T1 file, and let's increase the contrast
            self.dim = -.5
        self.back_img = bg_img

    def set_dim(self, dim):
        self.dim = dim

    def set_title(self, title):
        self.title = title

    def set_threshold(self, threshold):
        self.threshold = threshold

    def plot(self):
        if self.back_img:
            if self.ax is None:
                self.display = plot_stat_map(stat_map_img=self.stat_map, bg_img=self.back_img,
                                            display_mode=self.display_mode,
                                            vmax=self.vmax, cut_coords=self.cut_coords, annotate=self.annotate,
                                            draw_cross=self.draw_cross, black_bg=self.black_bg, threshold=self.threshold,
                                            colorbar=self.colorbar, title=self.title, dim=self.dim)
            else:
                self.display = plot_stat_map(stat_map_img=self.stat_map, bg_img=self.back_img,
                                            display_mode=self.display_mode,
                                            vmax=self.vmax, cut_coords=self.cut_coords, annotate=self.annotate,
                                            draw_cross=self.draw_cross, black_bg=self.black_bg, threshold=self.threshold,
                                            colorbar=self.colorbar, title=self.title, dim=self.dim, ax=self.ax)

        else:
            if self.ax is None :
                self.display = plot_stat_map(stat_map_img=self.stat_map, display_mode=self.display_mode, vmax=self.vmax,
                                         cut_coords=self.cut_coords, annotate=self.annotate, draw_cross=self.draw_cross,
                                         black_bg=self.black_bg, threshold=self.threshold, colorbar=self.colorbar,
                                         title=self.title)
            else:
                self.display = plot_stat_map(stat_map_img=self.stat_map, display_mode=self.display_mode, vmax=self.vmax,
                                         cut_coords=self.cut_coords, annotate=self.annotate, draw_cross=self.draw_cross,
                                         black_bg=self.black_bg, threshold=self.threshold, colorbar=self.colorbar,
                                         title=self.title, ax=self.ax)

    def add_markers(self, coords, marker_color='y', marker_size=100):
        self.display.add_markers(coords, marker_color=marker_color, marker_size=marker_size)

    def add_contours_of_roi_atlas(self, atlas, alpha=1.0, filled=False, lw=2):
        atlas.add_contours_list_rois_to_display(display=self.display, alpha=alpha, filled=filled, lw=lw)

    def add_contours_roi(self, roi, alpha=.6, filled=False, lw=2):
        roi.add_contours_to_display(display=self.display, alpha=alpha, filled=filled, lw=lw)

    def save(self, dpi=None):
        plt.savefig(self.outfile, dpi=dpi)
        plt.close()


class MontageActivationPlots:
    """
    Class to perform a montage of activation plots
    """

    def __init__(self, stat_maps, output_montage_file):
        """
        Initializes the class instance
        :param stat_maps: list of statistical maps (nifti files)
        :param output_montage_file:  output montage filename (image file)
        """
        self.stat_maps = stat_maps
        self.out_file = output_montage_file
        # Define default values below
        self.n = len(self.stat_maps)  # number of statistical maps
        self.out_dir = opd(self.out_file)  # output directory for temporary maps
        self.cut_coords = DEFAULT_Z_SLICES  # list of Z-coordinates
        self.dm = 'z'
        self.titles = [''] * self.n  # no title per statistical map
        self.black_bg = True  # Black background by default
        self.montage_title = ''  # Empty 'super' title
        self.colorbar = False  # Do not set a color bar
        # ROI parameters
        self.roi = None  # Do not set a ROI to show
        self.alpha_contour_roi = 1
        self.lw_contour_roi = 2
        # ROIAtlas parameters
        self.atlas = None  # No set of ROIs to show
        self.alpha_contours_rois = 1
        self.lw_contour_rois = 2
        self.crop_files = False  # Do not crop files
        self.vmax = None  # Do not define a maximum value
        self.list_t1_bg = []  # List of paths to normalised t1 files for background
        # Correction Method
        self.correction = None  # One for all statistical maps
        self.list_corrections = None  # One per statistical map
        # Use already calculated threshold
        self.threshold = None  # One threshold per statistical map
        self.list_thresholds = None  # Can be used if one threshold per statistical map is used

    def set_display_mode(self, dm):
        if dm in ['x', 'y', 'z']:
            self.dm = dm
        else:
            sys.exit('MontageActivationPlots can only be performed with display mode x, y or z')

    def set_cut_coords(self, cut_coords):
        self.cut_coords = cut_coords

    def set_list_normalised_t1_files_for_background(self, list_bg):
        self.list_t1_bg = list_bg
        if len(self.list_t1_bg) != len(self.stat_maps):
            err_msg = 'Discrepancy between number of statistical maps ({0}) and number of background T1 files ({1})'.format(
                self.n, len(self.list_t1_bg))
            err_msg += 'List of statistical maps : '
            for stat_map in self.stat_maps:
                err_msg += '\n\t - ' + stat_map
            err_msg += '\n'
            err_msg += 'List of t1 files: '
            for t1 in self.list_t1_bg:
                err_msg += '\n\t - ' + t1
            sys.exit(err_msg)

    def set_correction(self, correction):
        self.correction = correction

    def remove_correction(self):
        self.correction = None

    def set_list_corrections(self, list_corrections):
        self.list_corrections = list_corrections

    def set_threshold(self, threshold):
        self.threshold = threshold
        self.correction = None  # Force no correction when using manual threshold

    def set_list_thresholds(self, list_thresholds):
        if len(list_thresholds) != len(self.stat_maps):
            sys.exit(' You must provide the same number of thresholds than statistical maps')
        self.list_thresholds = list_thresholds
        self.correction = None

    def set_vmax(self, vmax):
        self.vmax = vmax

    def set_titles(self, titles):
        self.titles = titles

    def set_montage_title(self, montage_title):
        self.montage_title = montage_title

    def set_colorbar(self, colorbar):
        self.colorbar = colorbar

    def set_roi(self, roi, alpha=1, lw_contour_roi=2):
        self.roi = roi
        self.alpha_contour_roi = alpha
        self.lw_contour_roi = lw_contour_roi

    def set_atlas(self, atlas, alpha=1, lw_contour_rois=2):
        self.atlas = atlas
        self.alpha_contours_rois = alpha
        self.lw_contour_rois = lw_contour_rois

    def set_crop_intermediate_files(self, width_crop=18, height_crop=0):
        """
        First set Tue to the crop files option, that is to say intermediate files will be cropped
        Second, set cropping parameters
        :param width_crop: number of pixels removed from the left AND from the right
        :param height_crop: number of pixels removed from the top AND from the bottom of the images
        :return:
        """
        self.crop_files = True
        self.crop_params = {'width': width_crop, 'height': height_crop}

    def plot_temp_files(self):
        """
        Create temporary activation plots : one activation plot per statistical map.
        These files are temporarily saved before the montage is performed. They may be deleted afterwards.
        :return:
        """
        import nibabel
        self.list_imgs = []  # list of temporary images that will be deleted once the montage will be made
        # Define I/O
        for s, stat_file in enumerate(self.stat_maps):
            if isinstance(stat_file, str):
                if not ope(stat_file):
                    sys.exit('Error MontageActivationPlot : unexisting statistical map : \n\t{0}'.format(stat_file))
            elif isinstance(stat_file, nibabel.nifti1.Nifti1Image):
                if not hasattr(self, 'list_thresholds'):
                    err_msg = 'User must define list_thresholds when passing a list of thresholded statistical maps'
                    sys.exit(err_msg)
            # Create temporary filename
            temp_file = opj(self.out_dir, opb(self.out_file)[:-4] + '_temp_{0}.png'.format(s))
            if not ope(temp_file):
                # Check whether the user defined threshold(s) or correction method(s)
                if self.correction or self.list_corrections:
                    if self.correction:
                        thr_stat_map, tval = self.correction.compute_threshold(stat_map=stat_file)
                    else:
                        thr_stat_map, tval = self.list_corrections[s].compute_threshold(stat_map=stat_file)
                elif self.threshold or self.list_thresholds:
                    if self.threshold:
                        thr_stat_map, tval = stat_file, self.threshold
                    else:
                        thr_stat_map, tval = stat_file, self.list_thresholds[s]
                else:
                    thr_stat_map, tval = stat_file, 0
                # Start an activation plot
                act_plot = ActivationPlot(stat_map=thr_stat_map, output_file=temp_file)
                act_plot.set_display_mode(self.dm)
                act_plot.set_cut_coords(cut_coords=self.cut_coords)
                act_plot.set_title(self.titles[s])
                act_plot.set_black_background(True)
                if self.list_t1_bg:
                    act_plot.set_background_image(self.list_t1_bg[s])
                #if self.threshold:
                    # act_plot.set_threshold(threshold=self.threshold)
                if tval > 0:
                    act_plot.set_threshold(threshold=tval)
                act_plot.set_annotate(annotate=False)
                act_plot.set_color_bar(colorbar=self.colorbar)
                if self.vmax:
                    act_plot.set_vmax(vmax=self.vmax)
                if s == self.n - 1:  # Last row of the montage has annotations
                    act_plot.set_annotate(annotate=True)
                act_plot.plot()
                if self.atlas:
                    act_plot.add_contours_of_roi_atlas(atlas=self.atlas, alpha=self.alpha_contours_rois, filled=False,
                                                       lw=self.lw_contour_rois)
                if self.roi:
                    act_plot.add_contours_roi(roi=self.roi, alpha=self.alpha_contour_roi, filled=False,
                                              lw=self.lw_contour_roi)
                act_plot.save()
            self.list_imgs.append(temp_file)

    def plot_montage(self, vertical_montage=False):
        """
        Convert the list of intermediate images to a column of images with a montage title
        :return:
        """
        m = Montage1D(list_images=self.list_imgs, output_file=self.out_file, delete_inputs=True)
        if self.montage_title:
            m.set_title(title=self.montage_title)
        if len(self.cut_coords) > 1 or vertical_montage:
            m.vertical_montage()
        else:
            m.horizontal_montage()

    def crop_intermediate_files(self):
        """
        Every temporary intermediate image is cropped with default parameters.
        Now, the image is cropped in the width length
        w pixels removed from the left and w pixels removed from the right
        Todo : maybe set crop parameters or find a way to automatically estimate the crop parameters
        """
        wc, hc = self.crop_params['width'], self.crop_params['height']
        for f in self.list_imgs:
            im = Image.open(f)
            im_width, im_height = im.size
            im = im.crop((wc, hc, im_width - wc, im_height - hc))
            im.save(f)

    def plot(self, force_vertical_montage=False):
        if not ope(self.out_file):
            self.plot_temp_files()
            if self.crop_files:
                self.crop_intermediate_files()
            self.plot_montage(vertical_montage=force_vertical_montage)


class MontageCheckerboardMapsAs2DArrayOneSlice:
    """
    Class to create a checkerboard of statistical maps of size NxM
    For example : n Subjects and n Contrasts in a 2D montage with a single z-cut
    """

    def __init__(self, input_images, output_file):
        if not isinstance(input_images, np.ndarray):
            sys.exit(
                'MontageCheckerboard can only work with input_images as np.ndarray. Provide this type instead of {0}'.format(
                    type(input_images)))
        self.input_images = input_images
        self.output_file = output_file
        # Set default values
        self.out_dir = opd(self.output_file)
        self.nR, self.nC = self.input_images.shape
        self.z_slice = 55
        self.column_titles = []
        self.row_titles = []
        self.montage_title = ''
        self.correction = None
        self.threshold = 0
        self.atlas = None
        self.vmax = None
        self.cols = []

    def set_correction(self, correction):
        self.correction = correction

    def set_column_titles(self, column_titles):
        if len(column_titles) == self.nC:
            self.column_titles = column_titles
        else:
            msg = 'Number of columns ({0}) and number of titles ({1}) do not match. No column titles set.'.format(
                self.nC, len(column_titles))
            print(msg)

    def set_row_titles(self, row_titles, pos_index=0):
        if pos_index < 0 or pos_index >= self.nC:
            print('Wrong position index ({0}) for row titles'.format(pos_index))
        else:
            self.pos_index = pos_index
            self.row_titles = row_titles

    def set_threshold(self, threshold):
        self.threshold = threshold

    def set_montage_title(self, montage_title):
        self.montage_title = montage_title

    def set_z_slice(self, z_slice):
        self.z_slice = z_slice

    def set_vmax(self, vmax):
        self.vmax = vmax

    def set_atlas(self, atlas):
        self.atlas = atlas

    def plot_columns(self):
        for c in range(self.nC):
            basename = opb(self.output_file)[:-4]
            col_temp = opj(self.out_dir, '{0}_col_{1}_sur_{2}.png'.format(basename, c + 1, self.nC))
            if not ope(col_temp):
                map = MontageActivationPlots(stat_maps=list(self.input_images[:, c]), output_montage_file=col_temp)
                map.set_cut_coords([self.z_slice])
                if self.threshold:
                    map.set_threshold(threshold=self.threshold)
                if self.correction:
                    map.set_correction(self.correction)
                if self.vmax:
                    map.set_vmax(self.vmax)
                if self.row_titles and c == self.pos_index:
                    map.set_titles(titles=self.row_titles)
                if self.column_titles:
                    map.set_montage_title(self.column_titles[c])
                if self.atlas:
                    map.set_atlas(atlas=self.atlas)
                map.set_crop_intermediate_files(width_crop=0, height_crop=0)
                map.plot(force_vertical_montage=True)
            self.cols.append(col_temp)

    def montage_columns(self):
        """

        :return:
        """
        m = Montage1D(list_images=self.cols, output_file=self.output_file)
        m.set_delete_inputs(delete_inputs=True)
        if self.montage_title:
            m.set_title(self.montage_title, font_size=40)
        m.horizontal_montage()

    def plot(self):
        """

        :return:
        """
        if not ope(self.output_file):
            t0 = time.time()
            print('Montage 2D array of size {0}x{1} {2} ... '.format(self.nR, self.nC, opb(self.output_file)), end='')
            self.plot_columns()
            self.montage_columns()
            print('performed in ' + convert_duration_to_nice_duration_string(time.time() - t0))


class MontageCheckerboardMapsAs1DArrayMultipleSlices:
    def __init__(self, stat_maps, z_slices, output_file):
        """
        Multiple statistical maps presented in columns while several z_slices are presented in rows.
        Results presented as a checkerboard.
        :param stat_maps: list of statistical maps
        :param z_slices: list of z slices, cut_coords
        :param output_file: output filename
        """
        self.stat_maps = stat_maps
        self.z_slices = sorted(z_slices)[::-1]  # to have top brain slices at the top of the montage
        self.output_file = output_file
        # Set default values
        self.out_dir = opd(self.output_file)
        self.nR, self.nC = (len(self.z_slices), len(self.stat_maps))
        self.column_titles = []
        self.row_titles = []
        self.montage_title = ''
        self.atlas = None
        self.vmax = None
        self.list_t1_bg = []
        self.list_thresholds = None
        self.correction = None
        self.alpha_contour_roi = 1
        self.lw_contour_roi = 2

    def set_column_titles(self, column_titles):
        if len(column_titles) == self.nC:
            self.column_titles = column_titles
        else:
            msg = 'Number of columns ({0}) and number of titles ({1}) do not match. No column titles set.'.format(
                self.nC, len(column_titles))
            print(msg)

    def set_row_titles(self, row_titles, pos_index=0):
        if pos_index < 0 or pos_index >= self.nC:
            print('Wrong position index ({0}) for row titles'.format(pos_index))
        else:
            self.pos_index = pos_index
            self.row_titles = row_titles

    def set_list_thresholds(self, list_thresholds):
        self.list_thresholds = list_thresholds

    def set_correction(self, correction):
        self.correction = correction

    def set_montage_title(self, montage_title):
        self.montage_title = montage_title

    def set_vmax(self, vmax):
        self.vmax = vmax

    def set_atlas(self, atlas, alpha=1, lw_contour_rois=2):
        self.atlas = atlas
        self.alpha_contour_roi = alpha
        self.lw_contour_roi = lw_contour_rois

    def set_list_normalised_t1_files_for_background(self, list_bg):
        self.list_t1_bg = list_bg
        if len(self.list_t1_bg) != len(self.stat_maps):
            err_msg = 'Discrepency between number of statistical maps ({0}) and number of background T1 files ({1})'.format(
                len(self.stat_maps), len(self.list_t1_bg))
            err_msg += 'List of statistical maps : '
            for stat_map in self.stat_maps:
                err_msg += '\n\t - ' + stat_map
            err_msg += '\n'
            err_msg += 'List of t1 files: '
            for t1 in self.list_t1_bg:
                err_msg += '\n\t - ' + t1
            sys.exit(err_msg)

    def plot_rows(self):
        self.rows = []
        for r in range(self.nR):
            basename = opb(self.output_file)[:-4]
            row_temp = opj(self.out_dir, '{0}_ligne_{1}_sur_{2}.png'.format(basename, r + 1, self.nR))
            if not ope(row_temp):
                map = MontageActivationPlots(stat_maps=self.stat_maps, output_montage_file=row_temp)
                map.set_cut_coords([self.z_slices[r]])
                if self.list_thresholds:
                    map.set_list_thresholds(list_thresholds=self.list_thresholds)
                if self.correction:
                    map.set_correction(correction=self.correction)
                if self.vmax:
                    map.set_vmax(self.vmax)
                if r == 0 and self.column_titles:
                    map.set_titles(self.column_titles)
                if self.atlas:
                    map.set_atlas(atlas=self.atlas, alpha=self.alpha_contour_roi, lw_contour_rois=self.lw_contour_roi)
                if self.list_t1_bg:
                    map.set_list_normalised_t1_files_for_background(self.list_t1_bg)
                map.set_crop_intermediate_files(width_crop=0, height_crop=0) # was wc = 18
                map.plot()
            self.rows.append(row_temp)

    def montage_rows(self):
        """

        :return:
        """
        m = Montage1D(list_images=self.rows, output_file=self.output_file)
        m.set_delete_inputs(delete_inputs=True)
        if self.montage_title:
            m.set_title(self.montage_title, font_size=40)
        m.vertical_montage()

    def plot(self):
        """

        :return:
        """
        if not ope(self.output_file):
            self.plot_rows()
            self.montage_rows()


class FullMontageActivationMap:
    """
    The idea is to provide a full view (x ,y or z) of a statistical map
    """

    def __init__(self, stat_map, display_mode, out_file):
        self.stat_map = stat_map
        self.display_mode = display_mode
        self.out_file = out_file
        # Set default values
        # Set default view parameters
        default_coords = \
            {
                'x': list(range(-60, 60, 4)),  # 6x5
                'y': list(range(-90, 60, 5)),  # 4x5
                'z': list(range(-20, 70, 3)),  # 6x5
            }
        default_nrows = {'x': 6, 'y': 6, 'z': 6}
        default_ncols = {'x': 5, 'y': 5, 'z': 5}
        self.cut_coords = default_coords[self.display_mode]
        self.nrows = default_nrows[self.display_mode]
        self.ncols = default_ncols[self.display_mode]
        # Set default activation maps parameters
        self.black_bg = True
        self.title = ''
        self.threshold = 0
        self.atlas = None
        self.background_img = ''
        self.vmax = None
        self.roi = None

    def set_title(self, title):
        self.title = title

    def set_threshold(self, threshold):
        self.threshold = threshold

    def set_atlas(self, atlas, alpha=.6, lw=2):
        self.atlas = atlas
        self.atlas_transparency = alpha
        self.atlas_linewidth = lw

    def set_background_img(self, bg_img):
        self.background_img = bg_img

    def set_vmax(self, vmax):
        self.vmax = vmax

    def set_roi(self, roi):
        self.roi = roi

    def set_montage_parameters(self, display_mode, cut_coords, nrows, ncols):
        """
        Let the user define itw own parameters
        :param display_mode:
        :param cut_coords:
        :param nrows:
        :param ncols:
        :return:
        """
        self.display_mode = display_mode
        self.cut_coords = cut_coords
        self.nrows = nrows
        self.ncols = ncols

    def plot(self):
        """

        :return:
        """
        i0 = 0
        temp_files = []
        if not ope(self.out_file):
            for row in range(self.nrows):
                temp_file = opj(opd(self.out_file), 'temp_row_{0}.png'.format(row + 1))
                if not ope(temp_file):
                    i1 = i0 + self.ncols
                    # Start the Activation plot
                    ap = ActivationPlot(stat_map=self.stat_map, output_file=temp_file)
                    ap.set_cut_coords(self.cut_coords[i0:i1])
                    ap.set_display_mode(dm=self.display_mode)
                    ap.set_black_background(black_bg=self.black_bg)
                    if self.background_img:
                        ap.set_background_image(bg_img=self.background_img)
                    ap.set_annotate(annotate=True)
                    ap.set_threshold(threshold=self.threshold)
                    ap.set_draw_cross(draw_cross=False)
                    if self.vmax:
                        ap.set_vmax(vmax=self.vmax)
                    if row == self.nrows - 1:
                        ap.set_color_bar(colorbar=True)
                    ap.plot()
                    if self.atlas:
                        ap.add_contours_of_roi_atlas(atlas=self.atlas, alpha=self.atlas_transparency,
                                                     lw=self.atlas_linewidth)
                    if self.roi:
                        ap.add_contours_roi(roi=self.roi, alpha=.6)
                    ap.save()

                    temp_files.append(temp_file)
                    i0 = i1

        # Create the montage
        m = Montage1D(list_images=temp_files, output_file=self.out_file, delete_inputs=True)
        if self.title:
            m.set_title(self.title)
        m.vertical_montage()


class MosaicActivationMap:
    """
    #TODO : use the display_mode 'MosaicPlot' that came with nilearn 0.7.1
    """

    def __init__(self, stat_map, out_file, mosaic_parameters=None):
        self.stat_map = stat_map
        self.out_file = out_file
        # Default values are defined here
        if mosaic_parameters:
            self.set_mosaic_parameters(mosaic_parameters)
        else:
            self.set_mosaic_parameters(DEFAULT_MOSAIC_PARAMETERS)
        self.views = ['x', 'y', 'z']
        self.cc = [self.x_cc, self.y_cc, self.z_cc]
        self.intermediate_files = [opj(opd(self.out_file), 'temp_{0}.png'.format(v)) for v in self.views]
        self.threshold = 0  # Threshold is 0
        self.title = ''  # No title
        self.atlas = None  # By default, no set of ROIs will be shown on the maps
        self.colorbar_index = 2  # Default color bar is set on the axial slices (Z)
        self.alpha = 1  # Transparency parameter for plotting an atlas
        self.vmax = None
        self.bg_img = None
        # Add markers (seed) with options
        self.markers = None
        self.markers_col = None
        # Add Region of interest and options
        self.roi = None
        self.roi_alpha = None
        self.roi_filled = None
        self.roi_lw = None

    def set_x_cut_coords(self, x):
        """
        The user can define the x coordinates that will be used for the sagittal slices
        :param x: list of x-MNI coordinates
        """
        self.x_cc = x

    def set_y_cut_coords(self, y):
        """
        The user can define the y coordinates that will be used for the coronal slices
        :param y: list of y-MNI coordinates
        """
        self.y_cc = y

    def set_z_cut_coords(self, z):
        """
        The user can define the z coordinates that will be used for the axial slices
        :param z: list of z-MNI coordinates
        """
        self.z_cc = z

    def set_xyz_cut_coords(self, x, y, z):
        self.set_x_cut_coords(x)
        self.set_y_cut_coords(y)
        self.set_z_cut_coords(z)

    def set_atlas_linewidth(self, lw):
        self.atlas_lw = lw

    def set_mosaic_parameters(self, mosaic_parameters):
        self.set_x_cut_coords(mosaic_parameters['x'])
        self.set_y_cut_coords(mosaic_parameters['y'])
        self.set_z_cut_coords(mosaic_parameters['z'])
        self.set_atlas_linewidth(mosaic_parameters['atlas_lw'])

    def set_title(self, title):
        """
        The user can define a title
        :param title:
        :return:
        """
        self.title = title

    def set_threshold(self, threshold):
        """
        Sets a threshold value
        :param threshold:
        :return:
        """
        self.threshold = threshold

    def set_background_image(self, bg_img):
        self.bg_img = bg_img

    def set_atlas(self, atlas):
        self.atlas = atlas

    def set_alpha(self, alpha):
        self.alpha = alpha

    def set_colorbar_index(self, cbar_index):
        if cbar_index > 2 or cbar_index < 0:
            sys.exit('Choose color bar index in [0,1,2] for [x,y,z]')
        self.colorbar_index = cbar_index

    def set_vmax(self, vmax):
        self.vmax = vmax

    def set_markers(self, markers, color='y'):
        self.markers = markers
        self.markers_col = color

    def set_roi(self, roi, alpha=.6, filled=False, lw=2):
        self.roi = roi
        self.roi_alpha = alpha
        self.roi_filled = filled
        self.roi_lw = lw

    def plot(self):
        if not ope(self.out_file):
            self.create_each_view()
            self.perform_montage()

    def create_each_view(self):
        for i, f in enumerate(self.intermediate_files):
            ap = ActivationPlot(self.stat_map, output_file=f)
            if self.bg_img:
                ap.set_background_image(bg_img=self.bg_img)
            ap.set_annotate(annotate=True)
            ap.set_threshold(threshold=self.threshold)
            ap.set_black_background(black_bg=True)
            if i == self.colorbar_index:
                ap.set_color_bar(True)
            if self.vmax:
                ap.set_vmax(vmax=self.vmax)
            ap.set_view_mode(display_mode=self.views[i], cut_coords=self.cc[i])
            ap.set_draw_cross(False)
            ap.plot()
            if self.atlas:
                ap.add_contours_of_roi_atlas(atlas=self.atlas, alpha=self.alpha, lw=self.atlas_lw)
            if self.markers:
                ap.add_markers(coords=self.markers, marker_color=self.markers_col)
            if self.roi:
                ap.add_contours_roi(roi=self.roi, filled=self.roi_filled, alpha=self.roi_alpha, lw=self.roi_lw)
            ap.save()

    def perform_montage(self):
        m = Montage1D(list_images=self.intermediate_files, output_file=self.out_file, delete_inputs=True)
        m.set_title(title=self.title)
        m.vertical_montage_adjust_to_min_width()


class ConjunctionPlot:
    def __init__(self, conjunction_map, output_file):
        self.conjunction_map = conjunction_map
        self.output_file = output_file
        self.display_mode = 'z'
        self.cut_coords = DEFAULT_Z_SLICES
        self.bg_img = MNI152TEMPLATE
        self.dim = 'auto'
        self.black_bg = False
        self.fig_bg_col = 'w'
        self.cbar_tick_col = 'k'
        self.title = ''
        self.annotate = True
        self.colorbar_labels = None
        self.colormap = ListedColormap(colors=["red", "green", "blue"], name='conjunction_cmap', N=3)
        self.display = None

    def set_background_image(self, bg_img):
        if isinstance(bg_img, str):
            # In this case, the user may pass a normalised T1 file, and let's increase the contrast
            self.dim = -.5
        self.bg_img = bg_img

    def set_black_background(self):
        self.black_bg = True
        self.fig_bg_col = 'k'
        self.cbar_tick_col = 'w'

    def set_cut_coords(self, cut_coords):
        self.cut_coords = cut_coords

    def set_display_mode(self, dm):
        vals = ['x', 'y', 'z', 'ortho']
        if not dm in vals:
            sys.exit('ActivationPlot ERROR. Set display mode to one of the following values\n\t-' + '\n\t-'.join(vals))
        if dm == 'ortho':
            self.cut_coords = None
        self.display_mode = dm
        self.cut_coords = DEFAULT_SLICES_DM[dm]

    def set_colorbar_labels(self, colorbar_labels):
        self.colorbar_labels = colorbar_labels

    def set_annotate(self, annotate):
        self.annotate = annotate

    def set_title(self, title):
        self.title = title

    def plot(self):
        if self.display_mode != 'ortho':
            n_slices = len(self.cut_coords)
        else:
            n_slices = 3
        width_ratios = [n_slices, 0.08]
        figsize = (n_slices * 2, 2)
        fig, (img_ax, cbar_ax) = plt.subplots(1, 2,
                                              gridspec_kw={"width_ratios": width_ratios, "wspace": 0.0},
                                              figsize=figsize)
        # Work on the colorbar
        norm = colors.Normalize(vmin=0, vmax=3, clip=False)
        self.display = plot_roi(self.conjunction_map, cmap=self.colormap, axes=img_ax, display_mode=self.display_mode,
                                cut_coords=self.cut_coords, annotate=self.annotate, bg_img=self.bg_img,
                                black_bg=self.black_bg, title=self.title, dim=self.dim, threshold=.5, norm=norm)

        # Very strange way of setting the ticks but the previous "ticks = [.5, 1.5, 2.5]" resulted in an out-of-range
        # label positions
        ticks = [1.86, 2, 2.14]
        ticks = [1.2, 2, 2.8]
        colorbar.ColorbarBase(cbar_ax, cmap=self.colormap, ticks=ticks, norm=norm,
                              orientation="vertical", spacing="proportional", ticklocation='right')

        # If maximum length of colorbar labels < 7: keep labels horizontal
        max_str = max([len(c) for c in self.colorbar_labels])
        if max_str < 7:   # colorbar labels set verticaly
            cbar_ax.set_yticklabels(self.colorbar_labels, color=self.cbar_tick_col, rotation='vertical',
                                    fontdict={'va': 'center'})
        else:  # colorbar labels set horizontal
            cbar_ax.set_yticklabels(self.colorbar_labels, color=self.cbar_tick_col)

    def add_contours_of_roi_atlas(self, atlas, alpha=1.0, filled=False, lw=2):
        atlas.add_contours_list_rois_to_display(display=self.display, alpha=alpha, filled=filled, lw=lw)

    def add_contours_roi(self, roi, alpha=.6, filled=False, lw=2):
        roi.add_contours_to_display(display=self.display, alpha=alpha, filled=filled, lw=lw)

    def save(self):
        plt.savefig(self.output_file, bbox_inches="tight", facecolor=self.fig_bg_col)


def plot_stat_map_and_atlas(stat_map, atlas: ROIAtlas, out_file, black_bg, threshold=2.5, alpha=.8, axes=None,
                            title=None):
    """
    Simply plots an activation map and adds an atlas overlay on top
    :param stat_map:
    :param atlas:
    :param out_file:
    :param black_bg:
    :param threshold:
    :param alpha:
    :param axes:
    :param title:
    :return:
    """
    d = plot_stat_map(stat_map_img=stat_map, threshold=threshold, display_mode='ortho', draw_cross=False,
                      cut_coords=atlas.get_atlas_coordinates(), black_bg=black_bg, axes=axes, title=title)
    atlas.add_contours_list_rois_to_display(display=d, alpha=alpha)
    plt.savefig(out_file)
    plt.close()


class GlassBrain:
    def __init__(self, stat_map, output_file):
        self.stat_map = stat_map
        self.outfile = output_file
        # set default parameters (Nilearn default for plot_glass_brain)
        self.display_mode = 'ortho'
        self.annotate = True
        self.black_bg = True
        self.title = ''
        self.colorbar = False
        self.threshold = 0
        self.vmax = None
        self.vmin = None
        self.alpha = 0.7
        self.plot_abs = False
        self.symmetric_cbar = 'auto'
        self.resampling_interpolation = 'continuous'

    def set_display_mode(self, dm):
        vals = ['ortho', 'x', 'y', 'z', 'xz', 'yx', 'yz', 'l', 'r', 'lr', 'lzr', 'lyr', 'lzry', 'lyrz']
        if not dm in vals:
            sys.exit('ActivationPlot ERROR. Set display mode to one of the following values\n\t-' + '\n\t-'.join(vals))
        self.display_mode = dm

    def set_annotate(self, annotate):
        self.annotate = annotate

    def set_title(self, title):
        self.title = title

    def set_color_bar(self, colorbar):
        self.colorbar = colorbar

    def set_black_background(self, black_bg):
        self.black_bg = black_bg

    def set_vmin(self, vmin):
        self.vmin = vmin

    def set_vmax(self, vmax):
        self.vmax = vmax

    def plot(self):
        plot_glass_brain(stat_map_img=self.stat_map,
                         display_mode=self.display_mode,
                         colorbar=self.colorbar,
                         title=self.title,
                         threshold=self.threshold,
                         annotate=self.annotate,
                         black_bg=self.black_bg,
                         alpha=self.alpha,
                         vmin=self.vmin,
                         vmax=self.vmax,
                         plot_abs=self.plot_abs,
                         symmetric_cbar=self.symmetric_cbar,
                         resampling_interpolation=self.resampling_interpolation)

    def save(self):
        plt.savefig(self.outfile)
        plt.close()
