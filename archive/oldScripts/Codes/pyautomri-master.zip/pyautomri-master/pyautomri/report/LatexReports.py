import subprocess, os, shutil, filecmp
import time
from os.path import exists as ope, join as opj, dirname as opd
from pathlib import Path
from pyautomri.utils.utils import convert_duration_to_nice_duration_string, sizeof_fmt


LATEX_TEMPLATE_FILES_DIR = opd(Path(__file__))
PACKAGE_TXT = opj(LATEX_TEMPLATE_FILES_DIR, '_doc_use_package.txt')
END_DOC = r'\end{document}'


class LatexDocumentReport:
    """
    Class to generate a Latex Report
    """

    def __init__(self, tex_file):
        """
        Initializes the class
        :param tex_file: path to save the .tex file
        """
        self.tex_file = tex_file
        self.out_dir = opd(self.tex_file)
        self.pdf_file = tex_file[:-4] + '.pdf'
        if ope(self.tex_file):
            self.old_tex_file = self.tex_file[:-4] + '_OLD.tex'
            shutil.copy(self.tex_file, self.old_tex_file)
        self.f = open(self.tex_file, 'w')
        self.title = 'Titre par defaut'
        self.compile_doc = True

    def set_title(self, title):
        """
        Sets the title to the document
        :param title: str, title
        """
        self.title = title

    def __add_packages__(self):
        self.f.write(open(PACKAGE_TXT, 'r').read())

    def __set_geometry__(self):
        """
        Define geometry
        """
        self.f.write('\geometry{a4paper, total={170mm,257mm},left=20mm, top=20mm,}\n')

    def write_header(self):
        self.f.write('\documentclass{article} \n')
        self.__add_packages__()
        self.__set_geometry__()
        txt = r'''\title{Rapport ''' + self.title + r'''}
\author{}
\date{\today}

\begin{document}
\maketitle
'''
        self.f.write(txt)

    def set_table_of_contents(self):
        """
        Add the table of contents
        """
        self.f.write(r'\tableofcontents' + '\n')

    def __write_ending__(self):
        """
        Finish the document
        """
        self.f.write(END_DOC)

    def add_text(self, text):
        """
        Simply add text, and remove special characters that will fail Latex compilation
        :param text: text
        """
        text = text.replace('_', '\_')
        self.f.write(text)

    def newpage(self):
        """
        Adds a new page
        """
        self.f.write(r'\newpage' + '\n')

    def add_section(self, section_name):
        """
        Adds a section
        :param section_name: str, section name
        """
        self.f.write('\n\section{' + section_name + '}\n')

    def add_subsection(self, subsection_name):
        """
        Adds a subsection
        :param subsection_name: str, subsection name
        """
        self.f.write('\n\subsection{' + subsection_name + '}\n')

    def add_subsubsection(self, subsubsection_name):
        """
        Adds a subsubsection
        :param subsubsection_name: str, subsection name
        """
        self.f.write('\n\subsubsection{' + subsubsection_name + '}\n')

    def add_figure(self, path_image, width=0.95, legend='', align='!ht'):
        txt = r'\begin{figure}[' + align + ']' + '\n'
        txt += '\t' + r'\begin{center}' + '\n'
        txt += '\t\includegraphics[width=' + str(width) + '\linewidth]{' + path_image + '}\n'
        if legend:
            txt += '\caption{' + legend + '} \n'
        txt += '\t\end{center}\n'
        txt += '\end{figure}\n\n'
        self.f.write(txt)

    def add_table(self, table):
        """
        Adds a table that wa
        :param table: string, containing all Latex elements of the table
        """
        self.f.write(table)

    def save(self):
        """
        Save and close the .tex file
        :return:
        """
        self.__write_ending__()
        self.f.close()

    def compile(self):
        """
        Compile the .tex file into the same folder
        """
        perform_double_compilation = not ope(self.pdf_file)  # To get the table of contents -> double compilation

        if hasattr(self, 'old_tex_file'):
            # filecmp.cmp return True if the files are the same, False otherwise.
            # If files are exactly the same, it is not necessary to compile the document another time
            self.compile_doc = not filecmp.cmp(self.old_tex_file, self.tex_file)
            # And the OLD file is removed
            os.remove(self.old_tex_file)

        if self.compile_doc or not ope(self.pdf_file):
            print('-------------------------------------------------------------')
            print('---- Compiling PDF report ... ')
            t0 = time.time()
            # -interaction=batchmode makes a silent compilation
            options = ['-interaction=batchmode', '-output-directory', self.out_dir]
            compilation_cmd = 'pdflatex {0} {1}'.format(' '.join(options), self.tex_file)
            x = subprocess.call(compilation_cmd, shell=True)
            if x != 0:
                print('Exit - code not 0, check result!')
            else:
                if perform_double_compilation:
                    x = subprocess.call(compilation_cmd, shell=True)
                duration = convert_duration_to_nice_duration_string(d=time.time()-t0)
                print('-------------------------------------------------------------')
                print('Successful Latex Report compilation in {0} !'.format(duration))
                print('-------------------------------------------------------------')
        else:
            print('-------------------------------------------------------------')
            print('Report is not compiled because no change was added to the Latex file')
            print('-------------------------------------------------------------')
        size = sizeof_fmt(os.path.getsize(self.pdf_file))
        print('Report {0} pdf is here : '.format(self.title))
        print('-->' + self.pdf_file + ' ({0})'.format(size))
