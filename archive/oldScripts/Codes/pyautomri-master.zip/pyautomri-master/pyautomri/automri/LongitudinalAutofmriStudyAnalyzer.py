import sys
import numpy as np
from os.path import join as opj, exists as ope
from pyautomri.automri.AutofmriStudyAnalyzer import AutofmriStudyAnalyzer
from pyautomri.plot.StatisticalMapping import MontageCheckerboardMapsAs1DArrayMultipleSlices
from pyautomri.stat.StatFunctions import SecondLevelAnalysis
from pyautomri.utils.utils import find_nii_or_gz, list_of_files_exist_print_missing, create_dir


class LongitudinalAutofmriStudyAnalyzer(AutofmriStudyAnalyzer):
    """
    This class will implement functions to convert Groups to Groups And Sessions (=Visits)
    """
    def __init__(self, study_name, verbose=True):
        super().__init__(study_name=study_name, verbose=verbose)

    def __set_print_options__(self):
        self.sa = '--- LongitudinalStudyAnalyzer ' + '(' + self.name + ') --- '

    def __str__(self):
        """
        Implements the print function
        #todo : better looking implementation please
        """
        tab = '    |'
        text = '\n'
        text = text + tab + self.sa + '\n'
        text = text + tab + ' {0} Group(s) : \n'.format(self.nG)
        for g, gr in enumerate(self.groups):
            text = text + tab + tab[:-1] + ' - ' + gr.name + ' (' + str(gr.nS) + ' subjects) - ' + self.design_name \
                   + ' ({0} contrasts)'.format(self.n_con_per_group[g]) + '\n'
        text = text + tab + ' {0} p-values : {1}\n'.format(len(self.grp_stat_map_list_corrections),
                                                           [str(t) for t in self.grp_stat_map_list_corrections])
        try:
            text = text + tab + ' ROI dictionary : ' + self.roi_atlas.get_atlas_name() + ' ({0} ROIs)'.format(
                self.nR) + '\n'
            for r, roi in enumerate(self.roi_atlas.get_list_rois()):
                text = text + tab + tab[:-1] + ' - roi #{0} : {1} \n'.format(str(r + 1).zfill(2), roi.get_name())
        except AttributeError:
            pass
        return text

    def get_list_subjects(self):
        list_subjects = []
        for g, gr in enumerate(self.groups):
            list_subjects.append(gr.get_list_subjects())
        return list_subjects

    def __set_default_output_subdirectory_name__(self):
        self.output_subdir = 'autofmri_longitudinal_analysis_dir'

    def __find_autofmri_individual_statistical_maps__(self):
        """
        A list of numpy 2D-vector-arrays (shape: number of subjects x number of contrasts in the group design)
        containing path to the subjects statistical maps is filled
        """
        self.__check_settings__()
        if not self.grp_stat_maps:
            for g, gr in enumerate(self.groups):
                n_su, n_cn = gr.get_num_subjects(), gr.get_num_contrasts()
                self.ind_stat_maps.append(np.empty(shape=(n_su, n_cn), dtype=object))
                for s, su in enumerate(gr.get_list_subjects()):
                    for c, stat_map in enumerate(su.get_statistical_maps()):
                        self.ind_stat_maps[g][s, c] = stat_map
                msg = self.sa + 'Individual statistical maps from gr {0}'.format(gr.name)
                list_of_files_exist_print_missing(list(self.ind_stat_maps[g].flatten()), msg=msg, verbose=False)

    def __find_autofmri_individual_contrast_maps__(self):
        """
        A list of numpy 2D-vector-arrays (shape: number of subjects x number of contrasts in the group design)
        containing path to the subjects contrast maps is filled
        """
        self.__check_settings__()
        if not self.ind_con_maps:
            for g, gr in enumerate(self.groups):
                n_su, n_cn = gr.get_num_subjects(), gr.get_num_contrasts()
                # n_tp = gr.get_num_timepoints()  # I choose not to use the timepoint info in this representation
                self.ind_con_maps.append(np.empty(shape=(n_su, n_cn), dtype=object))
                for s, su in enumerate(gr.get_list_subjects()):
                    for c, con_map in enumerate(su.get_contrast_maps()):
                        self.ind_con_maps[g][s, c] = con_map
                msg = self.sa + 'Individual contrast maps from gr {0}'.format(gr.name)
                list_of_files_exist_print_missing(list(self.ind_con_maps[g].flatten()), msg=msg, verbose=self.verbose)
    #
    # def get_individual_contrast_map(self, subject, contrast, timepoint_index):
    #     self.__find_autofmri_individual_contrast_maps__()
    #     gr_index, su_index = self.get_subject_index_and_group_index(subject)
    #     print(gr_index, su_index)
    #     print(contrast)
    #     con_indices = self.groups[gr_index].get_contrast_index(contrast)
    #     print(con_indices)
    #     print(self.ind_con_maps[0].shape)
    #     sys.exit()
    #     return self.ind_con_maps[gr_index][su_index, con_index]

    def get_individual_statistical_map(self, subject, contrast, timepoint_index):
        self.__find_autofmri_individual_statistical_maps__()
        gr_index, _ = self.get_subject_index_and_group_index(subject)
        long_subject = self.groups[gr_index].get_subject(subject=subject)
        return long_subject.get_statistical_map(contrast=contrast, visit_index=timepoint_index)

    def setup_second_level_analyses(self):
        """
        Set up second level analyses
        For each group, for each contrast, perform a simple second level analysis
        :return:
        """
        self.__find_autofmri_individual_contrast_maps__()
        # Save instances of second level analyses and group statistical maps
        for g, gr in enumerate(self.groups):
            self.second_level_analyses.append(np.empty(shape=(self.n_con_per_group[g]), dtype=object))
            self.grp_stat_maps.append(np.empty(shape=(gr.get_num_contrasts()), dtype=object))
            gr_dir = create_dir(opj(self.get_second_level_directory(), gr.get_dirname()))
            con_visit_names = gr.get_contrast_names_with_visits()
            for c, contrast in enumerate(gr.get_contrasts()):
                # Subdirectory with contrast name "gr_gr1/gr_gr1_S1_con_0001_TASK"
                sla_dir = create_dir(opj(gr_dir, '_'.join([gr.get_dirname(), con_visit_names[c]])))
                basename = '_'.join([gr.get_name(), con_visit_names[c]])
                # Setup a "second level analysis" instance
                sla = SecondLevelAnalysis(contrast_maps=list(self.ind_con_maps[g][:, c]), output_dir=sla_dir)
                sla.set_output_statistical_map_basename(basename=basename)
                # Save instance into list of np arrays
                self.second_level_analyses[g][c] = sla
                # Define the group statistical map filename
                self.grp_stat_maps[g][c] = sla.get_statistical_map()
                # Set the statistical map to the group instance (in case previously calculated)
                if ope(self.grp_stat_maps[g][c]):
                    self.groups[g].set_statistical_map(contrast=contrast, stat_map=self.grp_stat_maps[g][c])
