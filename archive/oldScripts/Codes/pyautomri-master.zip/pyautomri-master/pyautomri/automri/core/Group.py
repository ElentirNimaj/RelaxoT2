#!/usr/bin/python
import sys

from os.path import join as opj, exists as ope
import numpy as np
from pyautomri.automri.core.Design import read_and_get_design
from pyautomri.automri.core.Subject import Subject
from pyautomri.utils.utils import find_nii_or_gz


class Group:
    def __init__(self, name, list_subjects):
        self.name = name
        self.gr_name = 'gr_' + name
        self.preproc_subdir_name = self.gr_name  # By default
        self.set_list_subjects(list_subjects)
        self.color = 'r'

    def set_color(self, color):
        self.color = color

    def get_color(self):
        return self.color

    def get_dirname(self):
        return 'gr_' + self.name

    def get_name(self):
        return self.name

    def set_list_subjects(self, list_subjects):
        """
        Sets the subjects to the class and sets the group information to each subject
        :param list_subjects: a list of dictionary items
        :return:
        """
        self.list_subjects = list_subjects
        self.list_subject_ids = []
        for s, su in enumerate(self.list_subjects):
            su.set_group(self)
            self.list_subject_ids.append(su.get_id())
        self.nS = len(self.list_subjects)

    def __str__(self):
        return 'Group ' + self.name + ' ({0} subjects)'.format(self.nS)

    def set_preproc_subdir_name(self, preproc_subdir_name):
        """
        Edit preproc_subdir_name for some cases
        :param preproc_subdir_name:
        :return:
        """
        self.preproc_subdir_name = preproc_subdir_name

    def set_study_dir(self, study_dir):
        self.study_dir = study_dir
        self.data_dir = opj(self.study_dir, 'data', self.gr_name)
        self.preprocessing_dir = opj(self.study_dir, 'pre-processing', self.preproc_subdir_name)
        for su in self.list_subjects:
            su.set_study_dir(self.study_dir)

    def set_design(self, design):
        """
        Assigns the design structure to every subject of the group
        :param design:
        :return:
        """
        self.design = read_and_get_design(design=design)
        # Now set the design to every subject of the group
        for su in self.list_subjects:
            su.set_design(self.design)
        # Count number of contrasts
        self.list_contrasts = self.design.get_contrasts()
        self.nC = len(self.list_contrasts)
        # Prepare the numpy array
        self.statistical_maps = np.empty((self.nC), dtype=object)

    def get_data_dir(self):
        return self.data_dir

    def get_list_subject_ids(self):
        return [su.su_id for su in self.list_subjects]

    def get_list_subjects(self):
        return self.list_subjects

    def get_num_subjects(self):
        return len(self.list_subjects)

    def get_pre_processing_dir(self):
        return self.preprocessing_dir

    def get_results_design_dir(self, design):
        gr_result_dir = opj(self.study_dir, 'results', 'functional', design.get_design_name(), 'gr_' + self.name)
        return gr_result_dir

    def check_design(self):
        try:
            self.design
        except AttributeError:
            sys.exit('Design is not set for Group {0}'.format(self.name))

    def check_study_dir(self):
        try:
            self.study_dir
        except AttributeError:
            sys.exit('Study directory is not set for Group {0}'.format(self.name))

    def get_design(self):
        self.check_design()
        return self.design

    def set_statistical_map(self, contrast, stat_map=None):
        con_num = contrast.get_spm_index()
        c = con_num - 1
        if not self.statistical_maps[c]:
            if stat_map:
                if ope(stat_map):
                    #print('\tStat map set contrast {0} for group {1} (nilearn file)'.format(con_num, self.name))
                    self.statistical_maps[c] = stat_map
                else:
                    err_msg = 'The provided statistical map does not exist for Group {0} contrast {1} {2}\n\t{3}'.format(
                        self.name, con_num, contrast.get_name(), stat_map)
                    sys.exit(err_msg)
            else:
                print('Group stat map being searched in default autofmri folder ')
                self.check_design()
                self.check_study_dir()
                spm_2nd_level_file = find_nii_or_gz(
                    opj(self.study_dir, 'results', 'functional', self.design.get_name(), '2nd_level', self.gr_name,
                        contrast.get_suffix(), 'spmT_0001.nii'), returnSearchedImageFilename=True)
                if ope(spm_2nd_level_file):
                    self.statistical_maps[c] = spm_2nd_level_file
                    print('\tStat map set contrast {0} for group {1} (SPM/autofmri file)'.format(con_num, self.name))
                else:
                    err_msg = 'The autofmri statistical map does not exist for Group {0} contrast {1} {2}\n\t{3}'.format(
                        self.name, con_num, contrast.get_name(), spm_2nd_level_file)
                    sys.exit(err_msg)

    def get_statistical_map(self, contrast):
        self.check_design()
        self.check_study_dir()
        c = self.design.get_contrast_index(contrast)
        if self.statistical_maps[c]:
            if ope(self.statistical_maps[c]):
                return self.statistical_maps[c]
            else:
                return find_nii_or_gz(
                    opj(self.study_dir, 'results', 'functional', self.design.get_name(), '2nd_level', self.gr_name,
                        contrast.get_suffix(), 'spmT_0001.nii'), returnSearchedImageFilename=True)
        else:
            print(self.statistical_maps[c])
            sys.exit('ERROR group stat map {0} was not set ?'.format(contrast))

    def get_contrasts(self):
        self.check_design()
        return self.design.get_contrasts()

    def get_num_contrasts(self):
        self.check_design()
        return self.nC

    def get_contrast_names(self):
        self.check_design()
        return [contrast.get_name() for contrast in self.design.get_contrasts()]

    def get_contrast(self, contrast):
        return self.design.get_contrast(contrast)

    def get_contrast_index(self, contrast):
        return self.design.get_contrast_index(contrast)

    def get_contrast_titles(self):
        self.check_design()
        return [contrast.get_legend() for contrast in self.design.get_contrasts()]

    def get_contrast_spm_strings(self):
        self.check_design()
        return [contrast.get_spm_index_str() for contrast in self.design.get_contrasts()]

    def get_normalised_t1_files(self):
        """
        For every subject, go get the normalised t1 file (wT1) and return the list
        :return:
        """
        list_t1_files = []
        for su in self.list_subjects:
            list_t1_files.append(su.get_normalised_t1_file())
        return list_t1_files

    def get_subject(self, subject):
        """

        :param subject:
        :return:
        """
        if isinstance(subject, str):
            return self.get_subject_given_subject_id(su_id=subject)
        elif isinstance(subject, int):
            return self.get_subject_given_subject_index(su_index=subject)
        elif isinstance(subject, Subject):
            if subject in self.list_subjects:
                su_idx = self.list_subjects.index(subject)
                return self.get_subject_given_subject_index(su_index=su_idx)
        elif hasattr(subject, 'group'):
            if subject in self.list_subjects:
                su_idx = self.list_subjects.index(subject)
                return self.get_subject_given_subject_index(su_index=su_idx)
        else:
            sys.exit('Unknown subject type ({0}) for requesting a subject from a group '.format(type(subject)))

    def get_subject_given_subject_id(self, su_id):
        """
        Get subject instance. Request is made with subject ID.
        :param su_id:str, subject ID.
        :return:
        """
        # Make sure that the request is made with a complete subject ID (the list of IDs has the "su_" prefix)
        if not su_id.startswith('su_'):
            su_id = 'su_' + su_id
        if su_id in self.get_list_subject_ids():
            return self.get_subject_given_subject_index(su_index=self.get_list_subject_ids().index(su_id))
        else:
            sys.exit('Error : unknown subject ID "{0}" in group {1}'.format(su_id, self.gr_name))

    def get_subject_given_subject_index(self, su_index):
        """

        :param su_index:
        :return:
        """
        if su_index > self.nS:
            sys.exit('Can not return a subject because subject index ({0}) > num subjects ({1})'.format(su_index, self.nS))
        else:
            return self.list_subjects[su_index]


# TODO : work in progress
class LongitudinalGroup(Group):
    def __init__(self, name, list_subjects):
        """

        :param name:
        :param list_subjects:
        """
        super().__init__(name, list_subjects)
        self.guess_timepoints()

    def __str__(self):
        return 'Longitudinal Group ' + self.name + ' with {0} subjects : {1}'.format(self.nS, self.list_subject_ids)

    def guess_timepoints(self):
        """

        :return:
        """
        timepoints = []
        for subject in self.list_subjects:
            for tp in subject.get_timepoints():
                timepoints.append(tp)
        self.timepoints = list(np.unique(timepoints))
        self.nt = len(self.timepoints)

    def get_list_subjects(self):
        return self.list_subjects

    def get_timepoints(self):
        """
        :return: list of timepoints for the group
        """
        return self.timepoints

    def get_num_timepoints(self):
        return self.nt

    def get_contrast_index(self, contrast):
        return [design.get_contrast_index(contrast) for design in self.designs]

    def set_study_dir(self, study_dir):
        self.study_dir = study_dir
        self.data_dir = opj(self.study_dir, 'data', self.gr_name)
        self.preprocessing_dir = opj(self.study_dir, 'pre-processing', self.preproc_subdir_name)
        for su in self.list_subjects:
            su.set_study_dir(self.study_dir)

    def set_design(self, design):
        print('No implementation of set_design() for a LongitudinalGroup')

    def set_designs(self, designs):
        """
        Assigns the designs structure to every longitudinal subject of the group
        :param designs:
        :return:
        """
        nd, nt = len(designs), len(self.timepoints)
        if nd != nt:
            sys.exit('Longitudinal group : Please provide as many designs (here : {0}) than timepoints '
                     '(here: {1}).'.format(nd, nt))
        # Assign designs
        self.designs = [read_and_get_design(design) for design in designs]
        self.unique_contrasts = []
        # For every design, edit the contrast name by adding a timepoint prefix
        for d, design in enumerate(self.designs):
            for c, contrast in enumerate(design.get_contrasts()):
                tp = self.timepoints[d]
                contrast.set_name(tp + '_' + contrast.get_name())
                contrast.set_legend('Contrast "{0}"'.format(contrast.title))
                contrast.set_suffix('con_{0}'.format(contrast.get_name().replace('>', '_sup_')))
                self.unique_contrasts.append(contrast)
        # Count number of unique contrasts
        self.nC = len(self.unique_contrasts)
        # Now set the design to every subject of the group
        for long_subject in self.list_subjects:
            long_subject.set_designs(self.designs)
        # Prepare the numpy array
        self.statistical_maps = np.empty((self.nC), dtype=object)

    def check_design(self):
        try:
            self.designs
        except AttributeError:
            sys.exit('Designs are not set for LongitudinalGroup {0}'.format(self.name))

    def get_contrasts(self):
        """
        Here we redefine this method because there are multiple designs (one per timepoint)
        :return:
        """
        return self.unique_contrasts

    def get_statistical_map(self, contrast):
        print('contrast', contrast)
        print([str(c) for c in self.designs[0].get_contrasts()])
        pass

    def get_timepoint_contrast_tuples(self):
        list_con_tp = []
        for timepoint, design in zip(self.timepoints, self.designs):
            for contrast in design.get_contrasts():
                list_con_tp.append((timepoint, contrast))
        return list_con_tp

    def get_contrast_names_with_visits(self):
        con_names_visits = []
        for d, design in enumerate(self.designs):
            for contrast in design.get_contrasts():
                con_names_visits.append(self.timepoints[d] + '_' + contrast.get_suffix())
        return con_names_visits
