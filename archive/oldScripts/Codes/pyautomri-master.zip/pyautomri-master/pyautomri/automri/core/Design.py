"""
    The ``Design`` module
    ======================

    Provides utilities
    -------------------

    Defines a contrast and a 1st level design.
    A User Design File Reader class is created to read and interpret a matlab written user_design_file.m
"""

import sys, re
from os.path import exists as ope
from pyautomri.utils.colors import DEFAULTS_CONTRASTS_PAL

def read_and_get_design(design):
    """
    This simple function provides a tool to read a design whether it is a path to to a user design file
    or a Design1stLevel instance
    :param design:
    :return:
    """
    if isinstance(design, Design1stLevel):
        return design
    elif isinstance(design, str):
        udfr = UserDesignFileReader(ud_file=design)
        # self.design = udfr.get_dictionary()
        return udfr.get_design()
    else:
        print('Unknown type for reading a design : ' + type(design))
        sys.exit('User design must be set with a string (path to user design file) or a Design1stLevel instance')


def get_quote_type_used_in_string(string):
    q1, q2 = "'", '"'
    if q1 in string:
        quote = q1
    elif q2 in string:
        quote = q2
    else:
        sys.exit('Did not find quotes in the following string\n' + string)
    return quote


class Contrast:
    """
    This class defines a SPM contrast
    - a SPM contrast has an index (let's say 1) and a name
    It provides some utilities concerning the retrieval of information
    - .get_contrast_map_basename() -> con_0001.nii
    - .get_statistical_map_basename() -> spmT_0001.nii
    - .get_legend() -> Contrast 0001 "Task vs Rest"
    - .get_suffix() -> "con_0001_task_vs_rest"
    """

    def __init__(self, name, spm_index, color=None):
        """
        Initializes the Contrast
        :param name: str, name
        :param spm_index: int, index associated with the SPM contrast
        :param color: str, matplotlib color
        """
        self.set_name(name=name)
        self.set_spm_index(spm_index=spm_index)
        self.color = color
        # Extra stuff
        self.legend = 'Contrast {0} "{1}"'.format(self.spm_index_str, self.title)
        self.suffix = 'con_{0}_{1}'.format(self.spm_index_str, self.name.replace('>', '_sup_'))

    def set_name(self, name):
        self.name = name
        self.title = self.name.replace('_', ' ')

    def set_spm_index(self, spm_index):
        self.spm_index = spm_index
        self.spm_index_str = str(self.spm_index).zfill(4)

    def __str__(self):
        """
        :return: A string giving the contrast number and the contrast name
        """
        return self.get_legend()

    def get_name(self):
        return self.name

    def get_suffix(self):
        """
        ex: con_0002_task_vs_rest
        :return: A string that can be used as a suffix in a filename
        """
        return self.suffix

    def get_spm_index(self):
        return self.spm_index

    def get_spm_index_str(self):
        return self.spm_index_str

    def get_legend(self):
        """
        ex: Contrast 0002 task vs rest
        :return: A string that can be used as a legend in a graph
        """
        return self.legend

    def set_legend(self, legend):
        self.legend = legend

    def set_suffix(self, suffix):
        self.suffix = suffix

    def get_contrast_map_basename(self):
        """
        :return: the contrast map basename inside a SPM 1st-level subject directory
        """
        return 'con_{0}.nii'.format(self.spm_index_str)

    def get_statistical_map_basename(self):
        """
        :return: the statistical map basename inside a SPM 1st-level subject directory
        """
        return 'spmT_{0}.nii'.format(self.spm_index_str)


class Design1stLevel:
    """
    This class defines an automri 1st level design.
    A design has a name and a list of contrasts.
    """

    def __init__(self, name, contrasts=None):
        """
        Initializes an automri 1st level design with a name (the one specified in the user design file)
        :param name:
        :param contrasts:
        """
        self.name = name
        if contrasts is None:
            contrasts = []
        self.contrasts = contrasts

    def __str__(self):
        """
        Prints the design name and the list of contrasts
        :return:
        """
        msg = 'Design {0} with {1} contrasts\n'.format(self.name, len(self.contrasts))
        for c, contrast in enumerate(self.contrasts):
            msg += '\t- {0}. {1} \n'.format(c+1, contrast)
        return msg

    def get_name(self):
        """
        :return: design name
        """
        return self.name

    def get_contrasts(self):
        return self.contrasts

    def add_contrast(self, contrast):
        """
        Adds a contrast to the list of contrasts
        :param contrast:
        :return:
        """
        self.contrasts.append(contrast)

    def set_list_contrasts(self, list_contrasts):
        """
        Sets a list of contrasts
        :param list_contrasts:
        :return:
        """
        self.contrasts = list_contrasts

    def get_contrast_index(self, contrast):
        """ Retrieve the contrast index by looking correspondance with the contrast names """
        # First get list of contrast names
        con_names = [con.get_name() for con in self.contrasts]
        # Make sure we have a correct contrast
        con_name = self.get_contrast(contrast).get_name()
        return con_names.index(con_name)

    def get_contrast(self, contrast):
        """
        Whether an integer (index), a string (index as a string or contrast name) or a contrast
        :param contrast:
        :return:
        """
        msg = 'Unrecognized contrast : {0} (type = {1})\n'.format(contrast, type(contrast))
        msg += 'Possible contrats for design {0}\n\t'.format(self.name)
        msg += '\n\t'.join(['{0}. {1}'.format(c+1, con.get_name()) for c, con in enumerate(self.contrasts)])
        if isinstance(contrast, int):
            return self.contrasts[contrast-1]
        elif isinstance(contrast, str):
            if contrast.isdigit():
                return self.get_contrast(int(contrast))
            else:
                for c, con in enumerate(self.contrasts):
                    if con.get_name() == contrast:
                        return self.contrasts[c]
        elif isinstance(contrast, Contrast):
            return contrast
        # In any other case
        sys.exit(msg)


class UserDesignFileReader:
    """
    This class builds functions to interpret and extract information from a MATLAB autofmri user design file.
    """

    def __init__(self, ud_file):
        """

        :param ud_file: path to the user design file
        """
        if not ope(ud_file):
            sys.exit('User Design file {0} does not exist'.format(ud_file))
        self.ud_file = ud_file
        self.__read__()
        self.__get_design_name__()
        self.__get_contrasts__()

    def error_message(self, msg):
        """

        :param msg:
        :return:
        """
        msgbeg = 'User Design File Reader crashed\n\t{0}\n'.format(self.ud_file)
        sys.exit(msgbeg + msg)

    def __read__(self):
        """

        :return:
        """
        f = open(self.ud_file, 'r')
        self.text = f.read()
        f = open(self.ud_file, 'r')
        self.lines = f.readlines()

    def __get_design_name__(self):
        """

        :return:
        """
        self.design_name = ''
        a = re.search("design.name.+", self.text)
        if a:
            cleaned_line = a.group().replace(' ', '')
            quote = get_quote_type_used_in_string(cleaned_line)
            # Here we have the quote character
            b = re.search(pattern='{0}.+{0};'.format(quote), string=cleaned_line)
            if b:
                self.design_name = b.group()[1:-2]
            else:
                self.error_message('Did not find the value of the design name')
        else:
            self.error_message('User Design File Reader could not find a line defining a design name')

    def __get_lines_defining_contrasts__(self):
        self.contrast_lines = []
        for line in self.lines:
            if not line.startswith('%'): # Avoid commented lines
                match1 = re.search('c\{[0-9]+\}', line, re.M | re.DOTALL)
                match2 = re.search('design.t_contrasts\{[0-9]+\}', line, re.M | re.DOTALL)
                if match1:
                    self.contrast_lines.append(line)
                else:
                    if match2:
                        self.contrast_lines.append(line)
        if len(self.contrast_lines) == 0:
            self.error_message('Could not find the definition of a single contrast')

    def __get_contrasts__(self):
        self.__get_lines_defining_contrasts__()
        self.con_indices = []
        self.con_names = []
        for con_line in self.contrast_lines:
            a = re.search('\{[0-9]+\}', con_line, re.M | re.DOTALL)
            b = re.search("name.+", con_line, re.M | re.DOTALL)
            if a:
                self.con_indices.append(int(a.group()[1:-1]))
            else:
                self.error_message('Could not find contrast index in line : \n ' + con_line)
            if b:
                i = b.group().index(',')
                rest_line = b.group()[i:]
                quote = get_quote_type_used_in_string(rest_line)
                i0 = rest_line.index(quote)  # Get first quote
                i1 = rest_line[i0 + 1:].index(quote)  # get second quote
                self.con_names.append(rest_line[i0 + 1:i0 + 1 + i1])
            else:
                self.error_message('Could not find contrast name in line : \n ' + con_line)
        if len(self.con_names) != len(self.con_indices):
            self.error_message('Did not find the same number of contrast indices ({0}) and contrast names({1})'.format(
                len(self.con_indices), len(self.con_names)))
        self.n_contrasts = len(self.con_indices)

    def get_sessions(self):
        """

        :return:
        """
        for line in self.lines:
            a = re.search('.sessions\s*={')
            if a:
                print(a.group())
        pass

    def __str__(self):
        """

        :return:
        """
        msg = '----------------------------------------------------\n'
        msg += 'User design file  : ' + self.ud_file + '\n'
        msg += '----------------------------------------------------'
        return msg

    def get_design(self):
        """

        :return: Design
        """
        dfl = Design1stLevel(name=self.design_name)
        for i in range(len(self.con_names)):
            # Create a contrast with contrast name and contrast index, sets DEFAULT COLOR
            contrast = Contrast(name=self.con_names[i], spm_index=self.con_indices[i], color=DEFAULTS_CONTRASTS_PAL[i])
            dfl.add_contrast(contrast=contrast)
        return dfl
