#!/usr/bin/python
from os.path import join as opj, exists as ope
from pyautomri.automri.core.Design import read_and_get_design
from pyautomri.utils.utils import find_nii_or_gz
import sys, glob


class Subject:
    """
    Class that implements an automri subject
    """
    def __init__(self, id):
        """
        :param id: subject identification number (ex : '002' or 'su_002')
        """
        self.id = None
        self.su_id = None
        self.design = None
        self.study_dir = None
        self.result_dir = None
        self.preproc_dir = None
        if id.startswith('su_'):
            id = id[3:]  # Remove the su_ prefix if it was provided
        self.set_id(id)
        self.group = None
        self.nf_normalised_mask = {}

    def __str__(self):
        """

        :return:
        """
        return 'Subject {0} ({1})'.format(self.su_id, self.group)

    def set_id(self, id):
        """
        Sets subject identification
        :param id:
        :return:
        """
        self.id = id
        self.su_id = 'su_' + self.id

    def get_id(self):
        return self.id

    def get_suID(self):
        return self.su_id

    def set_group(self, group):
        """

        :param group:
        :return:
        """
        self.group = group

    def set_design(self, design):
        """

        :param design:
        :return:
        """
        self.design = read_and_get_design(design)

    def get_design(self):
        return self.design

    def set_study_dir(self, study_dir):
        """

        :param study_dir:
        :return:
        """
        self.study_dir = study_dir
        self.result_dir = opj(self.study_dir, 'results', 'functional', self.design.get_name(), '1st_level',
                              self.group.preproc_subdir_name, self.su_id)
        self.preproc_dir = opj(self.study_dir, 'pre-processing', self.group.preproc_subdir_name, self.su_id)

    def check_design(self):
        """

        :return:
        """
        try:
            self.design
        except AttributeError:
            sys.exit('Design is not set for subject'.format(self.su_id))

    def check_study_dir(self):
        """

        :return:
        """
        try:
            self.study_dir
        except AttributeError:
            sys.exit('Study directory is not set for subject'.format(self.su_id))

    def get_beta_map(self, beta_index):
        beta_file = find_nii_or_gz(opj(self.result_dir, 'beta_{0}.nii.gz'.format(str(beta_index).zfill(4))))
        return beta_file

    def get_statistical_map(self, contrast):
        """

        :param contrast: int (contrast number), dict (contrast) or str (contrast name)
        :return:
        """
        self.check_design()
        self.check_study_dir()
        contrast = self.design.get_contrast(contrast=contrast)
        return find_nii_or_gz(opj(self.result_dir, contrast.get_statistical_map_basename()))

    def get_contrasts(self):
        self.check_design()
        return self.design.get_contrasts()

    def get_contrast_map(self, contrast):
        """

        :param contrast:
        :return:
        """
        self.check_design()
        self.check_study_dir()
        return find_nii_or_gz(opj(self.result_dir, contrast.get_contrast_map_basename()), returnSearchedImageFilename=True)

    def get_contrast_maps(self):
        su_con_maps = []
        for contrast in self.design.get_contrasts():
            su_con_maps.append(self.get_contrast_map(contrast=contrast))
        return su_con_maps

    def get_statistical_maps(self):
        su_stat_maps = []
        for contrast in self.design.get_contrasts():
            su_stat_maps.append(self.get_statistical_map(contrast=contrast))
        return su_stat_maps

    def get_normalised_t1_file(self, pattern='wT13D*'):
        """
        Search for the normalised T1 file ("wT13D*" as a pattern) in the pre-processing directory.
        :return:
        """
        err_beg = '{0} crashed for subject {1} ({2}). \n'.format('get_normalised_t1_file()', self.su_id, self.group.name)
        # Define search directory
        search_dir = opj(self.preproc_dir, 'structural', 'norm_spm')
        if not ope(search_dir):
            sys.exit('{0} Directory {1} does not exist !'.format(err_beg, search_dir))
        wt1_files = glob.glob(opj(search_dir, pattern), recursive=False)
        if len(wt1_files)>0:
            return wt1_files[0]
        else:
            sys.exit('{0}No normalised t1 file in directory : \n\t{1}'.format(err_beg, search_dir))

    def set_nf_normalised_mask_for_target(self, nf_wmask, target):
        """
        Set a normalised NF target mask for a target
        :param nf_wmask: normalised NF target mask
        :param target: target name
        :return:
        """
        self.nf_normalised_mask[target] = nf_wmask


# Todo
class LongitudinalSubject:
    def __init__(self, id, groupname, visits):
        """

        :param id:
        :param age:
        :param gender:
        """
        if id.startswith('su_'):
            id = id[3:]  # Remove the su_ prefix if it was provided
        self.set_id(id)
        self.group = groupname
        self.visits = visits
        self.timepoints = [su.get_id().split('_')[-1] for su in self.visits]  # "su_002_S1" or "002_S1" becomes "S1"
        self.n_v = len(self.visits)

    def __str__(self):
        """

        :return:
        """
        return 'Subject {0} (gr {1}) with {2} visits : {3} '.format(self.su_id, self.group, self.n_v, self.timepoints)

    def set_id(self, id):
        """
        Sets subject identification
        :param id:
        :return:
        """
        self.id = id
        self.su_id = 'su_' + self.id

    def get_id(self):
        return self.id

    def get_suID(self):
        return self.su_id

    def get_timepoints(self):
        return self.timepoints

    def set_group(self, group):
        """

        :param group:
        :return:
        """
        self.group = group
        for visit in self.visits:
            visit.set_group(group=self.group)

    def set_study_dir(self, study_dir):
        """

        :param study_dir:
        :return:
        """
        self.study_dir = study_dir
        for visit in self.visits:
            visit.set_study_dir(study_dir)

    def set_designs(self, designs):
        self.designs = [read_and_get_design(design) for design in designs]
        for visit, design in zip(self.visits, self.designs):
            visit.set_design(design=design)

    def get_designs(self):
        return self.designs

    def get_contrast_map(self, contrast, visit_index):
        """

        :param contrast:
        :return:
        """
        return self.visits[visit_index].get_contrast_map(contrast)

    def get_contrast_maps(self):
        """

        :return:
        """
        c_maps = []
        for visit in self.visits:
            c_maps += visit.get_contrast_maps()
        return c_maps

    def get_statistical_map(self, contrast, visit_index):
        return self.visits[visit_index].get_statistical_map(contrast)

    def get_statistical_maps(self):
        """

        :return:
        """
        s_maps = []
        for visit in self.visits:
            s_maps += visit.get_statistical_maps()
        return s_maps

    def get_normalised_t1_files(self):
        normalised_t1_files = []
        for visit in self.visits:
            normalised_t1_files.append(visit.get_normalised_t1_file())
        return normalised_t1_files

    def set_nf_normalised_masks_for_target(self, nf_wmasks, target):
        """
        Sets a list of normalised nf masks to the longitudinal subject
        :param nf_wmasks: list of MNI normalised masks
        :param target: target name
        :return:
        """
        if not isinstance(nf_wmasks, list):
            msg = 'The user must set a list of NF normalised masks for a longitudinal subject ({0}).\n'.format(self.su_id)
            msg += 'Data type "{0}" is not understood'.format(type(nf_wmasks))
            sys.exit()
        if len(nf_wmasks) != len(self.visits):
            msg = 'You are trying to set {0} NF masks for target {1} for subject {2}'.format(len(nf_wmasks), target, self.su_id)
            msg += 'Subject {0} has {1} visits'.format(self.su_id, len(self.visits))
            sys.exit(msg)
        for v, visit in enumerate(self.visits):
            visit.set_nf_normalised_mask_for_target(nf_wmask=nf_wmasks[v], target=target)
