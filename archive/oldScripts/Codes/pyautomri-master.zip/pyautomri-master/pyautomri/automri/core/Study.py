from os.path import join as opj, basename as opb, normpath as opn, exists as ope
import sys, json
from pathlib import Path
from pyautomri.automri.AutofmriStudyAnalyzer import AutofmriStudyAnalyzer
from pyautomri.automri.core.Group import Group
from pyautomri.automri.core.Subject import Subject
from pyautomri.roi.Atlas import CSV2Atlas


# TODO : implement a fully automatic way instance of configuring AutofmriStudyAnalyzer
# TODO : or a fully interactive way -> Study Name ? -> Subjects ? (keyboard inputs)

def assign_dir_if_exists(folder):
    if ope(folder):
        return folder
    else:
        return None


# Path to the Template configuration .json file
TEMPLATE_JSON = opj(Path(__file__).parent.parent.parent.parent, 'resources', 'Template_pyautomri_config.json')
# Mandatory JSON configuration file keys
JK_1_STUDY = 'study'  # Mandatory
JK_1_GROUPS = 'groups'  # Mandatory
JK_1_ANALYSIS = 'Analysis'  # Optional
JK_1_DISPLAY = 'StatisticalMappingDisplayOptions'  # Optional
# Secondary keys for Study
JK_2_ST_NAME = 'name'  # Mandatory
JK_2_ST_DIR = 'dir'  # Mandatory : path to the automri directory
JK_2_ST_DESIGN_NAME = 'design_name'  # Mandatory
# Secondary keys for Groups
JK_2_GR_SUBJECTS = 'subjects'  # Mandatory
JK_2_GR_NAME = 'name'  # Mandatory
JK_2_GR_UD_FILE = 'user_design_file'  # Mandatory
# Secondary keys for Analysis
JK_2_AN_ROI = 'ROI'  # Optional
# Secondary keys for Display
JK_2_DI_Z = 'z'

EXAMPLE_DEF_STUDY = \
    """
    "study":
    {
        "name": "my_original_study",
        "dir" : /path/to/automri_dir/
        "design_name": "design_01"
    }
"""

EXAMPLE_DEF_GROUPS = \
    """
    "groups":
    [
      { "name": "controls", 
      "subjects": ["HC_01", "HC_02", "HC_03", "HC_04"],
        "user_design_file": "relative_path_to/ud_design_01.m"
      },
      {
        "name": "patients",
        "subjects": ["P_01","P_02","P_03","P_04"],
        "user_design_file":"relative_path_to/user_design_d02.m"
      }
    ],
"""

ERROR_RELATIVE_PATHS = \
"""---------------------------------------------------------------------------------
Be careful if you are using relative paths. Double check your configuration file !
---------------------------------------------------------------------------------"""

MSG_JSON_MISSING = \
    """
Please define a few parameters describing your study and your analysis in a .json configuration file.
    - Study Name
    - Groups (and subjects)
    - User design file used
    - Path to the csv file describing the ROI
    
See template json file below to respect the convention
    - {0}
""".format(TEMPLATE_JSON)


def error_missing_file_relative_paths(provided_path, computed_path, json_file):
    print('You provided the following path (1) and pyautomri guessed (2)')
    print('\t(1) ' + provided_path)
    print('\t(2) ' + computed_path)
    print(ERROR_RELATIVE_PATHS)
    print('Edit file : ' + json_file)
    sys.exit()


def error_missing_key_in_json_file(key, json_file):
    msg = '-' * 50 + '\n'
    msg += 'ERROR in your JSON configuration file :\n'
    msg += json_file + '\n'
    msg += 'Mandatory key "{0}" is missing !'.format(key)
    print(msg)


def check_directory_looks_like_an_automri_project_dir(path_dir):
    """
    Check if it is an automri project folder
    :param path_dir: str, directory path
    :return: True, if either subdirectory "data", "pre-processing" or "results" exist
    """
    data_dir = ope(opj(path_dir, 'data'))
    pre_processing_dir = ope(opj(path_dir, 'pre-processing'))
    results_dir = ope(opj(path_dir, 'results'))
    return data_dir or pre_processing_dir or results_dir


class StudyAutomaticConfiguration:
    """
    Class to automatically get information from an automri project given just a path to the folder
    """

    def __init__(self, study_dir):
        self.study_dir = study_dir
        self.automri_dir = None
        self.design_name = None
        self.study_name = None
        self.config_json_file = None
        self.__find_config_file__()
        self.__set_directories__()

    def __set_directories__(self):
        """
        Define subdirectories for an autofmri study directory.
        It is used as a way to inform the user that he/she pointed to a wrong project directory
        (if project/data, project/results project/pre-processing do not exist)
        """
        if not check_directory_looks_like_an_automri_project_dir(self.automri_dir):
            msg = 'Probably not an automri project folder ? \n\t -> ' + self.automri_dir
            sys.exit(msg)
        self.data_dir = assign_dir_if_exists(opj(self.automri_dir, 'data'))
        self.pre_processing_dir = assign_dir_if_exists(opj(self.automri_dir, 'pre-processing'))
        self.results_dir = assign_dir_if_exists(opj(self.automri_dir, 'results'))
        self.user_design_dirs = assign_dir_if_exists(opj(self.automri_dir, 'user_designs'))
        self.rois_dir = assign_dir_if_exists(opj(self.automri_dir, 'config'))  # Look for ROIS_XXX.csv file

    def __find_config_file__(self):
        cfg_file = opj(self.study_dir, 'pyautomri_config.json')
        if ope(cfg_file):
            self.config_json_file = cfg_file
            self.read_json_file()
        else:
            print('ERROR : Could not find a JSON configuration file for project', self.study_name)
            print(MSG_JSON_MISSING)
            sys.exit()

    def __initialize_Study_Analyzer__(self, study_name):
        """
        This is meant to be eventually edited in a child class for very specific configurations
        :return:
        """
        return

    def read_json_file(self):
        """
        Parses the json file and retrieves essential values to configure a study.
        :return:
        """
        with open(self.config_json_file) as json_data_file:
            self.json_data = json.load(json_data_file)

        self.check_mandatory_fields()

        self.asa = AutofmriStudyAnalyzer(study_name=self.study_name, verbose=False)
        self.asa.set_automri_project_dir(self.automri_dir)
        self.asa.set_pyautomri_output_directory(self.study_dir)
        self.asa.set_design_name(self.design_name)
        # This is not done yet. Dissociate output directory from study directory
        # todo : self.asa.set_output_directory(self.study_dir)
        self.setup_groups()
        self.setup_analysis()
        self.setup_display()

    def check_mandatory_fields(self):
        # Check mandatory keys first
        l_keys = self.json_data.keys()
        if not JK_1_STUDY in l_keys:
            error_missing_key_in_json_file(JK_1_STUDY, self.config_json_file)
            print('You must define a Study.')
            print('Follow this example : ')
            print(EXAMPLE_DEF_STUDY)
            sys.exit()
        if not JK_1_GROUPS in l_keys:
            error_missing_key_in_json_file(JK_1_GROUPS, self.config_json_file)
            print('You must define at least one group.')
            print('Follow this example : ')
            print(EXAMPLE_DEF_GROUPS)
            sys.exit()
        # Set intermediate values
        if JK_2_ST_DIR in self.json_data[JK_1_STUDY].keys():
            self.automri_dir = self.json_data[JK_1_STUDY][JK_2_ST_DIR]
        else:
            print('No attribute "dir" setup in the json file. Default json directory is used.')
            self.automri_dir = self.study_dir
        self.study_name = self.json_data[JK_1_STUDY][JK_2_ST_NAME]
        self.design_name = self.json_data[JK_1_STUDY][JK_2_ST_DESIGN_NAME]

    def setup_groups(self):
        """
        Setup the groups
        :return:
        """
        groups = []
        for json_group in self.json_data[JK_1_GROUPS]:
            # Define a list of Subject instances
            list_subjects = [Subject(id=su) for su in json_group[JK_2_GR_SUBJECTS]]
            group = Group(json_group[JK_2_GR_NAME], list_subjects=list_subjects)
            ud_file = opj(self.automri_dir, json_group[JK_2_GR_UD_FILE])
            if not ope(ud_file):
                print('Could not find the provided user design file.')
                error_missing_file_relative_paths(provided_path=json_group[JK_2_GR_UD_FILE],
                                                  computed_path=ud_file, json_file=self.config_json_file)
            group.set_design(json_group[JK_2_GR_UD_FILE])
            groups.append(group)
        self.asa.set_groups(groups)

    def setup_analysis(self):
        """
        Setup the analysis part
        :return:
        """
        if JK_1_ANALYSIS in self.json_data.keys():
            if JK_2_AN_ROI in self.json_data[JK_1_ANALYSIS].keys():
                rel_path = self.json_data[JK_1_ANALYSIS][JK_2_AN_ROI]
                # Go relative path
                possible_abs_path = opj(self.automri_dir, rel_path)
                if not ope(possible_abs_path):
                    print('Could not find the ROI analysis csv file.')
                    error_missing_file_relative_paths(provided_path=rel_path,
                        computed_path=possible_abs_path, json_file=self.config_json_file)
                csv2atlas = CSV2Atlas(csv_file=possible_abs_path)
                self.asa.set_atlas_for_roi_analysis(csv2atlas.get_atlas())

    def setup_display(self):
        if JK_1_DISPLAY in self.json_data.keys():
            if JK_2_DI_Z in self.json_data[JK_1_DISPLAY].keys():
                self.asa.set_z_slices_for_activation_plots(z_slices=self.json_data[JK_1_DISPLAY][JK_2_DI_Z])

    def get_configured_study(self):
        return self.asa
