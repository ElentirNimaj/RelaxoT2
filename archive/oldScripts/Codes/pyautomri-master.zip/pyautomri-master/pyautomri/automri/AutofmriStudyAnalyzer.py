import os, sys
import numpy as np
import nibabel as nib
from os.path import join as opj, exists as ope, basename as opb
import time
import pandas as pd
import nilearn

import pyautomri.automri.core.Subject
from pyautomri.automri.core.Group import Group
from pyautomri.automri.core.Subject import LongitudinalSubject
from pyautomri.stat.StatFunctions import SecondLevelAnalysis
from pyautomri.stat.CorrectionStatisticalMaps import CORR_2, CORR_3, Correction
from pyautomri.plot.StatisticalMapping import DEFAULT_Z_SLICES, MontageActivationPlots, \
    MontageCheckerboardMapsAs2DArrayOneSlice, MosaicActivationMap, DEFAULT_MOSAIC_PARAMETERS, MontageCheckerboardMapsAs1DArrayMultipleSlices
from pyautomri.utils.utils import find_nii_or_gz, create_dir, create_dirs, list_of_files_exist_print_missing, convert_duration_to_nice_duration_string
from pyautomri.report.LatexReports import LatexDocumentReport
from pyautomri.roi.Atlas import ROIAtlas
from pyautomri.roi.Analyzer import ROIAnalyzer


K_VIEW_DM = 'display_mode'
K_VIEW_CC = 'cut_coords'

CORR_SM_0 = Correction(alpha=1, height_control='fpr')
CORR_SM_1 = Correction(alpha=0.005, height_control='fpr', k=50)
CORR_SM_2 = Correction(alpha=0.001, height_control='fpr', k=0)
CORR_SM_3 = Correction(alpha=0.05, height_control='fwe', k=0)
DEFAULT_STAT_MAP_CORRS = [CORR_SM_0, CORR_SM_1, CORR_SM_2, CORR_SM_3]


class AutofmriStudyAnalyzer:
    """
    Class allowing to manipulate results from an autofmri results directory
    """

    def __init__(self, study_name, verbose=True):
        """
        Init function
        :param study_name: name of the study
        :type study_name: str
        :param verbose: allows to print information regarding the processing of the data
        :type: bool
        """
        self.name = study_name
        self.verbose = verbose
        self.set_default_values()

    def set_default_values(self):
        """
        Initial default values
        :return:
        """
        self.__set_print_options__()
        self.__set_default_group_values__()
        self.__set_default_reporting_parameters__()
        self.__set_default_roi_atlas_values__()
        self.__set_default_stat_maps_values__()
        self.__set_default_output_subdirectory_name__()

    def __set_print_options__(self):
        self.sa = '--- StudyAnalyzer ' + '(' + self.name + ') --- '

    def __set_default_group_values__(self):
        """

        :return:
        """
        self.nG = 0  # number of groups
        self.groups = []  # list of Group instances
        self.n_con_per_group = []  # Number of contrasts per groups
        # Structure to store all subject ids
        self.all_subject_id = []
        self.all_subject_gr = []
        self.all_subjects = [self.all_subject_id, self.all_subject_gr]

    def __set_default_stat_maps_values__(self):
        """

        :return:
        """
        self.ind_stat_maps = []  # Paths to the individual statistical maps
        self.ind_con_maps = []  # Paths to the individual contrast maps
        self.second_level_analyses = []  # Second Level Analyses instances (with Nilearn)
        self.grp_stat_maps = []  # Paths to the group statistical maps

    def __set_default_reporting_parameters__(self):
        """

        :return:
        """
        self.z_slices = DEFAULT_Z_SLICES  # When creating montage of activation maps, select z slices to plot
        self.grp_stat_map_list_corrections = [CORR_SM_2, CORR_SM_3]  # Default correction methods for group statistical maps
        self.ind_stat_map_list_corrections = [CORR_SM_1, CORR_SM_2]  # Default correction methods for individual statistical maps
        self.mosaic_parameters = DEFAULT_MOSAIC_PARAMETERS

    def __set_default_roi_atlas_values__(self):
        self.roi_atlas_set = False  # Check whether a ROI atlas was set
        self.roi_atlas = None  # ROIAtlas instance, used for ROI analysis and some statistical maps
        self.roi_atlas_for_stat_maps = None  # ROIAtlas instance, used to display on statistical maps
        self.list_roi_atlases = []
        self.use_spm_2nd_level_maps = True  # By default, use autofmri generated second level statistical maps

    def __set_default_output_subdirectory_name__(self):
        self.output_subdir = 'autofmri_analysis_dir'

    def __str__(self):
        """
        Implements the print function
        #todo : better looking implementation please
        """
        tab = '    |'
        text = '\n'
        text = text + tab + self.sa + '\n'
        text = text + tab + ' {0} Group(s) : \n'.format(self.nG)
        for g, gr in enumerate(self.groups):
            text = text + tab + tab[:-1] + ' - ' + gr.name + ' (' + str(gr.nS) + ' subjects) - ' + gr.get_design().get_name() \
                   + ' ({0} contrasts)'.format(self.n_con_per_group[g]) + '\n'
        text = text + tab + ' {0} p-values : {1}\n'.format(len(self.grp_stat_map_list_corrections),
                                                           [str(t) for t in self.grp_stat_map_list_corrections])
        try:
            text = text + tab + ' ROI dictionary : ' + self.roi_atlas.get_atlas_name() + ' ({0} ROIs)'.format(
                self.nR) + '\n'
            for r, roi in enumerate(self.roi_atlas.get_list_rois()):
                text = text + tab + tab[:-1] + ' - roi #{0} : {1} \n'.format(str(r + 1).zfill(2), roi.get_name())
        except AttributeError:
            pass
        return text

    def print(self, msg, force=False):
        """
        Method to print information regarding the performed analyses
        :param msg:
        :param force:
        :return:
        """
        if self.verbose or force:
            print(self.sa + msg)

    def set_automri_project_dir(self, dir):
        """
        Sets the path to the project directory
        :param dir: path to the project directory
        :type dir: str
        :return:
        """
        self.automri_project_dir = dir
        self.data_dir = opj(self.automri_project_dir, 'data')
        self.onsets_dir = opj(self.automri_project_dir, 'onsets')
        self.preprocessing_dir = opj(self.automri_project_dir, 'pre-processing')
        self.results_dir = opj(self.automri_project_dir, 'results')
        # Default output directory is set here : at the root folder
        self.set_pyautomri_output_directory(self.automri_project_dir)
        self.print('working directory : ' + self.automri_project_dir)

    def set_output_subdirectory_name(self, subdir_name):
        self.output_subdir = subdir_name

    def set_pyautomri_output_directory(self, out_dir):
        """
        Provide the user the possibility to dissociate automri project location and pyautomri results location
        :param out_dir: str, path to a directory
        :return:
        """
        self.pyautomri_output_dir = create_dir(opj(out_dir, self.output_subdir))

    def set_design_name(self, design_name):
        """
        Sets the design name, influences output results filenames
        :param design_name: Design name
        :type design_name: str
        :return:
        """
        self.design_name = design_name
        self.pyautomri_output_dir = create_dir(opj(self.pyautomri_output_dir, self.design_name))

    def add_group(self, group):
        """
        Adds an instance of the 'Group' class to the current analyzer
        :param group:
        :type group: Group
        :return:
        """
        try:
            self.automri_project_dir
        except AttributeError:
            sys.exit(
                '"self.automri_project_dir" attribute is not defined for the study {0}.\nPlease use set_directory() before add_group()'.format(
                    self.name))
        group.set_study_dir(self.automri_project_dir)
        self.groups.append(group)
        self.nG += 1
        self.n_con_per_group.append(len(group.get_contrasts()))
        for su in group.get_list_subject_ids():
            self.all_subject_id.append(su)
            self.all_subject_gr.append(group.name)
        self.print('group {0} added ({1} subjects)'.format(group.name, len(group.list_subjects)))

    def set_groups(self, list_groups):
        """
        Sets a list of groups, for each group calls the function add_group
        :param list_groups: list of groups
        """
        for group in list_groups:
            self.add_group(group=group)

    def set_z_slices_for_activation_plots(self, z_slices):
        """
        Define a list of coordinates to pass to activation plots instances
        :param z_slices: list of z coordinates
        """
        self.z_slices = z_slices

    def set_group_stat_map_corrections(self, corrections):
        """
        Defines a list of p-values for which Activation plot should be performed
        :param corrections: list of float p-values
        :type:list
        :return:
        """
        for correction in corrections:
            if not isinstance(correction, Correction):
                sys.exit('You must provide a Correction instance when setting statistical map Thresholds.')
        self.grp_stat_map_list_corrections = corrections

    def set_mosaic_parameters(self, mosaic_parameters):
        self.mosaic_parameters = mosaic_parameters

    def set_compute_second_level_maps_with_nilearn(self):
        """

        :return:
        """
        self.use_spm_2nd_level_maps = False

    def set_atlas_for_roi_analysis(self, atlas: ROIAtlas):
        """
        Adds a roi dictionary structure to the Study Analyzer to perform ROI analyses or add ROIs to some plots
        :param atlas: ROIAtlas
        :return:
        """
        self.roi_atlas = atlas
        self.roi_atlas.check()
        self.nR = len(self.roi_atlas.get_list_rois())
        roi_names = [roi.get_name() for roi in self.roi_atlas.get_list_rois()]
        self.print('ROIAtlas {0} added ({1} ROIs : {2})'.format(atlas.get_atlas_name(), self.nR, roi_names))
        self.roi_atlas_set = True
        self.roi_atlas_for_stat_maps = self.roi_atlas

    def set_roi_atlas_for_statistical_maps(self, roi_atlas):
        """
        :param roi_atlas:
        :return:
        """
        self.roi_atlas_for_stat_maps = roi_atlas

    def set_list_roi_atlases(self, list_roi_atlases):
        self.list_roi_atlases = list_roi_atlases

    # ======== Functions to check whether autofmristudyanalyzer is well set before being executed ========
    def __check_settings__(self):
        """
        Function that can be used prior to running an analysis to check mandatory attributes are set.
        """
        err_msg = '==== ERRROR /!\ misconfiguration of the AutofmriStudyAnalyzer ====\n'
        print_msg = False
        if not hasattr(self, 'design_name'):
            err_msg += "Attribute 'design_name' (str) was not set. Use set_design_name() function \n"
            print_msg = True
        if not hasattr(self, 'automri_project_dir'):
            err_msg += "Attribute 'automri_project_dir' (str) was not set. Use set_automri_project_dir() function \n"
            print_msg = True
        if len(self.groups) == 0:
            err_msg += "Attribute 'groups' (list of Groups) contains 0 group. Add at least one Group using add_group() function."
            print_msg = True
        if print_msg:
            sys.exit(err_msg)

    def __check_atlas__(self):
        try:
            self.roi_atlas
        except AttributeError:
            sys.exit('Can not load a ROI Atlas. Use "set_atlas(atlas=)" to be able to use ROI Analysis.')

    # ---------------- Definition of some getters ----------------------
    def get_number_of_groups(self):
        """
        :return: int, number of groups added to the Study Analyzer
        """
        return self.nG

    def get_groups(self):
        """
        :return: list of groups that have been added to the StudyAnalyzer
        """
        return self.groups

    def get_subjects(self, group_index):
        return self.groups[group_index].get_list_subjects()

    def get_group(self, group):
        """
        :param group: int, group index to retrieve
        :return: instance of Group
        """
        if isinstance(group, int):
            if group < self.nG:
                return self.groups[group]
            else:
                self.print('Unable to retrieve group number {0}. Only {1} group.'.format(self.nG + 1, self.nG),
                           force=True)
                return None
        elif isinstance(group, str):
            gr_names = [gr.name for gr in self.groups]
            if group in gr_names:
                return self.groups[gr_names.index(group)]
        elif isinstance(group, Group):
            if group in self.groups:
                return group
            else:
                sys.exit('Group {0} is not set to this study'.format(group))
        else:
            sys.exit('Unknown type ({0}) for Group {1}'.format(type(group), str(group)))

    def get_subject_index_and_group_index(self, su):
        (subject, group) = self.get_subject_and_group(su)
        gr_index = self.groups.index(group)
        su_index = group.get_list_subject_ids().index(subject.su_id)
        return gr_index, su_index

    def get_subject_and_group(self, subject):
        """
        Given a subject instance, find to which group this subject belongs to
        :param subject:
        :return: (subject, group) instances
        """
        if isinstance(subject, str):
            if subject.isdigit():
                # TODO very dangerous because '002' comes back as 2 into the function and is interpreted as an index
                return self.get_subject_and_group(subject=int(subject))
            else:
                # then the subject string is an ID
                if subject in self.all_subject_id:
                    su_idx = self.all_subject_id.index(subject)
                    return self.get_subject_and_group(subject=su_idx)
                else:
                    list_subjects = '\n\t'.join(['{0}. {1}'.format(i, su) for i,su in enumerate(self.all_subject_id)])
                    sys.exit('Unrecognized subject ID : {0}. Choose among the following list : {1}'.format(subject, list_subjects))
        elif isinstance(subject, int):
            if subject > len(self.all_subject_id):
                sys.exit('You chose a subject index ({0}) > number of subjects ({1})'.format(subject, len(self.all_subject_id)))
            su_index = subject  #
            # Here we have checked and defined the subject ID
            su = self.all_subject_id[su_index]
            gr = self.all_subject_gr[su_index]
            # Retrieve the Group and Subject instances
            group = self.get_group(gr)
            subject = group.get_subject(subject=su)
            return (subject, group)
        elif isinstance(subject, pyautomri.automri.core.Subject.Subject):
            return (subject, subject.group)
        elif hasattr(subject, 'group'):
            return (subject, subject.group)
        else:
            sys.exit('Unknown type ({0}) for Subject {1}'.format(type(subject), str(subject)))

    def get_atlas(self):
        self.__check_atlas__()
        return self.roi_atlas

    def get_activations_dir(self):
        """
        :return: out_dir/"Activations"
        """
        return create_dir(opj(self.pyautomri_output_dir, 'Activations'))

    def get_roi_analysis_dir(self):
        """

        :return:
        """
        d = create_dir(opj(self.pyautomri_output_dir, 'Analysis_ROI'))
        return create_dir(opj(d, self.roi_atlas.get_atlas_name()))

    def get_second_level_directory(self):
        """
        :return: out_dir/"SecondLevelAnalyses"
        """
        return create_dir(opj(self.pyautomri_output_dir, 'Analysis_2nd_level'))

    def get_individual_statistical_map(self, subject, contrast):
        """

        :param subject:
        :param contrast:
        :return:
        """
        self.__find_autofmri_individual_statistical_maps__()
        gr_index, su_index = self.get_subject_index_and_group_index(subject)
        con_index = self.groups[gr_index].get_contrast_index(contrast)
        return self.ind_stat_maps[gr_index][su_index, con_index]

    def get_individual_contrast_map(self, subject, contrast):
        self.__find_autofmri_individual_contrast_maps__()
        gr_index, su_index = self.get_subject_index_and_group_index(subject)
        con_index = self.groups[gr_index].get_contrast_index(contrast)
        return self.ind_con_maps[gr_index][su_index, con_index]

    def get_individual_contrast_maps(self, group_index, contrast):
        """Returns all individual contrast maps of a single group and a defined contrast"""
        group = self.groups[group_index]
        self.__find_autofmri_individual_contrast_maps__()
        con_index = group.get_contrast_index(contrast)
        return self.ind_con_maps[group_index][:, con_index]

    def get_group_statistical_map(self, gr_index, con_index):
        if hasattr(self, 'grp_stat_maps'):
            if gr_index < self.nG:
                group = self.groups[gr_index]  # Group
                nC = self.n_con_per_group[gr_index]
                if con_index < group.get_num_contrasts():
                    con_name = group.get_contrast_names()[con_index]
                    return self.grp_stat_maps[gr_index][con_index]
                else:
                    sys.exit('Contrast index ({0}) > num contrasts ({1})'.format(con_index, nC))
            else:
                sys.exit('Group index ({0}) >  num groups ({1})'.format(gr_index, self.nG))
        else:
            sys.exit('Error : group level statistical maps do net exist yet. Perform second level analysis.')

    # ---------------- Implementation of functions to define statistical and contrast maps ----------------------
    def __find_maps__(self):
        """
        Check whether data structures are well loaded
        :return:
        """
        self.__find_autofmri_contrast_maps__()
        self.__find_autofmri_statistical_maps__()

    def __find_autofmri_contrast_maps__(self):
        """
        Assign contrast maps to data structures
        :return:
        """
        try:
            self.ind_con_maps
        except AttributeError:
            self.__find_autofmri_individual_contrast_maps__()

    def __find_autofmri_statistical_maps__(self):
        """
        Assign statistical maps to data structures
        :return:
        """
        self.__find_autofmri_individual_statistical_maps__()
        self.__find_group_statistical_maps__()

    def __find_group_statistical_maps__(self):
        if self.use_spm_2nd_level_maps:
            self.__find_autofmri_group_statistical_maps__()
        else:
            self.perform_second_level_analyses()

    def __find_group_maps__(self):
        """
        Check group maps only
        :return:
        """
        self.__find_group_statistical_maps__()

    def __find__individual_maps__(self):
        """
        Checks individual contrast and statistical maps
        :return:
        """
        self.__find_autofmri_individual_contrast_maps__()
        self.__find_autofmri_individual_statistical_maps__()

    def __find_autofmri_individual_statistical_maps__(self):
        """
        A list of numpy 2D-vector-arrays (shape: number of subjects x number of contrasts in the group design)
        containing path to the subjects statistical maps is filled
        """
        self.__check_settings__()
        if not self.ind_stat_maps:
            for g, gr in enumerate(self.groups):
                self.ind_stat_maps.append(np.empty(shape=(gr.nS, gr.get_num_contrasts()), dtype=object))
                for s, su in enumerate(gr.get_list_subjects()):
                    for c, contrast in enumerate(gr.get_contrasts()):
                        cmap = find_nii_or_gz(su.get_statistical_map(contrast), returnSearchedImageFilename=True)
                        self.ind_stat_maps[g][s, c] = cmap
                msg = self.sa + 'Individual statistical maps from gr {0}'.format(gr.name)
                list_of_files_exist_print_missing(list(self.ind_stat_maps[g].flatten()), msg=msg,
                                                  verbose=self.verbose)

    def __find_autofmri_individual_contrast_maps__(self):
        """
        A list of numpy 2D-vector-arrays (shape: number of subjects x number of contrasts in the group design)
        containing path to the subjects contrast maps is filled
        """
        self.__check_settings__()
        if not self.ind_con_maps:
            for g, gr in enumerate(self.groups):
                self.ind_con_maps.append(np.empty(shape=(gr.nS, gr.get_num_contrasts()), dtype=object))
                for s, su in enumerate(gr.get_list_subjects()):
                    for c, contrast in enumerate(gr.get_contrasts()):
                        cmap = find_nii_or_gz(su.get_contrast_map(contrast), returnSearchedImageFilename=True)
                        self.ind_con_maps[g][s, c] = find_nii_or_gz(cmap)
                msg = self.sa + 'Individual contrast maps from gr {0}'.format(gr.name)
                list_of_files_exist_print_missing(list(self.ind_con_maps[g].flatten()), msg=msg,
                                                  verbose=self.verbose)

    def __find_autofmri_group_statistical_maps__(self):
        """
        A list of numpy 1D-vector-arrays (length : number of contrasts in the group design) containing path to the group
        statistical maps is filled
        """
        self.__check_settings__()
        try:
            self.grp_stat_maps
        except AttributeError:
            self.grp_stat_maps = []
            self.print('Finding 2nd level autofmri maps')
            for g, gr in enumerate(self.groups):
                self.grp_stat_maps.append(np.empty(shape=(gr.get_num_contrasts()), dtype=object))
                for c, contrast in enumerate(gr.get_contrasts()):
                    self.grp_stat_maps[g][c] = gr.get_statistical_map(contrast)
                msg = self.sa + 'Group statistical maps from gr {0}'.format(gr.name)
                list_of_files_exist_print_missing(list(self.grp_stat_maps[g].flatten()), msg=msg,
                                                  verbose=self.verbose)

        # =========== Other actions ==================

    def perform_second_level_analyses(self):
        """
        When second level analyses were not performed with autofmri, this function allows to calculate second level
        group statistical maps provided that 1st level contrast maps were already calculated with autofmri
        :return:
        """
        # Creates the Second Level Analyses instances
        self.setup_second_level_analyses()
        # print(self.get_individual_contrast_maps(group_index=0, contrast=3))
        # print()
        # print()
        # print(self.get_individual_contrast_maps(group_index=1, contrast=3))
        # sys.exit()
        if not self.check_second_level_maps_exist():
            self.compute_second_level_statistical_maps()
        self.__initialize_cluster_reporting__()  # Initialize some values if the user wants to report clusters

    def check_second_level_maps_exist(self):
        l_f = []
        for g in range(self.nG):
            l_f += list(self.grp_stat_maps[g].flatten())
        return all(ope(f) for f in l_f)

    def setup_second_level_analyses(self):
        """
        Set up second level analyses
        For each group, for each contrast, perform a simple second level analysis
        :return:
        """
        self.__find_autofmri_individual_contrast_maps__()
        # Save instances of second level analyses and group statistical maps
        for g, gr in enumerate(self.groups):
            self.second_level_analyses.append(np.empty(shape=(self.n_con_per_group[g]), dtype=object))
            self.grp_stat_maps.append(np.empty(shape=(gr.get_num_contrasts()), dtype=object))
            gr_dir = create_dir(opj(self.get_second_level_directory(), gr.get_dirname()))
            for c, contrast in enumerate(gr.get_design().get_contrasts()):
                # Get the individual contrast maps
                con_maps = list(self.ind_con_maps[g][:, c])
                # Define an output basename
                # Subdirectory with contrast name "gr_gr1/gr_gr1_con_0001_TASK"
                sla_dir = create_dir(opj(gr_dir, '_'.join([gr.get_dirname(), contrast.get_suffix()])))
                basename = '_'.join([gr.get_name(), contrast.get_suffix()])
                # Setup a "second level analysis" instance
                sla = SecondLevelAnalysis(contrast_maps=con_maps, output_dir=sla_dir)
                sla.set_output_statistical_map_basename(basename=basename)
                # Save instance into list of np arrays
                self.second_level_analyses[g][c] = sla
                # Define the group statistical map filename
                self.grp_stat_maps[g][c] = sla.get_statistical_map()
                # Set the statistical map to the group instance (in case previously calculated)
                if ope(self.grp_stat_maps[g][c]):
                    self.groups[g].set_statistical_map(contrast=contrast, stat_map=self.grp_stat_maps[g][c])

    def compute_second_level_statistical_maps(self):
        """

        :return:
        """
        self.print('Performing Second Level Analyses with Nilearn', force=True)
        for g, gr in enumerate(self.groups):
            for c, contrast in enumerate(gr.get_contrasts()):
                if not ope(self.grp_stat_maps[g][c]):
                    msg = '\tGr {0} Con {1}'.format(gr.get_name(), contrast.get_legend())
                    self.second_level_analyses[g][c].compute_statistical_map(msg_to_print=msg)
                    # Set the statistical map to the group instance
                    self.groups[g].set_statistical_map(contrast=contrast, stat_map=self.grp_stat_maps[g][c])

    def get_group_subject_contrast(self, group, subject, contrast):
        """

        :param group:
        :param subject:
        :param contrast:
        :return:
        """
        # group = self.get_group(group)
        self.get_subject_index_and_group_index(su=subject)
        self.get_individual_statistical_map(subject, contrast)

    # -------------------------------- Cluster Analyses --------------------------------------
    def __initialize_cluster_reporting__(self):
        """

        :return:
        """
        self.corrections_cluster_table = [CORR_2, CORR_3]
        # For symbolic linking
        self.cluster_reporting_symdir = create_dir(opj(self.get_activations_dir(), '2nd_level_clusters'))
        # Cluter reporters
        self.cluster_csv_files = []
        for g, group in enumerate(self.groups):
            nC = group.get_num_contrasts()
            nT = len(self.corrections_cluster_table)
            self.cluster_csv_files.append(np.empty(shape=(nC, nT), dtype=object))

    def report_cluster_tables(self, list_contrasts=None):
        self.__initialize_cluster_reporting__()
        self.print('Reporting clusters to CSV files ...', force=True)
        for g, group in enumerate(self.groups):
            if not list_contrasts:
                list_contrasts = group.get_contrasts()
            for contrast in list_contrasts:
                #TODO: check this
                # c = group.get_contrast_index(contrast)
                c = group.get_design().get_contrast_index(contrast)
                sla = self.second_level_analyses[g][c]
                for ct, correction in enumerate(self.corrections_cluster_table):
                    # Get CSV file
                    sla.export_clusters_tables(correction=correction)
                    self.cluster_csv_files[g][c, ct] = sla.get_clusters_table_csv_filename(correction=correction)
                    # # Symbolic linking
                    out_dir = create_dirs(opj(self.cluster_reporting_symdir, 'clusters_tables', correction.get_suffix()))
                    symlink = opj(out_dir, '_'.join([contrast.get_suffix(), correction.get_suffix()]) + '.csv')
                    if not ope(symlink):
                        os.symlink(src=self.cluster_csv_files[g][c, ct], dst=symlink)

    def perform_cluster_plots(self, list_contrast_indices=None):
        """
        :param list_contrast_indices: Contrast indices
        :return:
        """
        for g, group in enumerate(self.groups):
            list_contrasts = group.get_contrasts()
            if list_contrast_indices:
                list_contrasts = [list_contrasts[i] for i in list_contrast_indices]
            self.print('Running Cluster Plots for Group {0} with {1} contrasts'.format(group.name, len(list_contrast_indices)),
                       force=True)
            for contrast in list_contrasts:
                # Get contrast index in the contrast list
                c = group.get_contrast_index(contrast)
                g = self.groups.index(group)
                # Retrieve instance of Second Level Analysis
                sla = self.second_level_analyses[g][c]
                for c, correction in enumerate(self.corrections_cluster_table):
                    # Filenaming
                    fig_suffix = '_'.join([group.name, contrast.get_suffix(), correction.get_suffix()])
                    sla.plot_clusters(correction=correction, fig_suffix=fig_suffix)

    # ------------------- Perform some checking plots ------------------------------
    def run_check_contrast_plots(self, z_slice=60):
        self.print('Run Check Contrast Plots module', force=True)
        self.check_dir = create_dir(opj(self.pyautomri_output_dir, 'check'))
        self.__find_autofmri_individual_contrast_maps__()
        self.__create_montage_individual_contrast_plots__(z_slice=z_slice)

    def __create_montage_individual_contrast_plots__(self, z_slice=60):
        for g, gr in enumerate(self.groups):
            out_file = opj(self.check_dir, 'montage_contrasts_plot_gr_{0}.png'.format(gr.name))
            if not ope(out_file):
                l_con = gr.get_design().get_contrasts()
                l_sub = gr.get_list_subject_ids()
                self.print(
                    'Creating 2D array {1} subjects X {2} contrasts plot for group {0},'.format(gr.name, len(l_sub),
                                                                                                len(l_con)), force=True)
                mcma2aos = MontageCheckerboardMapsAs2DArrayOneSlice(input_images=self.ind_con_maps[g],
                                                                    output_file=out_file)
                mcma2aos.set_vmax(2.5)
                mcma2aos.set_z_slice(z_slice=z_slice)
                mcma2aos.set_montage_title(gr.name)
                mcma2aos.set_threshold(threshold=0)
                mcma2aos.set_column_titles([con.get_name() for con in l_con])
                mcma2aos.set_row_titles(l_sub)
                mcma2aos.plot()

    # ---------------- Implementation of Statistical Maps plotting functions----------------------
    def plot_group_statistical_maps(self):
        """
        For each group, contrast, threshold, create a Mosaic plot that is stored in the Second level analysis output
        folder. A symbolic link in the activations directory is created.
        """
        for g, group in enumerate(self.groups):
            for c, contrast in enumerate(group.get_contrasts()):
                sla = self.second_level_analyses[g][c]
                for threshold in self.grp_stat_map_list_corrections:
                    group_info = 'Group {0} ({1} subjects)'.format(group.get_name(), group.nS)
                    title = '{0}. {1}, {2}'.format(contrast.get_legend(), group_info, threshold)
                    png_map = sla.plot_stat_map(correction=threshold, title=title,
                                                mosaic_parameters=self.mosaic_parameters,
                                                atlas=self.roi_atlas_for_stat_maps)
                    # Create symlink
                    symdir = create_dirs(opj(self.get_activations_dir(), '2nd_level_maps',
                                             group.get_dirname(), threshold.get_suffix()))
                    symlink = opj(symdir, opb(png_map))
                    if not ope(symlink):
                        os.symlink(src=png_map, dst=symlink)

    def plot_montage_group_statistical_maps_compare_contrasts(self):
        """
        Creates a Vertical Montage comparing the different contrasts within each group.
        For each contrast, an activation plot with several Z slices is performed.
        These maps are stacked vertically so that within-group-different-contrast maps can be compared within the blink
        of an eye
        :return:
        """
        for g, gr in enumerate(self.groups):
            self.print('Creating Montage Group {0} Statistical Maps all contrasts'.format(gr.name))
            for corr in self.grp_stat_map_list_corrections:
                gr_s, thr_s = gr.get_dirname(), corr.get_suffix()
                out_dir = create_dirs(opj(self.get_activations_dir(), '2nd_level_maps', gr_s, thr_s))
                png_map = opj(out_dir, 'Montage_{0}_all_contrasts_{1}.png'.format(gr_s, thr_s))
                if not ope(png_map):
                    stat_files = list(self.grp_stat_maps[g])
                    map = MontageActivationPlots(stat_maps=stat_files, output_montage_file=png_map)
                    map.set_correction(correction=corr)
                    map.set_cut_coords(cut_coords=self.z_slices)
                    map.set_colorbar(True)
                    map.set_titles([contrast.get_legend() for contrast in gr.get_contrasts()])
                    title = '{0} - Design {1} - Group {2} ({3}) {4}'.format(self.name, gr.get_design().get_name(),
                                                                            gr.name.upper(), gr.nS, corr)
                    map.set_montage_title(montage_title=title)
                    if self.roi_atlas_for_stat_maps:
                        map.set_atlas(atlas=self.roi_atlas_for_stat_maps)
                    map.plot()

    def plot_all_individual_statistical_maps(self, correction=CORR_SM_2):
        """
        Calls individual plots subfunctions to save every statistical map of every subject
        """
        self.__find__individual_maps__()
        for g, gr in enumerate(self.groups):
            for s, su in enumerate(gr.get_list_subjects()):
                for c, contrast in enumerate(gr.get_contrasts()):
                    self.plot_individual_statistical_map(subject=su, contrast=contrast, correction=correction)

    def plot_individual_statistical_map(self, subject, contrast, correction=CORR_SM_2):
        """
        Perform a mosaic plot for a subject, statistical map associated to the contrast provided, with a threshold.
        :param subject: str, int or Subject. Something that identifies the subject
        :param contrast: str, int or Contrast. Something that helps identifying the contrast.
        :param correction: Threshold. By default (p<0.001 fpr)
        :return:
        """
        subject, grp = self.get_subject_and_group(subject)
        contrast = grp.get_contrast(contrast)
        stat_map = self.get_individual_statistical_map(subject=subject, contrast=contrast)
        # Recurrent information
        suid, grd, grn, = subject.get_suID(), grp.get_dirname(), grp.name
        thr_str, thr_sfx = str(correction), correction.get_suffix()
        # Prepare output directory
        out_dir = create_dirs(opj(self.get_activations_dir(), '1st_level_maps', grd, suid))
        # Output filename
        basename = '_'.join([suid, contrast.get_suffix(), thr_sfx]) + '.png'
        out_file = opj(out_dir, basename)
        if not ope(out_file):
            title = '{0} ({1}) {2} {3}'.format(suid, grp.name, contrast.get_legend(), thr_str)
            # Threshold statistical map
            thr_map, thr_val = correction.compute_threshold(stat_map=stat_map)
            # Make the Mosaic plot
            mam = MosaicActivationMap(stat_map=thr_map, out_file=out_file)
            mam.set_title(title=title)
            mam.set_threshold(threshold=thr_val)
            if self.roi_atlas_set:
                mam.set_atlas(self.roi_atlas_for_stat_maps)
            mam.plot()
            msg = '--- Mosaic Activation Map saved for following statistical map --'
            msg += '\n\tsubject   --> {0} (group {1})'.format(suid, grn)
            msg += '\n\tcontrast  --> {0}'.format(contrast.get_legend())
            msg += '\n\tthreshold --> {0}'.format(thr_str)
            msg += '\n\tstat map  --> {0}'.format(stat_map)
            msg += '\n\tsaved here--> {0}'.format(out_file)
            print(msg)
        return out_file

    def plot_montages_individual_statistical_maps(self, correction=CORR_SM_2, vmax=None):
        # Then create the large matrix
        for g, gr in enumerate(self.groups):
            if gr.get_num_contrasts() > 1:
                # For each group Matrix Subjects x Contrasts (one z slices)
                self.montage_individual_stat_maps_for_group(group=gr, correction=correction, vmax=vmax)
            for c, contrast in enumerate(gr.get_contrasts()):
                # For each contrast : create a subjects x slices montage (multiple z slices)
                self.montage_individual_stat_maps_for_group_and_contrast(group=gr, contrast=contrast,
                                                                         correction=correction)

    def montage_individual_stat_maps_for_group(self, group, correction, z_slice=55, vmax=None):
        """
        For a single group, plot all subjects and all contrasts in a large matrix.
        One single z slice is isolated per activation map.
        :return:
        """
        self.__find_autofmri_individual_statistical_maps__()
        out_dir = create_dir(opj(self.get_activations_dir(), '1st_level_maps'))

        base_info = [self.design_name]
        base_info += ['gr', group.name]
        base_info += ['individual_maps']
        base_info += [correction.get_suffix()]
        base_info += ['z', str(z_slice)]
        out_file = opj(out_dir, '_'.join(base_info) + '.png')

        if not ope(out_file):
            t0 = time.time()
            # Retrieve group index
            g = self.groups.index(group)
            # Print a message to inform the user
            n_su, n_cn = group.get_num_subjects(), group.get_num_contrasts()
            msg = 'Plotting Group {0} Activation Matrix of {1} subjects x {2} contrasts for and correction {3} ' \
                  '(n={4} maps)'.format(group.get_name(), n_su, n_cn, str(correction), n_su*n_cn)
            self.print(msg, force=True)
            # Start the plotting
            mc = MontageCheckerboardMapsAs2DArrayOneSlice(input_images=self.ind_stat_maps[g],
                                                          output_file=out_file)
            mc.set_z_slice(z_slice)
            mc.set_p_value(correction)
            if vmax:
                mc.set_vmax(vmax)
            mc.set_column_titles(column_titles=group.get_contrast_spm_strings())
            mc.set_row_titles(row_titles=group.get_list_subject_ids(), pos_index=0)
            mc.set_montage_title(
                montage_title='{0} Group {1} all contrasts {2}'.format(self.name, group.name.upper(), correction))
            if self.roi_atlas_set:
                mc.set_atlas(atlas=self.roi_atlas_for_stat_maps)
            mc.plot()
            # Inform the user a file was saved
            dur_str = convert_duration_to_nice_duration_string(d=time.time() - t0)
            print('Output file {0} generated in '.format(out_file), dur_str, '\n')

    def montage_individual_stat_maps_for_group_and_contrast(self, group, contrast, correction, vmax=None):
        """
        For a single group, and a single contrast, plot all subjects activation maps.
        A list of z slices is used.
        :param group:
        :param contrast:
        :param correction:
        :return:
        """
        self.__find_autofmri_individual_statistical_maps__()
        out_dir = create_dir(opj(self.get_activations_dir(), '1st_level_maps'))

        base_info = [self.design_name]
        base_info += ['gr', group.name]
        base_info += ['individual_maps']
        base_info += ['contrast', contrast.get_suffix()]
        base_info += [correction.get_suffix()]
        out_file = opj(out_dir, '_'.join(base_info) + '.png')

        if not ope(out_file):
            t0 = time.time()
            # Retrieve group index and contrast index
            g, c = self.groups.index(group), group.get_contrast_index(contrast)
            # Print a message to the user
            n_su = group.get_num_subjects()
            msg = 'Plotting Group {0} Individual Activation Maps of {1} subjects for {2} and correction {3} ' \
                  'with {4} slices.'.format(group.get_name(), n_su, contrast, str(correction), len(self.z_slices))
            self.print(msg, force=True)

            m = MontageActivationPlots(stat_maps=self.ind_stat_maps[g][:,c], output_montage_file=out_file)
            m.set_cut_coords(cut_coords=self.z_slices)
            m.set_correction(correction=correction)
            if self.roi_atlas_for_stat_maps:
                m.set_atlas(atlas=self.roi_atlas_for_stat_maps)
            if vmax:
                m.set_vmax(vmax=vmax)
            else:
                m.set_colorbar(colorbar=True)
            m.set_titles(titles=group.get_list_subject_ids())
            m.set_montage_title('Group {0} {1} {2}'.format(group.get_name(), contrast.get_legend(), correction))
            m.plot()
            # Inform the user a file was saved
            dur_str = convert_duration_to_nice_duration_string(d=time.time()-t0)
            print('Output file {0} generated in '.format(out_file), dur_str, '\n')

    # ----------------------------- ROI Analyses ------------------------------------------------
    def __load_contrasts_in_rois__(self):
        """

        :return:
        """
        self.__check_atlas__()
        self.__find_autofmri_contrast_maps__()
        self.__find_group_statistical_maps__()

        data_maps = self.ind_con_maps
        self.roi_analyzer = ROIAnalyzer(data_maps=data_maps, atlas=self.roi_atlas, out_dir=self.get_roi_analysis_dir())
        self.roi_analyzer.set_groups(self.groups)
        self.roi_analyzer.load_average_contrasts_roi_data()

    def perform_roi_analysis(self, plot_all_con_in_one_roi=True, plot_all_rois_in_one_con=True,
                             xlabel_is_contrast_index=False):
        """
        Work-in-progress
        :return:
        """
        if self.roi_atlas_set:
            self.print('Performing ROI Analysis with ROIAtlas {0}'.format(self.roi_atlas.get_atlas_name()), force=True)
            self.__load_contrasts_in_rois__()
            if plot_all_con_in_one_roi:
                self.roi_analyzer.plot_all_contrasts_in_one_roi(xlabel_is_contrast_index=xlabel_is_contrast_index)
            if plot_all_rois_in_one_con:
                self.roi_analyzer.plot_all_rois_in_one_contrast()
        else:
            sys.exit('Can not perform ROI analysis since no ROIAtlas is defined')

    def perform_roi_analyses_for_multiple_atlases(self):
        if len(self.list_roi_atlases) > 0:
            for roi_atlas in self.list_roi_atlases:
                self.set_atlas_for_roi_analysis(atlas=roi_atlas)
                self.perform_roi_analysis()
        else:
            sys.exit('You must define a list of ROIAtlases')

    def count_voxels_per_roi(self, correction=CORR_SM_3):
        """ Count number of active voxels (>threshold) per ROI"""
        data = {'ROI':[], 'Group':[], 'Contrast':[], 'con_num':[], 'n_activated_voxels':[], 'n_voxels_roi':[], 'Coordinates':[], 'Z Score':[]}
        self.__check_atlas__()
        self.__find_group_statistical_maps__()
        if self.roi_atlas_set:
            self.print('Counting num Voxels per ROI Analysis with ROIAtlas {0}'.format(self.roi_atlas.get_atlas_name()), force=True)
            for g, group in enumerate(self.groups):
                for c, contrast in enumerate(group.get_design().get_contrasts()):
                    stat_map = self.grp_stat_maps[g][c]
                    affine = nib.load(stat_map).affine
                    correction.compute_threshold(stat_map)
                    thr = correction.get_threshold_stat_map()
                    stat_data = nib.load(stat_map).get_fdata()
                    thr_map = correction.get_thresholded_stat_map().get_fdata() > thr
                    for r, roi in enumerate(self.roi_atlas.get_list_rois()):
                        roi_data = nib.load(roi.get_file()).get_fdata()
                        roi_mask = np.nonzero(roi_data)
                        nvox_act = np.sum(thr_map[roi_mask])
                        nvox_roi = np.sum(np.sum(roi_data>0))
                        z_max = np.max(stat_data[roi_mask])
                        # Retrieve coordinates
                        index_in_mask = np.argmax(stat_data[roi_mask])
                        vx = roi_mask[0][index_in_mask]
                        vy = roi_mask[1][index_in_mask]
                        vz = roi_mask[2][index_in_mask]
                        x,y,z = nilearn.image.coord_transform(vx,vy,vz,affine)
                        # Append data
                        data['Group'].append(group.get_name())
                        data['ROI'].append(roi.get_name())
                        data['con_num'].append(contrast.get_spm_index())
                        data['Contrast'].append(contrast.get_name())
                        data['n_activated_voxels'].append(nvox_act)
                        data['n_voxels_roi'].append(nvox_roi)
                        data['Coordinates'].append(f'{round(x)},{round(y)},{round(z)}')
                        data['Z Score'].append(z_max)
            df = pd.DataFrame(data, columns=['Group', 'Contrast', 'con_num', 'ROI', 'n_activated_voxels', 'n_voxels_roi', 'Coordinates', 'Z Score'])
            df['Percentage activation (ROI)'] = df['n_activated_voxels']/df['n_voxels_roi']
            return df
        else:
            sys.exit('Can not count active voxels per ROI since not ROIAtlas is set')

    # --------------------- Generating a PDF Latex report ------------------------------
    def generate_pdf_report(self, correction=CORR_3):
        """
        Main function organizing the generation of latex PDF reports
        """
        self.print('Generating Latex PDF report', force=True)
        # Start the Latex Report
        latex_dir = create_dir(opj(self.pyautomri_output_dir, 'Report'))
        self.latex_report_file = opj(latex_dir, 'report_{0}_{1}.tex'.format(self.name, correction.get_suffix()))
        self.lr = LatexDocumentReport(tex_file=self.latex_report_file)
        self.lr.set_title(self.name)
        self.lr.write_header()
        self.lr.set_table_of_contents()
        self.lr.newpage()
        # Give information regardi ng the study (groups, subjects, design etc...)
        self.write_study_info_section()
        # Contrasts section
        self.write_contrasts_section(correction=correction)
        if self.roi_atlas_set:
            # If a ROI analysis was performed, write a section about it
            self.write_roi_section()
        # End the process by saving and compiling
        self.add_extra_information_specific_to_project()
        self.lr.save()
        self.lr.compile()

    def generate_study_report_pdf(self, alpha):
        """
        Function to gather all statistical maps plots and clusters positions from all groups, for all contrasts
        into a single PDF file
        :param alpha: chosen threshold
        """
        pass

    def write_study_info_section(self):
        self.lr.add_section('Study information')

        text = r'\begin{itemize}' + '\n'
        text += '\item Study name : ' + r'\texttt{' + self.name + '}\n'
        if self.nG > 1:
            text += '\item {0} Groups : \n'.format(self.nG)
        else:
            text += '\item A single Group : \n'.format(self.nG)
        text += r'\begin{itemize}' + '\n'
        for g, gr in enumerate(self.groups):
            des = gr.get_design()
            text += '\item Groupe ' + gr.name + ' : \n'
            text += r'\begin{itemize}' + '\n'
            text += '\item' + str(gr.nS) + ' subjects : '
            text += ', '.join([r'\texttt{' + su + '}' for su in gr.get_list_subject_ids()]) + '\n'
            text += '\item Design ' + r'\texttt{' + des.get_name() + '}' + ' ({0} contrasts)'.format(
                self.n_con_per_group[g]) + '\n'
            text += r'\end{itemize}' + '\n'
        text += r'\end{itemize}' + '\n'

        if self.roi_atlas_set:
            text += '\item ROI dictionary : ' + self.roi_atlas.get_atlas_name() + ' ({0} ROIs)'.format(self.nR) + '\n'
            text += r'\begin{enumerate}' + '\n'
            for r, roi in enumerate(self.roi_atlas.get_list_rois()):
                text += '\item {0} \n'.format(roi.get_name())
            text += r'\end{enumerate}' + '\n'

            self.lr.add_text(text=text)
            if hasattr(self, 'roi_analyzer'):
                self.lr.add_figure(path_image=self.roi_analyzer.get_roi_plot_file(), width=0.6,
                                   legend='Regions of Interest', align='!h')
            self.lr.add_text(text=r'\end{itemize}' + '\n')
        else:
            text += r'\end{itemize}' + '\n'
            self.lr.add_text(text=text)
        # In any case : end with a newpage
        self.lr.newpage()

    def write_contrasts_section(self, correction):
        """
        Function to gather all statistical maps plots and clusters positions from each group, for all contrasts
        into a single PDF file
        :param correction: threshold
        """
        self.lr.add_section(section_name='Contrasts of interest')
        for g, group in enumerate(self.groups):
            subsection = 'Groupe ' + group.name.replace('_', ' ') + ' ({0} subjects)'.format(
                len(group.get_list_subjects()))
            self.lr.add_subsection(subsection_name=subsection)
            for c, contrast in enumerate(group.get_contrasts()):
                self.lr.add_subsubsection(subsubsection_name=contrast.get_legend())
                # Retrieve information from the Second Level Analysis instance
                sla = self.second_level_analyses[g][c]
                self.lr.add_figure(path_image=sla.plot_stat_map(correction), width=1., legend='')
                self.lr.add_table(sla.get_clusters_table_latex(correction=correction))
                self.lr.newpage()

    def write_roi_section(self):
        """
        This section is independant of the alpha threshold
        :return:
        """
        # Add section ROI Analysis
        self.lr.add_section('ROI analysis with ' + self.roi_atlas.get_atlas_name().replace('_', ' ') + ' dictionary')
        # Retrieve ROIS figures from the ROI analyzer
        fixed_contrasts = self.roi_analyzer.get_plots_one_contrast_all_rois()
        fixed_rois = self.roi_analyzer.get_plots_one_roi_all_contrasts()
        # Add subsection 1
        self.lr.add_subsection('One contrast fixed, {0} ROIs'.format(len(self.roi_atlas.get_list_rois())))
        for g, gr in enumerate(self.groups):
            self.lr.add_subsubsection(subsubsection_name='Groupe ' + gr.name.replace('_', '\_'))
            for c in range(len(fixed_contrasts[g, :])):
                con_name = gr.get_contrasts()[c].get_legend()
                legend = 'Average contrasts values distribution for ' + con_name + ' in the ROIs.'
                self.lr.add_figure(path_image=fixed_contrasts[g, c], width=0.6, legend=legend, align='!h')
        # Add subsection 2
        self.lr.newpage()
        self.lr.add_subsection('One ROI fixed, all contrasts')
        for g, gr in enumerate(self.groups):
            self.lr.add_subsubsection(subsubsection_name='Groupe ' + gr.name.replace('_', '\_'))
            for r, roi in enumerate(self.roi_atlas.get_list_rois()):
                legend = 'Average contrasts values distribution in ROI {0} {1}.'.format(r + 1,
                                                                                        roi.get_name().replace('_',
                                                                                                                '.'))
                self.lr.add_figure(path_image=fixed_rois[g, r], width=0.6, legend=legend, align='!h')
        self.lr.newpage()

    def add_extra_information_specific_to_project(self):
        """
        This function is meant to be implemented in children classes
        """
        pass
