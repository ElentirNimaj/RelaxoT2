import os
import sys
import warnings
from pyautomri.stat.CorrectionStatisticalMaps import get_predefined_threshold, Correction
from pyautomri.automri.core.Study import check_directory_looks_like_an_automri_project_dir


def get_error_message_study_dir(cur_dir):
    return """ 
    ERROR !! NOT AN AUTOMRI FOLDER ? \n
1. You did not provide an automri study dir 
2. AND the current working directory does not seem to be an automri project folder.
        {0}
SOLUTION : Provide a valid path to an automri directory or move to another folder. 
""".format(cur_dir)


def get_correction_from_cl_args(alpha, k, height_control, correction_index):
    """
    Given command line arguments provided by the user, either returns a predefined threshold (predef_thresh)
    or a user-defined threshold (alpha, k, and correction type provided)
    :param alpha: float, threshold value
    :param k: int, cluster threshold
    :param height_control: correction type : 'fpr', 'fdf' or 'bonferroni'
    :param correction_index: int, index in [0,1,2,3]
    :return:
    """
    # If three parameters are defined then removed predefined correction index
    if alpha or height_control or k:
        # Set correction index to False
        correction_index = False
        # Set default options to unset parameters
        if not alpha:
            alpha = 0.001
        if not k:
            k = 0
        if not height_control:
            height_control = 'fpr'
    if correction_index:
        if alpha or k or height_control:
            msg = 'When selecting a correction method, you chose both a correction method ({0}) and the following ' \
                  'parameter(s) :\n'.format(correction_index)
            for param, value in zip(['alpha', 'k', 'height'],[alpha, k, height_control]):
                if value:
                    msg += '\t- {0}: {1}\n'.format(param, value)
            msg += 'In that case, the correction method ({0}) is kept : '.format(correction_index)\
                   + str(get_predefined_threshold(correction_index))
            warnings.warn(msg)
        correction = get_predefined_threshold(correction_index)
    else:
        correction = Correction(alpha=float(alpha), height_control=height_control, k=int(k))
    print('Chosen correction is', correction.get_legend())
    return correction


def get_study_dir_from_cl_args(study_dir):
    """
    If a path is given, then return it.
    Else, check if the user in currently in an automri project.
        If it is the case, return current working directory
        Otherwise print a meaningfull message.
    :param study_dir: path to an automri project
    :return:
    """
    if not study_dir:
        study_dir = os.getcwd()
        if not check_directory_looks_like_an_automri_project_dir(study_dir):
            sys.exit(get_error_message_study_dir(study_dir))
    return study_dir
