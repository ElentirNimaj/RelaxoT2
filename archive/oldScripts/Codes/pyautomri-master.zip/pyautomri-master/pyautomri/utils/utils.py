from os.path import exists as ope, basename as opb, dirname as opd, join as opj
import os, sys, nibabel, numpy as np


def list_of_files_exist_print_missing(list_files, msg, verbose=True):
    if list_of_files_exist(list_files):
        if verbose:
            print(msg + ' : all found.')
    else:
        print(msg + ' : SOME ARE MISSING ')
        for f in list_files:
            if f:
                if not ope(f):
                    print(f)
        sys.exit()


def list_of_files_exist(listFiles):
    """
    Check if every file in the list of files exist. If only one file is missing return false
    :param listFiles: list of filenames
    :return: True if all the files exist. False if one file is missing
    """
    # for f in listFiles:
    #    f.replace(' ','\ ')
    values = [ope(x) for x in listFiles if x]
    return len([x for x in values if x]) == len(listFiles)


def find_nii_or_gz(image_filename, returnEmptyCharIfNotFound=False, returnSearchedImageFilename=False):
    """
    return the nifti path whether it is a compressed nifti file or a uncompressed nifti file
    :param image_filename: path to the requested nifti file
    :return:
    """
    if image_filename.endswith('.nii'):
        otherExtFile = image_filename + '.gz'
    elif image_filename.endswith('.nii.gz'):
        otherExtFile = image_filename[:-3]
    else:
        err_msg = 'Error find_nii_or_gz : requested file is not a nifti file :\n\t{0}'.format(image_filename)
        sys.exit(err_msg)

    if ope(image_filename):
        return image_filename
    elif ope(otherExtFile):
        return otherExtFile
    else:
        err_msg = 'Error find_nii_or_gz : no such file (.nii or .nii.gz) exists \n\t{0}'.format(image_filename)

    if returnEmptyCharIfNotFound or returnSearchedImageFilename:
        if returnEmptyCharIfNotFound:
            return ''
        if returnSearchedImageFilename:
            return image_filename
    else:
        sys.exit(err_msg)


def create_dir(dir):
    """Create a directory if it does not exist
    :param dir: directory to be created
    """
    if not ope(dir):
        os.mkdir(dir)
    return dir


def create_dirs(dir):
    """Recursive create dirs"""
    if not ope(dir):
        os.makedirs(dir)
    return dir


def remove_nifti_extension(f):
    """
    Remove extension of a nifti file
    :param f:
    :return:
    """
    if f.endswith('.nii'):
        return opb(f)[:-4]
    elif f.endswith('.nii.gz'):
        return opb(f)[:-7]
    else:
        sys.exit('remove_nifti_extension(f) only works with nifti files (.nii or .nii.gz)')


def flip_nii_file(f, print_if_not_exist=True):
    """
    Reads a nifti file and flips the volume along the x-axis
    :param f:
    :param print_if_not_exist:
    :return:
    """
    if not ope(f):
        print(f)
    out_f = opj(opd(f), remove_nifti_extension(f) + '_flipped_py.nii.gz')
    if ope(out_f):
        if print_if_not_exist:
            print('Flip Volume did not run because output file already exists\n' + out_f)
        else:
            pass
    else:
        # Read input_file
        nii_f = nibabel.load(f)
        # Flip array
        flipped_data = np.flip(nii_f.get_data(), axis=0)
        # Create output nifti
        out_file = nibabel.Nifti1Image(flipped_data, affine=nii_f.affine, header=nii_f.header)
        # Save
        nibabel.save(out_file, out_f)
    return out_f


def convert_duration_to_nice_duration_string(d):
    """
    Duration printed as 00:07:18 for example (7 minutes and 18 seconds)
    :param d: float, duration in seconds
    :return: string, human-readable-ready-to-be-printed duration
    """
    m, s = divmod(d, 60)
    h, m = divmod(m, 60)
    txt = ''
    if h > 0:
        txt += '%dh' % h
    if m > 0:
        txt += '%dm' % m
    txt += '%ds' % s
    return txt


def sizeof_fmt(num, suffix='B'):
    for unit in ['','Ki','Mi','Gi','Ti','Pi','Ei','Zi']:
        if abs(num) < 1024.0:
            return "%3.1f%s%s" % (num, unit, suffix)
        num /= 1024.0
    return "%.1f%s%s" % (num, 'Yi', suffix)


def get_pval_alpha(pval):
    """
    When annotating a graph, I want the box label to have an opacity relative to the effect size
    :param pval:
    :return:
    """
    import math
    return min(1.0, -math.log10(pval) / 10)