import sys
import time
import os
from os.path import join as opj, exists as ope

import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.gridspec import GridSpec

from pyautomri.roi.Atlas import CSV2Atlas, ROIAtlas
from pyautomri.stat.StatFunctions import CSV2DataMaps
from pyautomri.stat.CorrectionStatisticalMaps import CORR_2
from pyautomri.roi.ROI import RegionOfInterest
from pyautomri.utils.utils import convert_duration_to_nice_duration_string, create_dir
from pyautomri.plot.StatisticalMapping import MontageActivationPlots

# For the ROI analyzer, define a list of columns for the pandas data frame
# Keys defining columns of the ROI data frame
K_DF_ROI_GRP = 'Group'
K_DF_ROI_SUB = 'Subject'
K_DF_ROI_ROI = 'ROI'
K_DF_ROI_CON = 'Contrast'
K_DF_ROI_VAL = 'Value'
K_DF_ROI_CON_IDX = 'Contrast index'
K_DF_ROI_TMP = 'Timepoint'

# Ordered list of columns when saving the data frame of a ROI Analyzer
K_DF_COLS_RA = [K_DF_ROI_GRP, K_DF_ROI_SUB, K_DF_ROI_ROI, K_DF_ROI_CON, K_DF_ROI_CON_IDX, K_DF_ROI_VAL]
K_DF_COLS_LRA = [K_DF_ROI_GRP, K_DF_ROI_SUB, K_DF_ROI_ROI, K_DF_ROI_CON, K_DF_ROI_TMP, K_DF_ROI_VAL]
K_DF_COLS_IRA = [K_DF_ROI_GRP, K_DF_ROI_SUB, K_DF_ROI_CON, K_DF_ROI_VAL]


def get_mean_values_in_maps(data_maps, roi_file):
    """
    Given a list of data maps and a ROI file, ret
    :param data_maps: list of paths to nifti data maps
    :param roi_file: path to a ROI file
    :return: list of average values inside the data maps for the given ROI
    """
    vals = []
    # Load the ROI file
    roi_nii = nib.load(roi_file)
    roi_data = roi_nii.get_fdata()
    mask_roi = np.nonzero(roi_data)  # returns 3-list of array indices
    for data_file in data_maps:
        nifti_vol = nib.load(data_file)
        y_data = nifti_vol.get_fdata()
        con_value = np.nanmean(y_data[mask_roi])
        vals.append(con_value)
    return vals


class InputMapsROIAnalysis:
    """
    This class is meant to provide a quick and straightforward ROI analysis on data maps
    """

    def __init__(self, data_csv, rois_csv, out_dir):
        """
        Initializes the class with two csv files and an output directory
        :param data_csv: str, path to the csv file describing input data
        :param rois_csv: str, path to the csv file describing the set of regions of interest
        :param out_dir: str, path to the output directory where results will be saved
        """
        self.data_csv = data_csv
        self.rois_csv = rois_csv
        self.out_dir = out_dir
        # Read ROI csv file and retrieve useful information
        self.csv2atlas = CSV2Atlas(self.rois_csv)
        self.atlas = self.csv2atlas.get_atlas()
        self.csv2atlas.create_atlas_plot(png_file=opj(self.out_dir, 'roi_plot.png'))
        # Read data maps from csv file
        self.csv2data = CSV2DataMaps(self.data_csv)
        self.data_maps = self.csv2data.get_list_input_maps()
        self.subjects = self.csv2data.get_list_subjects()
        # Get number of ROIs and number of subjects
        self.n_rois = self.atlas.get_number_of_rois()
        self.n_subjects = len(self.subjects)

    def __str__(self):
        msg = '---------- ROI Analysis ----------\n'
        msg += '\t- ROIs csv file  : {0} ({1} ROIs)\n'.format(self.rois_csv, self.n_rois)
        msg += '\t- DATA csv file  : {0} ({1} data maps)\n'.format(self.data_csv, self.n_subjects)
        msg += '\t- Results folder : {0}'.format(self.out_dir)
        return msg

    def __check_data_and_rois_are_coherent__(self):
        #todo : implement function that 1. loads data maps, 2. loads ROI masks and check that they share the same
        # dimensionality and the same matrices
        pass

    def __prepare_filenames__(self):
        self.data_in_rois_csv = opj(self.out_dir, 'data.csv')
        self.output_png_graph = opj(self.out_dir, 'graph.png')

    def __compute_average_data_in_rois__(self):
        """
        For all regions of interest : 1) load the ROI mask and computes average contrast values for all subjects and all
        contrast maps.
        Data are stored into a pandas data frame that is stored into the self.df class structure.
        """
        nr, ns = self.n_rois, self.n_subjects
        # Get a time stamp at the beginning of the global computation
        t0 = time.time()
        print('Start computing mean contrast values in {0} ROIs for {1} subjects ... '.format(nr, ns))

        # Prepare lists for the data frame
        l_sub, l_roi, l_val, l_file = [], [], [], []
        col_file = 'file'

        for r, roi in enumerate(self.atlas.get_list_rois()):
            # Get a time stamp at the beginning of the ROI computation
            t1 = time.time()
            # Load ROI data
            roi_nii = nib.load(roi.get_file())
            roi_data = roi_nii.get_data()
            # Define the ROI mask once for all contrast maps
            mask_roi = np.nonzero(roi_data)  # returns 3-list of array indices
            n_voxels = len(mask_roi[0])  # Just count the number of voxels
            for s, su in enumerate(self.subjects):
                nifti_file = self.data_maps[s]
                # Load Nifti of the statistical map
                nifti_vol = nib.load(nifti_file)
                y_data = nifti_vol.get_data()
                # Compute average value (where ROI mask is > 0)
                con_value = np.nanmean(y_data[mask_roi])
                # Append values to lists
                l_sub.append(su)  # Subject identification number
                l_roi.append(roi.get_name())  # ROI name
                l_val.append(con_value)  # Contrast value
                l_file.append(nifti_file)  # path to the data file
            dur_roi = convert_duration_to_nice_duration_string(d=round(time.time() - t1, 2))
            print('... ROI {0}/{1} computed in {2} ({3} voxels)'.format(r + 1, nr, dur_roi, n_voxels))

        roi_data_dict = {K_DF_ROI_SUB: l_sub, K_DF_ROI_ROI: l_roi, K_DF_ROI_VAL: l_val, col_file: l_file}
        self.df = pd.DataFrame(roi_data_dict, columns=[K_DF_ROI_SUB, col_file, K_DF_ROI_ROI, K_DF_ROI_VAL])
        dur_total = convert_duration_to_nice_duration_string(d=time.time() - t0)
        print('... ALL {0} ROI data of {1} subjects computed in {2}'.format(nr, ns, dur_total))

    def load_average_contrasts_roi_data(self):
        """
        Either computes the data and saves it to a csv file or loads the already computed csv file.
        """
        self.__prepare_filenames__()
        if not ope(self.data_in_rois_csv):
            self.__compute_average_data_in_rois__()
            print('Saving ROI data csv file : \n\t', self.data_in_rois_csv)
            self.df.to_csv(self.data_in_rois_csv)
        else:
            # if the data file was not already loaded, then load it
            if not hasattr(self, 'df'):
                self.df = pd.read_csv(self.data_in_rois_csv)
                print('ROI data csv file loaded from : \n\t' + self.data_in_rois_csv)

    def perform_analysis(self):
        self.load_average_contrasts_roi_data()
        if not ope(self.output_png_graph):
            self.__plot_roi_graph__()

    def __plot_roi_graph__(self):
        from pyautomri.roi.Graphs import MultipleROISSingleContrast
        mr = MultipleROISSingleContrast(df=self.df, atlas=self.atlas, contrast='',
                                        output_file=self.output_png_graph)
        mr.plot()
        print('Contrast distribution in ROIs Graph saved : ' + self.output_png_graph)


class ROIAnalyzer:
    """
    Class that allows to perform some ROI analysis onto data maps
    """

    def __init__(self, data_maps, atlas: ROIAtlas, out_dir):
        """

        :param data_maps: list of numpy arrays, usually individual contrast maps. data_maps[g][s,c] should return the
        contrast map c of individual s from group g
        :param atlas: a dictionary of ROIs
        :param out_dir: an output directory where resulting outputs should be stored
        """
        self.data_maps = data_maps
        self.atlas = atlas
        self.out_dir = out_dir
        self.__set_default_values__()

    def __set_default_values__(self):
        self.groups = None
        self.n_groups = None
        self.n_subjects = []  # Number of subjects per group [int, int, int]
        self.n_total_subjects = None  # Total Number of subjects
        self.n_contrasts = None
        self.__init_atlas__()

    def __init_atlas__(self):
        self.atlas.check()
        self.n_rois = self.atlas.get_number_of_rois()
        self.__plot_atlas__()
        self.__plot_rois__()

    def __plot_atlas__(self):
        self.atlas_plot_file = opj(self.out_dir, 'ROIAtlas_plot_{0}.png'.format(self.atlas.get_atlas_name()))
        if not ope(self.atlas_plot_file):
            self.atlas.plot(out_file=self.atlas_plot_file, alpha=1)

    def __plot_rois__(self):
        self.roi_plot_files = []
        roi_plot_dir = create_dir(opj(self.out_dir, 'roi_plots'))
        for r, roi in enumerate(self.atlas.get_list_rois()):
            roi_plot_f = opj(roi_plot_dir, 'roi_{0}_{1}.png'.format(r+1, roi.get_name().replace(' ','_')))
            self.roi_plot_files.append(roi_plot_f)
            if not ope(roi_plot_f):
                ax = roi.plot()
                self.atlas.add_overlay_list_rois_to_display(display=ax, alpha=.15)
                plt.savefig(roi_plot_f)
                plt.close()

    def get_roi_plot_file(self):
        return self.atlas_plot_file

    def set_groups(self, groups):
        """
        Set the list of groups
        :param groups: list of Group instances
        :return:
        """
        self.groups = groups
        if len(self.data_maps) != len(self.groups):
            msg = 'Miscorrespondance between the number of groups ({0}) and the length of the data_maps list ({1})'.format(
                len(self.groups), len(self.data_maps))
            sys.exit(msg)
        # Retrieve the number of subjects and number of contrasts per group from the data_maps
        self.n_groups = len(self.groups)
        self.n_subjects = np.asarray([np_arr.shape[0] for np_arr in self.data_maps])
        self.n_total_subjects = np.sum(self.n_subjects)
        self.n_contrasts = np.asarray([np_arr.shape[1] for np_arr in self.data_maps])

    def print(self, msg):
        print('** ROI Analyzer ' + msg)

    def __prepare_filenames__(self):
        nG = len(self.groups)
        dir_one_roi_all_contrasts = create_dir(opj(self.out_dir, 'all_contrasts_in_one_roi'))
        dir_one_contrast_all_rois = create_dir(opj(self.out_dir, 'all_rois_in_one_contrast'))

        self.plots_one_roi_all_contrasts = np.empty(shape=(nG, self.n_rois), dtype=object)
        self.plots_one_contrast_all_rois = np.empty(shape=(nG, np.max(self.n_contrasts)), dtype=object)
        for g, gr in enumerate(self.groups):
            for r, roi in enumerate(self.atlas.get_list_rois()):
                basename = 'contrasts_values_in_roi_{0}_{1}_gr_{2}.png'.format(r + 1, roi.get_name(), gr.name)
                self.plots_one_roi_all_contrasts[g, r] = opj(dir_one_roi_all_contrasts, basename)
            for c, contrast in enumerate(gr.get_contrasts()):
                basename = 'gr_{0}_contrast_{1}_{2}.png'.format(gr.name, c + 1, contrast.get_suffix())
                self.plots_one_contrast_all_rois[g, c] = opj(dir_one_contrast_all_rois, basename)

    def load_average_contrasts_roi_data(self):
        """
        Eithers computes the data and saves it to a csv file or loads the already computed csv file.
        """
        self.__prepare_filenames__()
        self.roi_csv_file = opj(self.out_dir, 'individual_avg_contrasts_in_ROIs.csv')
        if not ope(self.roi_csv_file):
            self.compute_contrasts()
            self.print('Saving ROI data csv file : \n\t' + self.roi_csv_file)
            self.roi_df.to_csv(self.roi_csv_file)
        else:
            # if the data file was not already loaded, then load it
            # This is done because load_average_contrasts_roi_data() is called multiple times and we want to avoid multiple calls to this function
            if not hasattr(self, 'roi_df'):
                self.roi_df = pd.read_csv(self.roi_csv_file)
                #self.print('ROI data csv file loaded : \n\t' + self.roi_csv_file)

    def compute_contrasts(self):
        """
        For all regions of interest : 1) load the ROI mask and computes average contrast values for all subjects and all
        contrast maps.
        Data are stored into a pandas data frame that is stored into the self.df class structure.
        """
        # Get a time stamp at the beginning of the global computation
        t0 = time.time()
        self.print('Start computing mean contrast values in {0} ROIs for {1} subjects ... '.format(self.n_rois,
                                                                                                   self.n_total_subjects))

        # Prepare lists for the data frame
        l_sub, l_grp, l_roi, l_val, l_con, l_con_idx = [], [], [], [], [], []

        for r, roi in enumerate(self.atlas.get_list_rois()):
            # Get a time stamp at the beginning of the ROI computation
            t1 = time.time()
            # Load ROI data
            roi_nii = nib.load(roi.get_file())
            R = roi_nii.get_data()
            # Define the ROI mask once for all contrast maps
            mask_roi = np.nonzero(R)  # returns 3-list of array indices
            n_voxels = len(mask_roi[0])  # Just count the number of voxels
            for g, gr in enumerate(self.groups):
                for s, su in enumerate(gr.get_list_subjects()):
                    for c, contrast in enumerate(gr.get_contrasts()):
                        # Load Nifti of the statistical map
                        nifti_vol = nib.load(self.data_maps[g][s, c])
                        y_data = nifti_vol.get_data()
                        if y_data.shape != R.shape:
                            print('Mismatch shape between Contrast Map and ROI mask !')
                            print('Contrast Map shape', y_data.shape)
                            print('ROI shape', R.shape)
                            print('Contrast map  :', self.data_maps[g][s,c])
                            print('ROI mask file :', roi.get_file())
                            sys.exit()
                        # Compute average value (where ROI mask is > 0)
                        # con_value = np.mean(y_data[mask_roi])
                        con_value = np.nanmean(y_data[mask_roi])
                        # Append values to lists
                        l_sub.append(su.get_id())  # Subject identification number
                        l_grp.append(gr.name)  # Group name
                        l_roi.append(roi.get_name())  # ROI name
                        l_con.append(contrast.get_legend())  # Contrast name
                        l_val.append(con_value)  # Contrast value
                        l_con_idx.append(contrast.get_spm_index())
            print('\t-ROI {0}/{1} {2} computed in {3}s ({4} voxels)'.format(str(r+1).zfill(2), self.n_rois, roi.get_name(),
                                                                        round(time.time() - t1, 2), n_voxels))

        roi_data_dict = {K_DF_ROI_GRP: l_grp,
                         K_DF_ROI_SUB: l_sub,
                         K_DF_ROI_ROI: l_roi,
                         K_DF_ROI_CON: l_con,
                         K_DF_ROI_VAL: l_val,
                         K_DF_ROI_CON_IDX: l_con_idx}
        self.roi_df = pd.DataFrame(roi_data_dict, columns=K_DF_COLS_RA)
        self.print('... ALL {0} ROI data of {1} computed in {2}s'.format(self.n_rois, self.n_total_subjects,
                                                                         int(time.time() - t0)))

    def plot_all_contrasts_in_one_roi(self, xlabel_is_contrast_index=False):
        """

        :return:
        """
        from pyautomri.roi.Graphs import SingleROIMultipleContrasts
        for g, gr in enumerate(self.groups):
            df = self.roi_df[self.roi_df[K_DF_ROI_GRP] == gr.name]
            for r, roi in enumerate(self.atlas.get_list_rois()):
                # Define output filename
                out_file = self.plots_one_roi_all_contrasts[g, r]
                if not ope(out_file):
                    # Create a ROI plot instance
                    rp = SingleROIMultipleContrasts(df=df, roi=roi, output_file=out_file)
                    if xlabel_is_contrast_index:
                        rp.set_xlabel_is_contrast_index()
                    rp.plot(type='swarmplot')

    def plot_all_rois_in_one_contrast(self):
        """

        :return:
        """
        from pyautomri.roi.Graphs import MultipleROISSingleContrast
        for g, gr in enumerate(self.groups):
            for c, contrast in enumerate(gr.get_contrasts()):
                out_file = self.plots_one_contrast_all_rois[g, c]
                if not ope(out_file):
                    df = self.roi_df[self.roi_df[K_DF_ROI_GRP] == gr.name]
                    mrp = MultipleROISSingleContrast(df=df, atlas=self.atlas, contrast=contrast,
                                                     output_file=out_file)
                    gr_stat_map = gr.get_statistical_map(contrast)
                    if ope(gr_stat_map):
                        thr_stat_map, threshold = CORR_2.compute_threshold(stat_map=gr_stat_map)
                        mrp.set_statistical_map(stat_map=thr_stat_map, threshold=threshold)
                    mrp.plot()

    def get_plots_one_contrast_all_rois(self):
        return self.plots_one_contrast_all_rois

    def get_plots_one_roi_all_contrasts(self):
        return self.plots_one_roi_all_contrasts

    def get_df(self):
        self.load_average_contrasts_roi_data()
        return self.roi_df


class LongitudinalROIAnalyzer(ROIAnalyzer):
    """
    Class that allows to perform some ROI analysis onto data maps
    """

    def __init__(self, data_maps, atlas: ROIAtlas, out_dir):
        """

        :param data_maps: list of numpy arrays, usually individual contrast maps. data_maps[g][s,c,t] should return the
        contrast map c, at timepoint t, of individual s from group g
        :param atlas: a dictionary of ROIs
        :param out_dir: an output directory where resulting outputs should be stored
        """
        super().__init__(data_maps, atlas, out_dir)

    def __set_default_values__(self):
        super().__set_default_values__()
        self.contrasts = None  # Contrasts names
        self.timepoints = None  # List of timepoints
        self.n_timepoints = None  # number of timepoints

    def set_timepoints(self, timepoints):
        """
        :param timepoints: list of list, one list of timepoints per contrast
        :return:
        """
        self.timepoints = timepoints

    def set_contrasts(self, contrasts):
        self.contrasts = contrasts

    def set_group_statistical_maps(self, statistical_maps):
        """Statistical maps must be in the shape statistical_maps[g][c,t]"""
        #self.data_maps[g][s,c,t]
        #self.statistical_maps = statistical_maps
        self.gr_statistical_maps = statistical_maps
        # Todo implement some kind of check

    def set_groups(self, groups):
        """
        Set the list of groups
        :param groups: list of Group instances
        :return:
        """
        self.groups = groups
        if len(self.data_maps) != len(self.groups):
            msg = 'Miscorrespondance between the number of groups ({0}) and the length of the data_maps list ({1})'.format(
                len(self.groups), len(self.data_maps))
            self.print(msg)
            sys.exit()
        # Retrieve the number of subjects and number of contrasts per group from the data_maps
        self.n_subjects = np.asarray([np_arr.shape[0] for np_arr in self.data_maps])
        self.n_total_subjects = np.sum(self.n_subjects)
        self.n_contrasts = np.asarray([np_arr.shape[1] for np_arr in self.data_maps])
        self.n_timepoints = len(self.timepoints)

    def print(self, msg):
        print('** Longitudinal ROI Analyzer :' + msg)

    def __prepare_filenames__(self):
        # nG = len(self.groups)
        # dir_one_roi_all_contrasts = create_dir(opj(self.out_dir, 'all_contrasts_in_one_roi'))
        # dir_one_contrast_all_rois = create_dir(opj(self.out_dir, 'all_rois_in_one_contrast'))
        #
        # self.plots_one_roi_all_contrasts = np.empty(shape=(nG, self.n_rois), dtype=object)
        # self.plots_one_contrast_all_rois = np.empty(shape=(nG, np.max(self.n_contrasts)), dtype=object)
        # for g, gr in enumerate(self.groups):
        #     for r, roi in enumerate(self.atlas.get_list_rois()):
        #         basename = 'contrasts_values_in_roi_{0}_{1}_gr_{2}.png'.format(r + 1, roi.get_name(), gr.name)
        #         self.plots_one_roi_all_contrasts[g, r] = opj(dir_one_roi_all_contrasts, basename)
        #     for c, contrast in enumerate(gr.get_contrasts()):
        #         basename = 'gr_{0}_contrast_{1}_{2}.png'.format(gr.name, c + 1, contrast.get_suffix())
        #         self.plots_one_contrast_all_rois[g, c] = opj(dir_one_contrast_all_rois, basename)
        pass

    def compute_contrasts(self):
        """
        For all regions of interest : 1) load the ROI mask and computes average contrast values for all subjects and all
        contrast maps.
        Data are stored into a pandas data frame that is stored into the self.df class structure.
        """
        # Get a time stamp at the beginning of the global computation
        t0 = time.time()
        self.print('Start computing mean contrast values in {0} ROIs for {1} subjects ... '.format(self.n_rois, self.n_total_subjects))

        # Prepare lists for the data frame
        l_sub, l_grp, l_roi, l_val, l_con, l_tmp, l_fcn, l_fro = [], [], [], [], [], [], [], []
        for r, roi in enumerate(self.atlas.get_list_rois()):
            # Get a time stamp at the beginning of the ROI computation
            t1 = time.time()
            # Load ROI data
            roi_nii = nib.load(roi.get_file())
            R = roi_nii.get_data()
            # Define the ROI mask once for all contrast maps
            mask_roi = np.nonzero(R)  # returns 3-list of array indices
            n_voxels = len(mask_roi[0])  # Just count the number of voxels
            for g, gr in enumerate(self.groups):
                for s, su in enumerate(gr.get_list_subjects()):
                    for c, contrast in enumerate(self.contrasts):
                        for t, timepoint in enumerate(gr.get_timepoints()):
                            # Load Nifti of the statistical map
                            nifti_vol = nib.load(self.data_maps[g][s, c, t])
                            y_data = nifti_vol.get_data()
                            # Compute average value (where ROI mask is > 0)
                            # con_value = np.mean(y_data[mask_roi])
                            con_value = np.nanmean(y_data[mask_roi])
                            # Append values to lists
                            l_sub.append(su.get_id())  # Subject identification number
                            l_grp.append(gr.name)  # Group name
                            l_roi.append(roi.get_name())  # ROI name
                            l_con.append(contrast)  # Contrast name
                            l_val.append(con_value)  # Contrast value
                            l_tmp.append(timepoint)  # Timepoint
                            l_fcn.append(self.data_maps[g][s,c,t])
                            l_fro.append(roi.get_file())
            self.print(
                '... ROI {0}/{1} computed in {2}s ({3} voxels)'.format(r + 1, self.n_rois, round(time.time() - t1, 2),
                                                                       n_voxels))

        roi_data_dict = {K_DF_ROI_GRP: l_grp,
                         K_DF_ROI_SUB: l_sub,
                         K_DF_ROI_ROI: l_roi,
                         K_DF_ROI_CON: l_con,
                         K_DF_ROI_VAL: l_val,
                         K_DF_ROI_TMP: l_tmp,
                         'Contrast map': l_fcn,
                         'ROI file': l_fro}
        self.roi_df = pd.DataFrame(roi_data_dict, columns=K_DF_COLS_LRA + ['Contrast map', 'ROI file'])
        self.print('... ALL {0} ROI data of {1} subjects computed in {2}s'.format(self.n_rois, self.n_total_subjects, int(time.time() - t0)))

    def plot_group_roiwise(self, plot_type='swarmplot'):
        """
        Single Longitudinal ROI Plot per ROI
        :return:
        """
        from pyautomri.roi.Graphs import LongitudinalSingleROIPlot
        for g, gr in enumerate(self.groups):
            gr_subdir = create_dir(opj(self.out_dir, 'gr_{0}'.format(gr.get_name())))
            for r, roi in enumerate(self.atlas.get_list_rois()):
                roi_name = roi.get_name().replace(' ', '_')
                for c, contrast in enumerate(self.contrasts):
                    basename = '_'.join(['gr', gr.get_name(), 'con', contrast, 'roi', str(r+1), roi_name, plot_type])
                    gr_out_file = opj(gr_subdir, basename + '.png')
                    if not ope(gr_out_file):
                        lsrp = LongitudinalSingleROIPlot(self.roi_df, roi=roi, out_file=gr_out_file, contrast=contrast,
                                                         group_name=gr.get_name())
                        # Maybe better than a ROI -> plot_stat_maps for every session
                        if hasattr(self, 'gr_statistical_maps'):
                            nt = len(self.timepoints[c])
                            gr_stat_maps = list(self.gr_statistical_maps[g][c,:nt])
                            temp_stat_file = opj(self.out_dir, 'temp_plot.png')
                            m = MontageActivationPlots(stat_maps=gr_stat_maps, output_montage_file=temp_stat_file)
                            m.set_correction(correction=CORR_2)
                            m.set_roi(roi=roi, alpha=1, lw_contour_roi=3)
                            m.set_cut_coords(cut_coords=[roi.get_barycenter()[2]])  # Z coordinate of the barycenter
                            m.plot()
                            lsrp.set_view_file(temp_stat_file, remove_after_plot=True)
                            lsrp.plot(plot_type=plot_type)
                        else:
                            # Default view is to use the Atlas ROIPlot file
                            lsrp.set_view_file(self.roi_plot_files[r], remove_after_plot=True)
                            lsrp.plot()

    def plot_individual_roi_wise(self):
        """
        For each subject, make a pl
        :return:
        """
        # Now perform the same plots for every subject
        from pyautomri.roi.Graphs import LongitudinalMultipleROISPlot
        for g, gr in enumerate(self.groups):
            gr_subdir = create_dir(opj(self.out_dir, 'gr_{0}'.format(gr.get_name())))
            su_dir = create_dir(opj(gr_subdir, 'subjects'))
            for s, su in enumerate(gr.get_list_subjects()):
                for c, contrast in enumerate(self.contrasts):
                    con_dir = create_dir(opj(su_dir, contrast))
                    basename = '_'.join(['gr', gr.get_name(), 'su', su.get_id(), 'con', contrast])
                    su_out_file = opj(con_dir, basename + '.png')
                    if not ope(su_out_file):
                        lmrp = LongitudinalMultipleROISPlot(self.roi_df, atlas=self.atlas, out_file=su_out_file,
                                                            contrast=contrast, group_name=gr.get_name())
                        lmrp.set_view_file(self.atlas_plot_file, remove_after_plot=False)
                        lmrp.plot(subject=su)


class IndividualisedROIAnalyzer(ROIAnalyzer):
    """
    This class provides solution to perform a Group ROI analysis with individualised ROIs.
    """
    def __init__(self, data_maps, atlas: list, out_dir):
        """

        :param data_maps: list of numpy arrays, usually individual contrast maps. data_maps[g][s,c] should return the
        contrast map c of individual s from group g
        :param atlas: here is a list of np.arrays
        :param out_dir: an output directory where resulting outputs should be stored
        """
        super().__init__(data_maps, atlas, out_dir)

    def __init_atlas__(self):
        if len(self.atlas) != len(self.data_maps):
            sys.exit('Miscorrespondance between data maps and individual masks')
        # self.atlas.check()
        # self.n_rois = self.atlas.get_number_of_rois()
        # self.__plot_atlas__() should not be run in this child class
        # self.__plot_rois__()

    def __plot_rois__(self):
        self.roi_plot_files = []
        roi_plot_dir = create_dir(opj(self.out_dir, 'roi_plots'))
        for g, gr in enumerate(self.groups):
            list_subjects = gr.get_list_subjects()
            for r, roi_file in enumerate(self.atlas[g]):
                su_id = list_subjects[r].get_suID()
                roi = RegionOfInterest(file=roi_file, name=su_id, color='r')
                roi_plot_f = opj(roi_plot_dir, 'roi_{0}_{1}.png'.format(r + 1, su_id))
                self.roi_plot_files.append(roi_plot_f)
                if not ope(roi_plot_f):
                    roi.plot(out_file=roi_plot_f)

    def set_groups(self, groups):
        super().set_groups(groups)
        self.__plot_rois__()

    def print(self, msg):
        print('** Individualised ROI Analyzer ' + msg)

    def __prepare_filenames__(self):
        pass

    def compute_contrasts(self):
        """
        For all regions of interest : 1) load the ROI mask and computes average contrast values for all subjects and all
        contrast maps.
        Data are stored into a pandas data frame that is stored into the self.df class structure.
        """
        # Get a time stamp at the beginning of the global computation
        t0 = time.time()
        #self.print('Start computing mean contrast values in {0} ROIs for {1} subjects ... '.format(self.n_rois, self.n_total_subjects))

        # Prepare lists for the data frame
        l_sub, l_grp, l_val, l_con, l_con_idx = [], [], [], [], []

        # Get a time stamp at the beginning of the ROI computation
        t1 = time.time()
        # Load ROI data
        for g, gr in enumerate(self.groups):
            for s, su in enumerate(gr.get_list_subjects()):
                roi_file = self.atlas[g][s]
                roi_nii = nib.load(roi_file)
                R = roi_nii.get_data()
                # Define the ROI mask once for all contrast maps
                mask_roi = np.nonzero(R)  # returns 3-list of array indices
                n_voxels = len(mask_roi[0])  # Just count the number of voxels
                for c, contrast in enumerate(gr.get_contrasts()):
                    # Load Nifti of the statistical map
                    nifti_vol = nib.load(self.data_maps[g][s, c])
                    y_data = nifti_vol.get_data()
                    # Compute average value (where ROI mask is > 0)
                    # con_value = np.mean(y_data[mask_roi])
                    con_value = np.nanmean(y_data[mask_roi])
                    # Append values to lists
                    l_sub.append(su.get_id())  # Subject identification number
                    l_grp.append(gr.name)  # Group name
                    l_con.append(contrast.get_name())  # Contrast name
                    l_val.append(con_value)  # Contrast value
                    l_con_idx.append(contrast.get_spm_index())
            #self.print('... ROI {0}/{1} computed in {2}s ({3} voxels)'.format(self.n_rois, round(time.time() - t1, 2), n_voxels))

        roi_data_dict = {K_DF_ROI_GRP: l_grp,
                         K_DF_ROI_SUB: l_sub,
                         K_DF_ROI_CON: l_con,
                         K_DF_ROI_VAL: l_val,
                         K_DF_ROI_CON_IDX: l_con_idx}
        self.roi_df = pd.DataFrame(roi_data_dict, columns=K_DF_COLS_RA)
        # self.print('... ALL {0} ROI data of {1} computed in {2}s'.format(self.n_rois, self.n_total_subjects,
        #                                                                  int(time.time() - t0)))


    def plot(self):
        print(self.roi_df)
        sns.swarmplot()


class IndividualisedLongitudinalROIAnalyzer(IndividualisedROIAnalyzer):
     def __init__(self, data_maps, atlas: list, out_dir):
         """

         :param data_maps: list of numpy arrays, usually individual contrast maps. data_maps[g][s,c] should return the
         contrast map c of individual s from group g
         :param atlas: here is a list of np.arrays
         :param out_dir: an output directory where resulting outputs should be stored
         """
         super().__init__(data_maps, atlas, out_dir)

