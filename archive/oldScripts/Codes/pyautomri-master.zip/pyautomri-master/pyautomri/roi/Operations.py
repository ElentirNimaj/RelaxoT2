import nibabel
import nibabel as nib
import numpy as np
import sys


def get_data_in_roi(image_file, roi_file):
    """
    Given an image 3D volume file (nifti) and a ROI volume file (nifti), returns the image data inside the ROI
    :param image_file: str, path to the 3D image file
    :param roi_file: str, path to the 3D ROI file
    :return: data of imageFile that is inside the roiFile
    """
    b = nib.load(image_file)
    r = nib.load(roi_file)
    imo = ImageMaskOperations(image_file=b, mask_file=r)
    return imo.get_data_in_mask()


def get_data_from_multiple_rois(image_file, list_roi_files):
    """
    :param image_file:
    :param list_roi_files:
    :return:
    """
    total_data = np.empty((0), dtype=float)
    b = nib.load(image_file)
    for roiFile in list_roi_files:
        r = nib.load(roiFile)
        imo = ImageMaskOperations(image_file=b, mask_file=r)
        total_data = np.append(total_data, imo.get_data_in_mask())
    return total_data


def check_input_is_ok(image):
    if isinstance(image, str):
        return nibabel.load(image)
    elif isinstance(image, nibabel.Nifti1Image):
        return image
    else:
        sys.exit('Unknown data type for ImageMaskOperations : ' + type(image))


class ImageMaskOperations:
    """
    This class provides useful functions relative to the use of a float image and a mask image
    """
    def __init__(self, image_file, mask_file):
        """
        Initializes the class with the image file and the mask file. They must share the same dimensions and resolutions
        :param image_file: 3D float Image, image containing values
        :param mask_file: 3D int Image, specifies the region of interest
        """
        self.image_f = check_input_is_ok(image_file)
        self.mask_f = check_input_is_ok(mask_file)
        self.image = self.image_f.get_fdata()
        self.mask = self.mask_f.get_fdata()
        self.mask_indices = np.nonzero(self.mask)

    def get_data_in_mask(self):
        """
        :return: a flattened 1D numpy array with data in the Mask
        """
        return self.image[self.mask_indices]

    def get_average_image_in_mask(self):
        """
        :return: average value of image inside the Mask region
        """
        return np.nanmean(self.image[self.mask_indices])

    def get_num_voxels_in_mask(self):
        """
        :return: the number of vaoxels inside the Mask
        """
        return np.sum(self.mask_indices)

    def get_max_value_in_mask(self):
        """
        :return: the maximum value of Image inside Mask
        """
        return max(self.get_data_in_mask())

    def get_barycenter_of_mask(self):
        """
        This function must be used with image files in MNI space.
        :return: MNI coordinates of the barycenter of the Mask
        """
        coords = self.mask_indices
        barycenter = [0, 0, 0]
        sum = 0
        for i in range(len(coords[0])):
            x, y, z = (coords[0][i], coords[1][i], coords[2][i])
            if ~np.isnan(self.image[x, y, z]):
                val = self.image[x, y, z]
                sum = sum + val
                barycenter[0] = barycenter[0] + val * x
                barycenter[1] = barycenter[1] + val * y
                barycenter[2] = barycenter[2] + val * z
        # Compute barycenter coordinates
        barycenter = [b / sum for b in barycenter]
        x, y, z, c = self.image_f.affine.dot([barycenter[0], barycenter[1], barycenter[2], 1])
        return [round(x, 2), round(y, 2), round(z, 2)]

    def get_mni_coordinates_peak_in_mask(self):
        """
        This function must be used with image files in MNI space.
        :return: MNI coordinates of the maximum value of image inside Mask
        """
        coords = self.mask_indices
        index_max = np.argmax(self.image[self.mask > 0])
        (i, j, k) = (coords[0][index_max], coords[1][index_max], coords[2][index_max])
        x, y, z, c = self.image_f.affine.dot([i, j, k, 1])
        return x, y, z

    def count_voxels_above_threshold_in_mask(self, threshold):
        """
        :param threshold: float value
        :return: The number of voxels of Image with value > threshold inside the Mask
        """
        return np.sum(self.get_data_in_mask() > threshold)

