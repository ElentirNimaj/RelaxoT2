import math
import sys
import numpy as np
import os
import scipy
import warnings

warnings.simplefilter("ignore", UserWarning)  # with swarmplot sometimes too many warnings
import seaborn as sns
from matplotlib.gridspec import GridSpec
from os.path import exists as ope, join as opj, dirname as opd, basename as opb
from matplotlib import pyplot as plt
from pyautomri.plot.StatisticalMapping import plot_stat_map_and_atlas, ActivationPlot
from pyautomri.utils.utils import get_pval_alpha
from pyautomri.roi.Analyzer import K_DF_ROI_ROI, K_DF_ROI_CON, K_DF_ROI_VAL, K_DF_ROI_CON_IDX, K_DF_ROI_SUB, \
    K_DF_ROI_TMP, K_DF_ROI_GRP
from pyautomri.plot.Montages import Montage1D


def p_value_to_legend(p_value):
    """Given a p-value, creates a text to annotate the matplotlib plots"""
    text = None
    if p_value < .05:
        text = 'p<0.05'
    if p_value < .001:
        text = 'p<0.001'
    if p_value < .00001:
        text = 'p<1E-5'
    return text


def p_value_to_asterisk(p_value):
    text = None
    if p_value < .05:
        text = '*'
    if p_value < .001:
        text = '**'
    if p_value < .00001:
        text = '***'
    return text


class ROIGraph:
    """
    Parent class to generate two parts graphs with a ROI view file in the top and a graph in the bottom.
    """

    def __init__(self, df, roi, output_file):
        """

        :param df:
        :param roi: type RegionOfInterest
        :param output_file:
        """
        self.__set_dataframe__(df)
        self.__set_roi__(roi)
        self.__set_output_file__(out_file=output_file)
        self.__set_default_params__()
        # Define temporary filenames
        self.__view_file__ = opj(opd(self.output_file), opb(self.output_file)[:-4] + '_view.png')
        self.__plot_file__ = opj(opd(self.output_file), opb(self.output_file)[:-4] + '_plot.png')
        self.view_file_set = False
        self.remove_view_file_after_plot = None
        # Default values
        self.x_axis = None
        self.y_axis = None

    def __set_dataframe__(self, df):
        self.df = df
        self.n_rois = len(self.df[K_DF_ROI_ROI].unique())
        self.n_con = len(self.df[K_DF_ROI_CON].unique())

    def __set_roi__(self, roi):
        self.roi = roi

    def __set_output_file__(self, out_file):
        self.output_file = out_file

    def __set_default_params__(self):
        """
        For a ROI plot
        1. Filter by ROI name
        2. Default plot axis is
        3. Default seaborn palette
        """
        self.__filter_dataframe__()
        self.__set_default_plot_axis__()
        self.__set_palette__()

    def __filter_dataframe__(self):
        """
        For a ROI plot, the data frame is filtered to extract only values from the current ROI.
        """
        self.df = self.df[self.df[K_DF_ROI_ROI] == self.roi.get_name()]

    def __set_default_plot_axis__(self):
        """ To implement in children classes """
        pass

    def __set_palette__(self):
        """
        Default color palette
        """
        self.palette = sns.color_palette()

    def __add_title_to_graph__(self):
        """ To implement in children classes """
        pass

    def set_view_file(self, view_file, remove_after_plot=False):
        """
        Sets a user-defined view file
        :param view_file: str, path to a png file.
        """
        if not ope(view_file):
            sys.exit('Provided view file {0} does not exist to create {1}'.format(view_file, self.output_file))
        self.__view_file__ = view_file
        self.view_file_set = True
        self.remove_view_file_after_plot = remove_after_plot

    def plot_roi(self):
        """
        If the user did not provide a view file, plot the default ROIplot.
        """
        self.roi.plot(out_file=self.__view_file__)

    def plot_graph(self):
        """ To implement in children classes """
        pass

    def plot(self):
        """
        Check existence of the output file and of the graph file and the view files before plotting them.
        """
        if not ope(self.output_file):
            if not ope(self.__plot_file__):
                self.plot_graph()
            if not ope(self.__view_file__):
                self.plot_roi()
            self.perform_montage()

    def perform_montage(self):
        """ To implement in children classes """
        pass


class SingleROIMultipleContrasts(ROIGraph):
    """
    Class that allows to perform a ROI plot, given a data frame that was computed with the ROI analyzer
    """

    def __init__(self, df, roi, output_file):
        """

        :param df:
        :param roi: type RegionOfInterest
        :param output_file:
        """
        super().__init__(df, roi, output_file)
        self.__set_default_plot_axis__()

    def __set_default_plot_axis__(self):
        self.x_axis = K_DF_ROI_CON
        self.y_axis = K_DF_ROI_VAL
        self.hue_axis = None

    def set_xlabel_is_contrast_index(self):
        self.x_axis = K_DF_ROI_CON_IDX

    def __add_title_to_graph__(self):
        plt.title('Contrast values in ROI {0}'.format(self.roi.get_name()))

    def plot_graph(self, graph_type='swarmplot'):
        # Home-made Bonferroni correction (nROIs x nContrasts = N), then p<alpha/N is OK
        n_bonferroni = self.n_rois * self.n_con
        alpha_bonferroni = 0.05 / n_bonferroni
        # Figure size properties
        # Count the number of unique x labels to adjust the figure size
        n_x = len(self.df[self.x_axis].unique())
        fig_height = 3.5
        fig_width = n_x / 2.5
        figsize = (fig_width, fig_height)
        # Count the maximum number of y elements across the x labels to adjust the marker size
        n_y = len(self.df[K_DF_ROI_SUB].unique())
        if n_y > 50:
            marker_size = 4
        else:
            marker_size = 5
        plt.figure(figsize=figsize)
        plot_types = ['swarmplot', 'boxplot', 'boxenplot', 'barplot', 'scatterplot', 'lineplot', 'violinplot']
        if graph_type == 'swarmplot':
            sns.swarmplot(x=self.x_axis, y=self.y_axis, hue=self.hue_axis, data=self.df, palette=self.palette,
                          s=marker_size)
        elif graph_type == 'boxplot':
            sns.boxplot(x=self.x_axis, y=self.y_axis, hue=self.hue_axis, data=self.df, palette=self.palette)
        elif graph_type == 'boxenplot':
            sns.boxenplot(x=self.x_axis, y=self.y_axis, hue=self.hue_axis, data=self.df, palette=self.palette)
        elif graph_type == 'barplot':
            sns.barplot(x=self.x_axis, y=self.y_axis, hue=self.hue_axis, data=self.df, palette=self.palette)
        elif graph_type == 'scatterplot':
            sns.scatterplot(x=self.x_axis, y=self.y_axis, hue=self.hue_axis, data=self.df, palette=self.palette)
        elif graph_type == 'lineplot':
            sns.lineplot(x=self.x_axis, y=self.y_axis, hue=self.hue_axis, data=self.df, palette=self.palette)
        elif graph_type == 'violinplot':
            sns.violinplot(x=self.x_axis, y=self.y_axis, hue=self.hue_axis, data=self.df, palette=self.palette)
        else:
            msg = 'ROIPlot : unknown plot type : ' + graph_type + '\n'
            msg += 'Choose among following types :\n'
            for t in plot_types:
                msg += '\t-' + t + '\n'
            sys.exit(msg)
        # Add a zero line to situate the effects compared to 0
        ax = plt.gca()
        [x0, x1] = ax.get_xlim()
        plt.plot([x0, x1], [0, 0], '--k')
        # Rotate x labels if any x tick has more than 5 characters
        rotate_x_labels = any([len(tick.get_text()) > 5 for tick in ax.get_xticklabels()])
        if rotate_x_labels:
            for tick in ax.get_xticklabels():
                tick.set_rotation(90)
        # Adds a symbol when significant
        self.add_labels_significancy(rotation=90, alpha_bonferroni_corr=alpha_bonferroni)
        # Add title and save
        self.__add_title_to_graph__()
        plt.savefig(self.__plot_file__, dpi=150, bbox_inches='tight')
        plt.close()

    def add_labels_significancy(self, rotation=0, alpha_bonferroni_corr=None):
        # Iterate over unique contrasts
        for c, contrast in enumerate(self.df[K_DF_ROI_CON].unique()):
            # Get vector of contrast values
            y = self.df[self.df[K_DF_ROI_CON] == contrast][K_DF_ROI_VAL]
            # Perform statistical test
            [_, pval] = scipy.stats.ttest_1samp(y, popmean=0)
            text = text = p_value_to_legend(pval)
            if text:
                # Display options whether the contrast is on average negative or positive
                ax = plt.gca()
                ymin, ymax = ax.get_ylim()
                if np.mean(y) < 0:
                    col, va, ypos = ('r', 'bottom', 0.97 * ymin)
                else:
                    col, va, ypos = ('g', 'top', 0.97 * ymax)
                bbox_props = dict(boxstyle="round,pad=0.3", fc=col, alpha=get_pval_alpha(pval), ec='k')
                if alpha_bonferroni_corr:
                    if pval < alpha_bonferroni_corr:
                        text = text + '$^{*}$'
                plt.annotate(text=text, xy=(c, ypos), va=va, ha='center', fontsize=6, bbox=bbox_props,
                             rotation=rotation)

    def plot(self, type='swarmplot'):
        """

        :param type:
        :return:
        """
        if not ope(self.output_file):
            if not ope(self.__plot_file__):
                self.plot_graph(graph_type=type)
            if not ope(self.__view_file__):
                self.plot_roi()
            self.perform_montage()

    def perform_montage(self):
        # Create a vertical montage
        m = Montage1D(list_images=[self.__view_file__, self.__plot_file__], output_file=self.output_file,
                      delete_inputs=True)
        # Adjust to min width only if width(view file) > width(plot_file) : not good
        if len(self.df[self.x_axis].unique()) > 10:  # More than 15 x labels become difficult to read
            m.set_background_color(color=(255, 255, 255))  # white
            m.vertical_montage()
        else:
            m.vertical_montage_adjust_to_min_width()


class MultipleROISSingleContrast(SingleROIMultipleContrasts):
    """

    """

    def __init__(self, df, atlas, output_file, contrast=None):
        # Define contrast 1st because this value is used in the __filter_dataframe__()
        self.contrast = contrast
        self.stat_map = None
        super().__init__(df=df, roi=atlas, output_file=output_file)
        self.threshold = None

    def __set_roi__(self, atlas):
        """
        This method is overwritten because a dictionary of ROI is given rather than a ROI only
        :param atlas:
        :return:
        """
        self.atlas = atlas

    def __set_default_params__(self):
        """
        For a ROI plot
        1. Filter by ROI name
        2. Default plot axis is
        3. Default seaborn palette
        """
        if self.contrast:
            self.__filter_dataframe__()
        self.__set_default_plot_axis__()
        self.__set_palette__()

    def __set_palette__(self):
        self.palette = [roi.get_color() for roi in self.atlas.get_list_rois()]

    def __set_default_plot_axis__(self):
        self.x_axis = K_DF_ROI_ROI
        self.y_axis = K_DF_ROI_VAL
        self.hue_axis = None

    def __filter_dataframe__(self):
        """
        For a Multiple ROIs plot, the data frame is filtered to extract only values from the current ROI.
        """
        self.df = self.df[self.df[K_DF_ROI_CON] == self.contrast.get_legend()]

    def add_labels_significancy(self, rotation=0, alpha_bonferroni_corr=None):
        for r, roi in enumerate(self.df[K_DF_ROI_ROI].unique()):
            # Get vector of contrast values
            y = self.df[self.df[K_DF_ROI_ROI] == roi][K_DF_ROI_VAL]
            # Perform statistical test
            [_, pval] = scipy.stats.ttest_1samp(y, popmean=0)
            text = p_value_to_legend(pval)
            if text:
                # Display options whether the contrast is on average negative or positive
                ax = plt.gca()
                ymin, ymax = ax.get_ylim()
                if np.mean(y) < 0:
                    col, va, ypos = ('r', 'bottom', 0.97 * ymin)
                else:
                    col, va, ypos = ('g', 'top', 0.97 * ymax)
                bbox_props = dict(boxstyle="round,pad=0.3", fc=col, alpha=get_pval_alpha(pval), ec='k')
                if alpha_bonferroni_corr:
                    if pval < alpha_bonferroni_corr:
                        text = text + '$^{*}$'
                plt.annotate(text=text, xy=(r, ypos), va=va, ha='center', fontsize=6, bbox=bbox_props,
                             rotation=rotation)

    def set_statistical_map(self, stat_map, threshold=0):
        self.stat_map = stat_map
        self.threshold = threshold

    def plot_roi(self):
        """
        In this case, we plot a statistical map. So parent class function name should be less specific.
        :return:
        """
        if self.stat_map:
            ap = ActivationPlot(stat_map=self.stat_map, output_file=self.__view_file__)
            ap.set_display_mode(dm='ortho')
            ap.set_black_background(black_bg=False)
            ap.set_color_bar(colorbar=True)
            if self.threshold != 0:
                ap.set_threshold(threshold=self.threshold)
                title = '{0} z>{1}'.format(self.contrast.get_name(), round(self.threshold, 1))
                ap.set_title(title)
            ap.set_cut_coords(cut_coords=self.atlas.get_atlas_coordinates())
            ap.plot()
            ap.add_contours_of_roi_atlas(atlas=self.atlas, alpha=.8, filled=False, lw=1.5)
            ap.save()
        else:
            self.atlas.plot(out_file=self.__view_file__, black_bg=False, axes=None, alpha=1)

    def __add_title_to_graph__(self):
        if self.contrast:
            title = '{0} values in ROIs {1}'.format(self.contrast.get_legend(), self.atlas.get_atlas_name())
        else:
            title = 'Data values in ROIs {0}'.format(self.atlas.get_atlas_name())
        plt.title(title)


class LongitudinalSingleROIPlot(ROIGraph):
    """

    """

    def __init__(self, df, roi, out_file, contrast, group_name):
        self.contrast = contrast
        self.group_name = group_name
        super().__init__(df, roi, out_file)
        self.timepoints = self.df[K_DF_ROI_TMP].unique()

    def __filter_dataframe__(self):
        roi_filter = self.df[K_DF_ROI_ROI] == self.roi.get_name()
        con_filter = self.df[K_DF_ROI_CON] == self.contrast
        grp_filter = self.df[K_DF_ROI_GRP] == self.group_name
        self.df = self.df[roi_filter & con_filter & grp_filter]

    def set_group_statistical_maps(self):
        # todo
        pass

    def plot_graph(self, plot_type='swarmplot', subject=None):
        # Create figure
        n_x = len(self.df[K_DF_ROI_TMP].unique())
        figsize = (n_x, 4)
        roi_col = self.roi.get_color()
        plt.figure(figsize=figsize)
        # Plot
        if subject:
            # Filter data from subject
            df_su = self.df[self.df[K_DF_ROI_SUB] == int(subject.get_id())]
            # Swarmplot of subject data set
            ax = sns.swarmplot(x=K_DF_ROI_TMP, y=K_DF_ROI_VAL, hue=K_DF_ROI_ROI, data=df_su, palette=[roi_col])
            sns.lineplot(x=K_DF_ROI_TMP, y=K_DF_ROI_VAL, hue=K_DF_ROI_ROI, data=self.df, palette=[roi_col])
        else:
            # Perform group plot only
            if plot_type == 'swarmplot':
                ax = sns.swarmplot(x=K_DF_ROI_TMP, y=K_DF_ROI_VAL, hue=K_DF_ROI_ROI, data=self.df, palette=[roi_col])
                sns.lineplot(x=K_DF_ROI_TMP, y=K_DF_ROI_VAL, hue=K_DF_ROI_ROI, data=self.df, palette=[roi_col])
            elif plot_type == 'barplot':
                ax = sns.barplot(x=K_DF_ROI_TMP, y=K_DF_ROI_VAL, hue=K_DF_ROI_ROI, data=self.df, palette=[roi_col])
            else:
                sys.exit('Unknown plot type ' + plot_type)
        # Tiny stuff
        ax.get_legend().remove()
        plt.title('Contrast ' + self.contrast + ' in ' + self.roi.get_name())
        plt.plot([0, n_x - 1], [0, 0], '--k')
        self.add_labels_significancy()
        plt.savefig(self.__plot_file__, bbox_inches='tight')
        plt.close()

    def add_labels_significancy(self, rotation=0):
        # Retrieve data from first session
        y0 = self.df[self.df[K_DF_ROI_TMP] == self.timepoints[0]][K_DF_ROI_VAL]
        for t, timepoint in enumerate(self.timepoints):
            # Get vector of contrast values
            y = self.df[self.df[K_DF_ROI_TMP] == timepoint][K_DF_ROI_VAL]
            # Perform statistical test
            [_, pval] = scipy.stats.ttest_1samp(y, popmean=0)
            text = p_value_to_legend(pval)
            if text:
                # Display options whether the contrast is on average negative or positive
                ax = plt.gca()
                ymin, ymax = ax.get_ylim()
                if np.mean(y) < 0:
                    col, va, ypos = ('r', 'bottom', 0.97 * ymin)
                else:
                    col, va, ypos = ('g', 'top', 0.97 * ymax)
                bbox_props = dict(boxstyle="round,pad=0.3", fc=col, alpha=get_pval_alpha(pval), ec='k')
                # For timepoints that are different to the first one, compare to the first session
                if t > 0:
                    [_, pval_1st_session] = scipy.stats.ttest_rel(a=y, b=y0)
                    pval_rel_text = p_value_to_asterisk(pval_1st_session)
                    if pval_rel_text:
                        text = text + '$^{' + pval_rel_text + '}$'
                plt.annotate(text=text, xy=(t, ypos), va=va, ha='center', fontsize=6, bbox=bbox_props,
                             rotation=rotation)
            else:
                # Not statistically significant in this session but compared to first session ?
                if t > 0:
                    # Display options whether the contrast is on average negative or positive
                    ax = plt.gca()
                    ymin, ymax = ax.get_ylim()
                    if np.mean(y) < 0:
                        col, va, ypos = ('r', 'bottom', 0.97 * ymin)
                    else:
                        col, va, ypos = ('g', 'top', 0.97 * ymax)
                    bbox_props = dict(boxstyle="round,pad=0.3", fc=col, alpha=get_pval_alpha(pval), ec='k')
                    [_, pval_1st_session] = scipy.stats.ttest_rel(a=y, b=y0)
                    pval_rel_text = p_value_to_asterisk(pval_1st_session)
                    if pval_rel_text:
                        text = '$^{' + pval_rel_text + '}$'
                    plt.annotate(text=text, xy=(t, ypos), va=va, ha='center', fontsize=6, bbox=bbox_props,
                                 rotation=rotation)

    def plot(self, plot_type='swarmplot', montage_type='adjust_to_width', subject=None):
        """
        Perform a figure with data location on top and a graph on the bottom displaying longitudinal dataset
        :param plot_type: 'swarmplot' or 'barplot' for the group data
        :param montage_type:
        :param subject: Longitudinal Subject instance, Set a subject to plot individual data
        :return:
        """
        if not ope(self.output_file):
            if not self.__view_file__:
                self.__view_file__ = opj(opd(self.output_file), opb(self.output_file)[:-4] + '_view.png')
            self.__plot_file__ = opj(opd(self.output_file), opb(self.output_file)[:-4] + '_plot.png')

            if not ope(self.__plot_file__):
                self.plot_graph(plot_type=plot_type, subject=subject)

            if not ope(self.__view_file__):
                self.plot_roi()

            # Create a vertical montage
            m = Montage1D(list_images=[self.__view_file__, self.__plot_file__], output_file=self.output_file,
                          delete_inputs=False)
            m.set_background_color(color=(255, 255, 255))
            m.set_title('Group {0}'.format(self.group_name))
            if montage_type == 'adjust_to_width':
                m.vertical_montage_adjust_to_min_width()
            else:
                m.vertical_montage_with_vertical_proportions([.35, .65])
            os.remove(self.__plot_file__)
            if ope(self.__view_file__):
                os.remove(self.__view_file__)


class LongitudinalMultipleROISPlot(ROIGraph):
    def __init__(self, df, atlas, out_file, contrast, group_name):
        self.contrast = contrast
        self.group_name = group_name
        super().__init__(df, atlas, out_file)
        self.timepoints = self.df[K_DF_ROI_TMP].unique()
        self.x_axis = K_DF_ROI_TMP
        self.y_axis = K_DF_ROI_VAL

    def __set_roi__(self, atlas):
        import math
        self.atlas = atlas
        # Define then number of rows and columns in the matplotlib graph
        nr = atlas.get_number_of_rois()
        if nr < 5:
            self.nrows, self.ncols = (1, nr)
            self.figsize = (8 * self.nrows, 2 * self.ncols)
        else:
            self.ncols = int(math.sqrt(nr))
            self.nrows = int(math.ceil(nr) / float(self.ncols))
            self.figsize = (4 * self.nrows, 4 * self.ncols)

    def __filter_dataframe__(self):
        con_filter = self.df[K_DF_ROI_CON] == self.contrast
        grp_filter = self.df[K_DF_ROI_GRP] == self.group_name
        self.df = self.df[con_filter & grp_filter]

    def prepare_figure(self):
        sns.set_context("talk")
        self.abs_max = self.df[self.y_axis].abs().max()
        self.y_min = self.df[self.y_axis].min()
        self.y_max = self.df[self.y_axis].max()
        self.fig = plt.figure(figsize=self.figsize)
        # Prepare grid of plots
        self.gs = GridSpec(self.nrows, self.ncols)

    def plot_graph(self, plot_type='swarmplot', subject=None):
        self.prepare_figure()
        # Prepare grid of plots
        self.gs.update(hspace=0.02, wspace=0.1)

        for r, roi in enumerate(self.atlas.get_list_rois()):
            # index row and index column
            ir, ic = r // self.ncols, r % self.ncols

            # Adds the subplot
            ax = self.fig.add_subplot((self.gs[ir, ic]))
            # Filter data frame for the ROI
            df = self.df[self.df[K_DF_ROI_ROI] == roi.get_name()]
            roi_col = roi.get_color()
            # Plot
            if subject:
                # Filter data from subject
                df_su = df[df[K_DF_ROI_SUB] == int(subject.get_id())]
                # Swarmplot of subject data set
                sns.swarmplot(x=K_DF_ROI_TMP, y=K_DF_ROI_VAL, data=df_su, palette=[roi_col], ax=ax)
                sns.lineplot(x=K_DF_ROI_TMP, y=K_DF_ROI_VAL, data=df_su, color=roi_col, ax=ax, ls='-', lw=4)
                sns.lineplot(x=K_DF_ROI_TMP, y=K_DF_ROI_VAL, data=df, color=roi_col, ax=ax, ls='--')
            else:
                # Perform group plot only
                sns.lineplot(x=K_DF_ROI_TMP, y=K_DF_ROI_VAL, data=df, color=roi_col, ax=ax)
            # Tiny stuff
            if len(self.timepoints) > 7:
                ax.set_xticks([])
                ax.set_xlabel('')
            if ir < self.nrows - 1 or ic > 0:  # if it is before the last line
                ax.set_xticks([])
                ax.set_xlabel('')
            if ic > 0:
                ax.set_yticks([])
                ax.set_ylabel('')

            ax.set_title(roi.get_name())
            # Rearrange limits
            ax.set_ylim(self.y_min, self.y_max)
            ax.set_xlim(-0.1, len(self.timepoints) - 0.9)
            plt.plot([0, len(self.timepoints) - 1], [0, 0], '--k')

        plt.savefig(self.__plot_file__, bbox_inches='tight')
        plt.close()

    def plot(self, plot_type='swarmplot', montage_type='adjust_to_width', subject=None):
        """
        Perform a figure with data location on top and a graph on the bottom displaying longitudinal dataset
        :param plot_type: 'swarmplot' or 'barplot' for the group data
        :param montage_type:
        :param subject: Longitudinal Subject instance, Set a subject to plot individual data
        :return:
        """
        if not ope(self.output_file):
            if not self.__view_file__:
                self.__view_file__ = opj(opd(self.output_file), opb(self.output_file)[:-4] + '_view.png')
            self.__plot_file__ = opj(opd(self.output_file), opb(self.output_file)[:-4] + '_plot.png')

            if not ope(self.__plot_file__):
                self.plot_graph(plot_type=plot_type, subject=subject)

            if not ope(self.__view_file__):
                self.atlas.plot(out_file=self.__view_file__)

            # Create a vertical montage
            m = Montage1D(list_images=[self.__view_file__, self.__plot_file__], output_file=self.output_file,
                          delete_inputs=False)
            m.set_background_color(color=(255, 255, 255))
            if subject:
                title = 'Subject {0} in {1}'.format(subject.get_id(), self.atlas.get_atlas_name())
            else:
                title = 'Group {0} in {1}'.format(self.group_name, self.atlas.get_name())
            m.set_title(title=title)
            if montage_type == 'adjust_to_width':
                m.vertical_montage_adjust_to_min_width()
            else:
                m.vertical_montage_with_vertical_proportions([.35, .65])
            os.remove(self.__plot_file__)
            if self.view_file_set and self.remove_view_file_after_plot:
                os.remove(self.__view_file__)
