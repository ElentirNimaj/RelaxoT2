"""
ROI
===

Provides
  1. Definitions of regions of interest
  2. Build ROIAtlases (set of regions of interest)
  3. Perform Analyses inside a set of ROIs

  >>> import pyautomri.roi

Create a simple ROIAtlas ::

  >>> from pyautomri.roi.Atlas import CSV2Atlas
  >>> "Provide a path to a ROIAtlas csv file"
  >>> roi_atlas = CSV2Atlas(csv_file='/home/user/Projects/my_project/config/ROIAtlas_Motor_Areas.csv').get_atlas()
  >>> print(roi_atlas)  # it is a dictionary

"""