import sys
from os.path import exists as ope, abspath as opa
import nilearn.plotting
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from nilearn.plotting.img_plotting import MNI152TEMPLATE
import nibabel


class RegionOfInterest:
    """
    Defines a region of interest in MNI space.
    A ROI has the following attributes that must be set by the user
        a name for labeling plots, legends etc...
        a nifti file (in MNI space) for computing measurements
        a color (for plotting) must be set by the user.
        a label (default is 1), the ROI has a label value indicating voxels belonging to the ROI in the nifti file
    """
    def __init__(self, file, name, color):
        self.file = opa(file)
        self.name = name
        self.color = color
        # Default Binary mask has value one to indicate the ROI
        self.label = 1

    def __str__(self):
        return '-ROI "{0}" (color {1})\n  {2}'.format(self.name, self.color, self.file)

    def set_label(self, label):
        self.label = label

    def get_name(self):
        return self.name

    def get_color(self):
        return self.color

    def get_file(self):
        return self.file

    def get_label(self):
        return self.label

    def set_color(self, color):
        self.color = color

    def set_name(self, name):
        self.name = name

    def set_file(self, file):
        self.file = opa(file)

    def check(self):
        """

        :return:
        """
        if not hasattr(self, 'name'):
            msg = 'ROI has no name. Edit the ROI'.format()
            sys.exit(msg)
        if not ope(self.file):
            msg = 'ROI {0} has an unexisting mask filename. Create the appropriate mask and save it : \n\t {1}'.format(
                self.name, self.file)
            sys.exit(msg)

    def get_binary_colormap(self):
        """
        Creates a Matplotlib binary colormap for making some plots
        :return: Matplotlib binary colormap
        """
        return LinearSegmentedColormap.from_list('roi_cmap', [(0, self.color), (1, self.color)])

    def plot(self, out_file=None, bg_img=MNI152TEMPLATE, title=None, display_mode='ortho', cut_coords=None, dim='auto', alpha=1, atlas=None, black_bg=True):
        """

        :param out_file:
        :param bg_img:
        :return:
        """
        if isinstance(bg_img, str):
            if bg_img != MNI152TEMPLATE:
                nii_bg = nibabel.load(bg_img)
                if len(nii_bg.get_fdata().shape) == 4:
                    print('[ROI Plot] Background image has 4 dimensions, a mean volume is computed over the 4th dimension')
                    bg_img = nilearn.image.mean_img(bg_img)
        elif isinstance(bg_img, nibabel.Nifti1Image):
            bg_img = bg_img
        elif isinstance(bg_img, nilearn.plotting.img_plotting._MNI152Template):
            bg_img = bg_img
        else:
            sys.exit('Unknown type for bg_img in ROI.plot() : ' + str(type(bg_img)))
        if title is None:
            title = self.name
        ax = nilearn.plotting.plot_roi(roi_img=self.file, bg_img=bg_img, display_mode=display_mode, draw_cross=False,
                                       cut_coords=cut_coords, annotate=True, cmap=self.get_binary_colormap(),
                                       dim=dim, title=title, alpha=alpha, black_bg=black_bg)
        if atlas:
            atlas.add_contours_list_rois_to_display(display=ax)
        if out_file:
            plt.savefig(out_file)
            plt.close()
        else:
            return ax

    def add_contours_to_display(self, display,  alpha=.6, filled=False, lw=2):
        """
        Adds contours of a single regions of interest to a matplotlib display
        :param display: nilearn display
        :param alpha: float, transparency in [0,1]
        :param filled: bool, fill ROI or not
        :param lw: linewidth
        """
        display.add_contours(self.file, cmap=self.get_binary_colormap(), alpha=alpha, filled=filled, levels=[.5], linewidths=lw)

    def add_overlay_to_display(self, display, alpha=1):
        display.add_overlay(self.file, cmap=self.get_binary_colormap(), alpha=alpha)

    def get_barycenter(self):
        """
        Get barycenter in the MNI space.
        The calculation si performed in the ImageMaskOperations class.
        :return: (x,y,z) : MNI coordinates casted as a triplet of int values
        """
        from pyautomri.roi.Operations import ImageMaskOperations
        import nibabel
        mask = nibabel.load(self.file)
        imo = ImageMaskOperations(image_file=mask, mask_file=mask)
        [x, y, z] = imo.get_barycenter_of_mask()
        return [int(x), int(y), int(z)]