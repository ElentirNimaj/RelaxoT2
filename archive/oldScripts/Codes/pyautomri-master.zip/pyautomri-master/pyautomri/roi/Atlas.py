import sys
import warnings
warnings.filterwarnings('ignore', message="The import path 'nilearn.input_data'")
import pandas as pd
import nibabel
import numpy as np
import nilearn
import nilearn.plotting
import matplotlib.pyplot as plt
import seaborn as sns
from itertools import compress
from os.path import join as opj, exists as ope, basename as opb, dirname as opd
from nltools.mask import create_sphere
from nilearn.plotting.img_plotting import MNI152TEMPLATE
from pyautomri.roi.Operations import ImageMaskOperations
from pyautomri.roi.ROI import RegionOfInterest
from pyautomri.utils.colors import DEFAULT_LIST_ROI_COLORS
from pyautomri.utils.utils import create_dir
from pyautomri.plot.Montages import Montage1D, montage_imagemagick

PREFIX_ROI_ATLAS_CSV_FILE = 'ROIAtlas_'


class ROIAtlas:
    """
    Class to create an atlas: a set of regions of interest.
    """

    def __init__(self, name='Default_Atlas_Name'):
        """
        Initializes the set of regions of interest, just with a name
        :param name:
        """
        self.atlas_name = name
        self.list_rois = []  # Empty list of regions of interest
        self.list_rois_to_plot = []  # Empty list of regions of interest
        self.rois_coord = []  # Empty (x,y,z) coordinates to center view on the set of ROIs
        self.n_rois = 0  # Initializes the attribute "n_rois"
        self.atlas = {}  # Initializes an empty set of ROIs

    def __str__(self):
        """
        Prints information regarding this set of ROIs
        :return:
        """
        msg = '--- Atlas "{0}" with {1} ROIs ---\n'.format(self.atlas_name, len(self.list_rois))
        for r, roi in enumerate(self.list_rois):
            msg += '\tROI #{0}. {1} file: {2}\n'.format(r + 1, roi.get_name(), opb(roi.get_file()))
        return msg

    def get_atlas_name(self):
        """
        :return: Atlas nickname
        """
        return self.atlas_name

    def get_roi(self, roi_index):
        if roi_index < self.n_rois:
            return self.list_rois[roi_index]
        else:
            sys.exit('Could not return ROI index {0} from ROIAtlas {1}'.format(roi_index, self.atlas_name))

    def get_atlas_coordinates(self):
        """
        Get optimal (x,y,z) MNI coordinates to create an orthoplot of the ROIAtlas
        :return:
        """
        if not self.rois_coord:
            self.computes_rois_coord()
        return self.rois_coord

    def get_list_rois(self):
        """
        Gets the list of regions of interest composing the ROIAtlas
        :return: a list of RegionOfInterest elements
        """
        return self.list_rois

    def get_list_rois_to_plot(self):
        """
        Gets the list of regions of interest that will be plotted
        :return:
        """
        return list(compress(self.list_rois, self.list_rois_to_plot))  # Filter out rois not to plot

    def get_number_of_rois(self):
        """
        :return: int, number of ROIs in the list
        """
        return self.n_rois

    def update_rois_count(self):
        """
        Update the number of ROIs
        :return:
        """
        self.n_rois = len(self.list_rois)

    def set_atlas_name(self, atlas_name):
        self.atlas_name = atlas_name

    def set_list_of_rois(self, list_rois, list_rois_to_plot):
        for roi in list_rois:
            self.add_region_of_interest(roi)
        self.list_rois_to_plot = list_rois_to_plot

    def set_palette(self, pal):
        """
        Applies a palette to the ROIAtlas
        :param pal:
        :return:
        """
        if isinstance(pal, sns.palettes._ColorPalette):
            for r, roi in enumerate(self.list_rois):
                roi.set_color(pal[r])
        else:
            sys.exit('Please use a sns.palettes._ColorPalette instance when applying to a ROIAtlas')

    def add_region_of_interest(self, roi, plot=True):
        """
        Adds a RegionOfInterestInstance
        :param plot:
        :param roi:
        :return:
        """
        self.list_rois.append(roi)
        if plot:
            self.list_rois_to_plot.append(roi)
        self.update_rois_count()

    def add_roi(self, roi_name, roi_file, color=None, exclude_roi_from_atlas_plot=False):
        """
        Adds a roi to the set of regions of interest. Creates a RegionOfInterest object with the specified arguments.
        :param roi_name: str, ROI name
        :param roi_file: str, path to the ROI nifti file
        :param color: str, color (matplotlib style : 'blue' or hexadecimal code). If not provided, default is used.
        :param exclude_roi_from_atlas_plot: we give the user the possibility not to plot an ROI when plotting an atlas
        """
        if color:
            col = color
        else:
            col = DEFAULT_LIST_ROI_COLORS[self.n_rois]
        # Create a region of interest and append it to the list of rois
        roi = RegionOfInterest(file=roi_file, name=roi_name, color=col)
        self.add_region_of_interest(roi=roi, plot=not exclude_roi_from_atlas_plot)

    def add_sphere_roi(self, center, radius, roi_name, out_file, ref_file, color=None,
                       exclude_roi_from_atlas_plot=False):
        """

        :param exclude_roi_from_atlas_plot:  we give the user the possibility not to plot an ROI when plotting an atlas
        :param color: str, , color (matplotlib style : 'blue' or hexadecimal code). If not provided, default is used.
        :param ref_file: str, path to the brain mask associated with this MNI coordinate
        :param out_file: str, path where to save the ROI nifti file
        :param roi_name: str, ROI name
        :param center: (x,y,z) MNI coordinates
        :param radius: float, sphere radius (mm)
        :return:
        """
        if color:
            col = color
        else:
            col = DEFAULT_LIST_ROI_COLORS[self.n_rois]
        if not ope(out_file):
            mask = create_sphere([center], radius=[radius], mask=ref_file)
            if not np.any(mask.get_data() > 0):
                msg = '-----------------------------SPHERICAL ROI CREATION ERROR ------------------------------------\n'
                msg += 'Error when creating a spherical ROI at ({0},{1},{2})\n'.format(center[0], center[1], center[2])
                msg += 'Check that this MNI coordinate is inside the provided reference file below\n'
                msg += ref_file
                sys.exit(msg)
            nibabel.save(mask, out_file)
        self.add_roi(roi_name=roi_name, roi_file=out_file, color=col,
                     exclude_roi_from_atlas_plot=exclude_roi_from_atlas_plot)

    def set_rois_coord(self, rois_coord):
        """
        This function allows the user to provide the (x,y,z) set of coordinates to center the ortho view that will be created
        :param rois_coord: list, (x,y,z) MNI coordinates to center an ortho view on the set of ROIs
        """
        self.rois_coord = rois_coord

    def computes_rois_coord(self):
        """
        Automatic way of guessing a "best" (x,y,z) coordinates triplet to center view.
        x is the x coordinate of the 1st ROI barycenter
        y is the y coordinate of the 2nd ROI barycenter
        z is the z coordinate of the 3rd ROI barycenter (if more than 2 rois, otherwise 2nd ROI)
        """
        lx, ly, lz = [], [], []
        for roi in self.list_rois[:min(self.n_rois, 3)]:
            mask = nibabel.load(roi.get_file())
            iam = ImageMaskOperations(image_file=mask, mask_file=mask)
            x, y, z = [int(c) for c in iam.get_barycenter_of_mask()]
            lx.append(x)
            ly.append(y)
            lz.append(z)
        if len(self.list_rois) > 2:
            self.rois_coord = [lx[0], ly[1], lz[2]]  # Center 3 coordinates each on the 3 first ROIs
        elif len(self.list_rois) == 1:
            self.rois_coord = [lx[0], ly[0], lz[0]]
        else:
            self.rois_coord = [lx[0], ly[1], lz[1]]

    def plot(self, out_file, bg_img=MNI152TEMPLATE, alpha=1, dim=None, title=None, display_mode='ortho',
             cut_coords=None, black_bg=True, as_contour=False):
        """
        Writes a figure (.png file) representing the set of ROIs
        :param out_file: str, path to the output PNG file
        :param bg_img:
        :param black_bg:
        :param alpha:
        :param dim:
        :param title:
        :param display_mode:
        :param cut_coords:
        :return:
        """
        # TODO : use the self.list_rois_to_plot value
        if not ope(out_file):
            title = title if title else self.atlas_name
            # title = '{0} ({1} ROIs)'.format(self.atlas_name, self.n_rois)
            if isinstance(bg_img, nibabel.Nifti1Image):
                pass
            elif isinstance(bg_img, str):
                if bg_img != MNI152TEMPLATE:
                    nii_bg = nibabel.load(bg_img)
                    if len(nii_bg.get_fdata().shape) == 4:
                        print('[Atlas Plot] Background image has 4 dimensions, a mean volume is computed over'
                              ' the 4th dimension')
                        bg_img = nilearn.image.mean_img(bg_img)
            # If cut coords not provided, compute ROI coordinates
            if display_mode == 'ortho' and not cut_coords:
                self.computes_rois_coord()  # Computes the ROI coordinates if not already done
                cut_coords = self.rois_coord
            d = self.list_rois[0].plot(out_file=None, bg_img=bg_img, title=title, display_mode=display_mode,
                                       cut_coords=cut_coords, dim=dim, alpha=alpha, black_bg=black_bg)
            for roi in self.list_rois[1:]:
                if as_contour:
                    roi.add_contours_to_display(d, alpha=alpha, lw=1.5)
                else:
                    roi.add_overlay_to_display(d, alpha=alpha)
            plt.savefig(out_file)
            plt.close()
            print('ROI plot for dictionary {0} was written here : \n\t{1}'.format(self.atlas_name, out_file))

    def create_montage_plot_of_each_roi(self, montage_file, display_mode='ortho', ncols=None, nrows=None, black_bg=True):
        if not ope(montage_file):
            temp_basenames = [roi.get_name().replace(' ', '_') for roi in self.get_list_rois()]
            temp_files = [opj(opd(montage_file), opb(montage_file[:-4] + '_' + bn) + '.png') for bn in temp_basenames]
            for r, roi in enumerate(self.list_rois):
                if not ope(temp_files[r]):
                    if display_mode in ['x', 'y', 'z']:
                        roi.plot(out_file=temp_files[r], display_mode=display_mode, cut_coords=1, black_bg=black_bg)
                    elif display_mode == 'ortho':
                        roi.plot(out_file=temp_files[r], display_mode=display_mode, black_bg=black_bg)
            if ncols == 0 or nrows == 0:
                m = Montage1D(list_images=temp_files, output_file=montage_file, delete_inputs=True)
                m.vertical_montage()
            else:
                montage_imagemagick(list_images=temp_files, output_file=montage_file, n_rows=nrows, n_cols=ncols, delete_inputs=True)

    def check(self):
        """
        Make sure all elements are ok
        Just make sure all filenames exist and that the roi dictionary is ok to run all subsequent analyses
        :return:
        """
        if not hasattr(self, "atlas_name"):
            sys.exit('Atlas has no name. Edit your Atlas configuration.')
        if not hasattr(self, "list_rois"):
            sys.exit('Atlas has no list of ROIs. Edit your Atlas configuration.')
        for r, roi in enumerate(self.list_rois):
            roi.check()  # Just make sure all files exist

    def add_contours_list_rois_to_display(self, display, alpha=.6, filled=False, lw=2):
        """
        Adds contours of the set of regions of interest to a matplotlib display
        :param display: nilearn display
        :param alpha: float, transparency in [0,1]
        :param filled: bool, fill ROI or not
        """
        for roi in self.get_list_rois_to_plot():
            roi.add_contours_to_display(display, alpha=alpha, filled=filled, lw=lw)

    def add_overlay_list_rois_to_display(self, display, alpha=1):
        for roi in self.get_list_rois_to_plot():
            roi.add_overlay_to_display(display=display, alpha=alpha)
            display.add_overlay(roi.get_file(), cmap=roi.get_binary_colormap(), alpha=alpha)

    def save_to_csv_file(self, out_file):
        """
        Save ROIAtlas to CSV file
        :param out_file:
        :return:
        """
        if not opb(out_file).startswith(PREFIX_ROI_ATLAS_CSV_FILE):
            msg = 'Can not save a ROIAtlas with the provided filename.\n'
            msg += 'Basename must start with "{0}"'.format(PREFIX_ROI_ATLAS_CSV_FILE)
            msg += '\n Your filename was -> ' + out_file
            sys.exit(msg)

        if ope(out_file):
            msg = 'ROIAtlas already exists. Change output filename or edit filename of existing file.\n'
            msg += '  -> ' + out_file
            sys.exit(msg)

        cols = ["ROI name", "ROI file", "ROI color", "plot"]
        l_name, l_file, l_col, l_plot = [], [], [], []
        for r, roi in enumerate(self.list_rois):
            l_file.append(roi.get_file())
            l_name.append(roi.get_name())
            roi_col = roi.get_color()
            if isinstance(roi_col, tuple):
                hex = '#%02x%02x%02x' % (int(roi_col[0] * 255), int(roi_col[1] * 255), int(roi_col[2] * 255))
                l_col.append(hex)
            elif isinstance(roi_col, str):
                l_col.append(roi_col)
            else:
                print('Unknown color type : ', type(roi_col), roi_col)
                sys.exit('Could not save ROIAtlas')
            l_plot = 'TRUE' if roi in self.list_rois_to_plot else 'FALSE'
        # Use data frame to save into a CSV file
        df = pd.DataFrame({"ROI name": l_name, "ROI file": l_file, "ROI color": l_col, "plot": l_plot})
        df.to_csv(path_or_buf=out_file, columns=cols, index=False)
        print('Saved ROIAtlas file with {0} ROIs here : \n\t {1}'.format(len(self.list_rois), out_file))

    def save_as_3d_multi_label_nifti_file(self, out_file):
        """
        Saves the ROIAtlas as a multi label nifti file. One ROI has one label.
        :param out_file:
        :return:
        """
        if not ope(out_file):
            roi_files = [roi.get_file() for roi in self.list_rois]
            img_1 = nibabel.load(roi_files[0])
            data = np.zeros(shape=img_1.get_fdata().shape, dtype=int)
            for r, roi_file in enumerate(roi_files):
                img = nibabel.load(roi_file)
                # Update the multi label ROI file
                data[nilearn.image.get_data(img) > 0] = r + 1
            multi_label_atlas_file = nilearn.image.new_img_like(ref_niimg=img_1, data=data)
            nibabel.save(multi_label_atlas_file, filename=out_file)

    def save_as_4d_nifti_file(self, out_file):
        """
        Saves the ROIAtlas as a 4D nifti file.
        :return:
        """
        if not ope(out_file):
            roi_files = [roi.get_file() for roi in self.list_rois]
            concatenated = nilearn.image.concat_imgs(niimgs=roi_files)
            nibabel.save(concatenated, out_file)


class CSV2Atlas:
    ra: ROIAtlas
    """
    This class reads a csv file and converts it into an acceptable set of regions of interest for other functions
    of this package
    """

    def __init__(self, csv_file):
        """
        Initializes the class with the csv filename that is checked in a first place
        :param csv_file: str, path to the csv file
        """
        self.csv_file = csv_file
        self.__check_csv_file__()  # Make sure file exists and that it is a CSV file
        self.__check_csv_basename__()  # Make sure the basename fits the required pattern
        self.__check_csv_headers__()  # Make sure required columns are here
        self.ra = ROIAtlas()

    def __check_csv_file__(self):
        if not ope(self.csv_file):
            sys.exit('The provided ROIAtlas csv file does not exist\n\t' + self.csv_file)
        if not self.csv_file.endswith('.csv'):
            sys.exit('The provided ROIAtlas file is not a csv file : ' + self.csv_file)

    def __check_csv_basename__(self):
        """
        The CSV filename is expected to respect the following format "ROIAtlas_XXX.csv".
        "XXX" will be the ROI dictionary name used later
        """
        basename = opb(self.csv_file)[:-4]  # Remove '.csv' extension
        if not basename.startswith(PREFIX_ROI_ATLAS_CSV_FILE):
            msg = 'Error when trying to create a ROIS dictionary from a CSV file. The CSV file must be named :\n'
            msg += '\t "{0}XXX.csv"  -> where "XXX" becomes the ROI dictionary name\n'.format(PREFIX_ROI_ATLAS_CSV_FILE)
            msg += '\t "{0}" is not an appropriate filename'.format(opb(self.csv_file))
            sys.exit(msg)
        # Thus, Define ROI dictionary name
        self.atlas_name = basename[len(PREFIX_ROI_ATLAS_CSV_FILE):].replace(' ', '_')

    def __check_csv_headers__(self):
        """
        Just make sure the ROI csv file has mandatory headers ("name" and "file" defined for each ROI)
        :param csv_file: path to the csv filename specifiying the set of regions of interest
        :return: c_roi_name, c_roi_file, c_roi_color: names of the headers for "name", "file" and "color"
        """
        # Now the CSV filename is correct, read it with pandas
        self.df = pd.read_csv(self.csv_file)
        self.df = self.df.replace(np.nan, '', regex=True)
        # Try to find following ROI columns in the csv file
        self.c_name = ''  # A column name is mandatory
        # To define a ROI, a roi file is mandatory
        self.c_roi_file = ''
        self.c_label = ''  # Optional. If provided, it means the corresponding ROI file is a multi-label nifti file
        # To define a sphere, all these columns must appear
        self.c_sphere_x, self.c_sphere_y, self.c_sphere_z, self.c_sphere_r, self.c_sphere_ref = '', '', '', '', ''
        # Optional columns are the following ones (if not given, default values are used). They can be used for spheres
        # and ROI definitions
        self.c_color, self.c_do_plot = '', ''
        for col in self.df.columns:
            if 'name' in col:
                self.c_name = col
            elif 'file' in col:
                self.c_roi_file = col
            elif 'color' in col:
                self.c_color = col
            elif 'plot' in col:
                self.c_do_plot = col
            elif 'label' in col:
                self.c_label = col
            # Now let's deal with spheres definitions
            elif 'center x' in col:
                self.c_sphere_x = col
            elif 'center y' in col:
                self.c_sphere_y = col
            elif 'center z' in col:
                self.c_sphere_z = col
            elif 'radius' in col:
                self.c_sphere_r = col
            elif 'reference' in col:
                self.c_sphere_ref = col
            else:
                # Print message if header is unknown
                print('Column {0} from csv file {1} is ignored. Unrecognized header name'.format(col, self.csv_file))
        # Define sphere Columns
        self.sphere_cols = self.c_sphere_x, self.c_sphere_y, self.c_sphere_z, self.c_sphere_r, self.c_sphere_ref
        # Define booleans for later
        self.rois_defined = bool(self.c_roi_file)  # ROIs exist if the "ROI file" column exists
        self.spheres_defined = all(self.sphere_cols)  # Spheres exist if columns x, y, z and radius exist
        # Stop if columns are not set
        if not self.c_name:
            sys.exit('Your csv file must define a header with "name" inside to define the ROIS names.')
        # if not self.c_roi_file:
        #     sys.exit('Your csv file must define a header with "file" inside to define the paths to the nifti files.')
        # If one sphere column is defined, make sure that all other columns are defined
        if any(self.sphere_cols):
            if not self.spheres_defined:
                sys.exit('At least one sphere column is defined but make sure to define all sphere columns')

    def create_atlas(self):
        """
        Now build the set of regions of interest
        Iterates over the rows judges whether the defined ROI is a sphere or a ROI and calls the appropriate function
        to create the ROI.
        :return:
        """
        # Start by createing a ROIAtlas creator
        self.ra = ROIAtlas(name=self.atlas_name)
        # Count number of rows in the data frame
        name = self.df.shape[0]
        empty_list = [''] * name
        # Mandatory column is to have ROI names
        r_n = self.df[self.c_name]  # ROI names
        # Colors and do plot values
        r_c = self.df[self.c_color] if self.c_color else empty_list.copy()  # ROI colors
        # ROI plot booleans (empty values are set to True (default value))
        r_p = self.df[self.c_do_plot].replace('', True) if self.c_do_plot else [True] * name
        # ROI definitions (ROI FILE mandatory and ROI Label optional)
        r_f = self.df[self.c_roi_file] if self.rois_defined else empty_list.copy()  # ROI files
        r_l = self.df[self.c_label] if self.c_label else empty_list.copy()  # ROI labels (multi label nifti files)
        # Sphere definitions
        s_x = self.df[self.c_sphere_x] if self.spheres_defined else empty_list.copy()  # center x
        s_y = self.df[self.c_sphere_y] if self.spheres_defined else empty_list.copy()  # center y
        s_z = self.df[self.c_sphere_z] if self.spheres_defined else empty_list.copy()  # center z
        s_r = self.df[self.c_sphere_r] if self.spheres_defined else empty_list.copy()  # radius
        s_ref = self.df[self.c_sphere_ref] if self.spheres_defined else empty_list.copy()  # reference file
        i = 0
        for name, f, x, y, z, r, c, ref, p, l in zip(r_n, r_f, s_x, s_y, s_z, s_r, r_c, s_ref, r_p, r_l):
            is_sphere = bool(ref)
            is_roi = bool(f)
            if is_sphere:
                out_dir = create_dir(opj(opd(self.csv_file), PREFIX_ROI_ATLAS_CSV_FILE + self.atlas_name + '_sphere_files'))
                basename = 'sphere_ROI_{0}_x_{1}_y_{2}_z_{3}_r_{4}.nii.gz'.format(i+1, int(x), int(y), int(z), int(r))
                sphere_file = opj(out_dir, basename)
                self.ra.add_sphere_roi(center=[x, y, z], radius=r, roi_name=name, out_file=sphere_file,
                                       ref_file=ref, color=c, exclude_roi_from_atlas_plot=not p)
            elif is_roi:
                self.ra.add_roi(roi_name=name, roi_file=f, color=c, exclude_roi_from_atlas_plot=not p)
            else:
                print('Row : ', (name, f, x, y, z, r, c, p, l))
                sys.exit('Previous Row can not be interpreted either a sphere or a ROI')
            i += 1

    def get_number_of_rois(self):
        """
        :return:
        """
        return self.ra.get_number_of_rois()

    def get_atlas(self):
        """

        :return: Atlas
        """
        self.create_atlas()
        return self.ra

    def create_atlas_plot(self, png_file=None):
        """

        :param png_file:
        :return:
        """
        # Create a ROI plot
        if not png_file:
            png_file = opj(opd(self.csv_file), '{0}{1}_plot.png'.format(PREFIX_ROI_ATLAS_CSV_FILE, self.atlas_name))
        if not ope(png_file):
            self.ra.plot(out_file=png_file)


def concatenate_roi_atlases(list_roi_atlases_csv_files, output_csv_file) -> ROIAtlas:
    """
    Takes multiple CSV ROIAtlases files and merges them into a single ROIAtlas file
    :param list_roi_atlases_csv_files: list of paths to individual ROIAtalses files
    :param output_csv_file: str, path to a new output CSV file (concatenation of input csv files)
    :return: Concatenated ROIAtlas
    """
    if not ope(output_csv_file):
        list_df = []
        for csv_file in list_roi_atlases_csv_files:
            list_df.append(pd.read_csv(csv_file))
        df_concat = pd.concat(list_df)
        df_concat.to_csv(output_csv_file)
    return CSV2Atlas(csv_file=output_csv_file).get_atlas()
