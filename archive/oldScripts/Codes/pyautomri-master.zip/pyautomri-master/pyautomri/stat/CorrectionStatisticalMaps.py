import sys, nibabel, scipy
import warnings
warnings.filterwarnings('ignore', message='The nilearn.glm module is experimental. ')
from os.path import exists as ope, dirname as opd, join as opj
from nilearn.glm import threshold_stats_img
from scipy.io import loadmat


class Correction:
    """
    Class defining a correction for statistical maps. Little functions to print it nicely and get suffix string for
    filenaming purposes.
    """

    def __init__(self, alpha, height_control, k=0):
        """
        Initializes the threshold with values
        :param alpha: float, p<alpha threshold (alpha<=1)
        :param height_control: str, choose among ['fpr', 'fdr', 'bonferroni']
        :param k: int, cluster threshold (default: 0), will keep clusters of size > than k voxels
        """
        self.alpha = alpha
        self.height_control = height_control
        self.k = k
        self.__check__()

    def __check__(self):
        self.__check_alpha__()
        self.__check_corr__()
        self.__check_k__()

    def set_alpha(self, alpha):
        self.alpha = alpha

    def set_height_control(self, height_control):
        self.height_control = height_control

    def set_k(self, k):
        self.k = k

    def __str__(self):
        if self.alpha == 1:
            return 'no threshold'
        else:
            if self.k > 0:
                return 'p<{0}, k>{1} ({2})'.format(self.alpha, self.k, self.height_control)
            else:
                return 'p<{0} ({1})'.format(self.alpha, self.height_control)

    def __check_alpha__(self):
        if self.alpha > 1:
            self.warning('alpha can not be > 1. It is set to 1 instead.')
            self.alpha = 1

    def __check_corr__(self):
        possible_corr = ['fpr', 'fdr', 'bonferroni', 'fwe', 'None', None]
        if not self.height_control in possible_corr:
            self.error('correction type must be one of the following : ' + ', '.join(possible_corr))
        else:
            if self.height_control == 'fwe':
                self.height_control = 'bonferroni'
            if self.height_control == 'None':
                self.height_control = None

    def __check_k__(self):
        if self.k < 0:
            self.warning('k can not be negative. It is set to 0 instead.')
            self.k = 0

    def get_suffix(self):
        if self.alpha == 1:
            return 'unthresholded'
        else:
            if self.k > 0:
                return 'p_{0}_{1}_k_{2}'.format(str(self.alpha).replace('.', '_'), self.height_control, self.k)
            else:
                return 'p_{0}_{1}'.format(str(self.alpha).replace('.', '_'), self.height_control)

    def get_legend(self):
        if self.alpha == 1:
            return 'unthresholded'
        else:
            if self.k > 0:
                return 'p<{0} {1} k>{2}'.format(str(self.alpha), self.height_control, self.k)
            else:
                return 'p<{0} {1}'.format(str(self.alpha), self.height_control)

    def get_k(self):
        return self.k

    def get_alpha(self):
        return self.alpha

    def get_height_control(self):
        return self.height_control

    def warning(self, msg):
        print('Warning with Correction : ' + msg)

    def error(self, msg):
        sys.exit('Error with Correction : ' + msg)

    def compute_threshold(self, stat_map):
        stat_map_type = identify_stat_map_type(stat_map=stat_map)
        if stat_map_type == 'SPM':
            spm_file = opj(opd(stat_map), 'SPM.mat')
            if self.height_control in ['bonferroni', 'fdr']:
                # TODO : in xjview
                # Pz      = spm_P(1,0,   U,df,STAT,1,n,S);% uncorrected p value
                # Pu      = spm_P(1,0,   U,df,STAT,R,n,S);% FWE-corrected {based on Z)
                # function [P,p,Em,En,EN] = spm_P(c,k,Z,df,STAT,R,n,S)
                # % Returns the [un]corrected P value using unifed EC theory
                # % FORMAT [P p Em En EN] = spm_P(c,k,Z,df,STAT,R,n,S)
                # %
                # % c     - cluster number
                # % k     - extent {RESELS}
                # % Z     - height {minimum over n values}
                # % df    - [df{interest} df{error}]
                # % STAT  - Statistical field
                # %       'Z' - Gaussian field
                # %       'T' - T - field
                # %       'X' - Chi squared field
                # %       'F' - F - field
                # %       'P' - Posterior probability
                # % R     - RESEL Count {defining search volume}
                # % n     - number of component SPMs in conjunction
                # % S     - Voxel count
                # %
                # % P     - corrected   P value  - P(n > kmax}
                # % p     - uncorrected P value  - P(n > k}
                # % Em    - expected total number of maxima {m}
                # % En    - expected total number of resels per cluster {n}
                # % EN    - expected total number of voxels {N}
                # %
                # %__________________________________________________________________________
                # %
                # % spm_P determines corrected and uncorrected p values, using the minimum
                # % of different valid methods.
                # %
                # % See the individual methods for details
                # %
                # %     spm_P_RF
                # %     spm_P_Bonf
                # %
                # %__________________________________________________________________________
                # % Copyright (C) 2008 Wellcome Trust Centre for Neuroimaging
                #
                # % Thomas Nichols
                # % $Id: spm_P.m 2690 2009-02-04 21:44:28Z guillaume $
                #
                #
                # % set global var NOBONF to 1 to turn off Bonferroni
                # %--------------------------------------------------------------------------
                # global NOBONF; if ~isempty(NOBONF) && NOBONF, S = []; end
                #
                # if (nargin < 8), S = []; end
                #
                # [P,p,Em,En,EN] = spm_P_RF(c,k,Z,df,STAT,R,n);
                #
                # % Use lower Bonferroni P value (if possible)
                # %==========================================================================
                # if ~isempty(S) && (c == 1 && k == 0) && ~(length(R) == 1 && R == 1)
                #     P = min(P,spm_P_Bonf(Z,df,STAT,S,n));
                # end
                print('/!\ Warning : currently the package does not deal with Bonferroni or FDR thresholds for SPM maps /!\ ')
                print('/!\ The following default threshold will be used instead : ', CORR_2, '/!\ ')
                # Setting default values
                self.set_alpha(alpha=0.001)
                self.set_height_control(height_control='fpr')
            self.threshold = get_t_value_from_p_value(p_value=self.alpha, spm_file=spm_file)
            self.thr_stat_map, _ = threshold_stats_img(stat_img=stat_map, height_control=None, threshold=self.threshold)
        elif stat_map_type == 'nilearn':
            self.thr_stat_map, self.threshold = threshold_stats_img(stat_map, alpha=self.alpha, height_control=self.height_control,
                                                                    cluster_threshold=self.k)
        return self.thr_stat_map, self.threshold

    def get_thresholded_stat_map(self):
        return self.thr_stat_map

    def get_threshold_stat_map(self):
        return self.threshold


CORR_0 = Correction(alpha=1, height_control='fpr')
CORR_1 = Correction(alpha=0.005, height_control='fpr')
CORR_2 = Correction(alpha=0.001, height_control='fpr')
CORR_3 = Correction(alpha=0.05, height_control='fwe')
DEFAULT_CORRECTIONS = [CORR_0, CORR_1, CORR_2, CORR_3]


def get_predefined_threshold(index):
    """
    Get a predefined threshold among the ones created just above.
    Make sure that index is a int or a string otherwise send an error.
    Returns a Threshold class instance.
    :param index:
    :return:
    """
    if isinstance(index, int):
        ok_values = list(range(len(DEFAULT_CORRECTIONS)))
        if index in ok_values:
            correction = DEFAULT_CORRECTIONS[index]
            return correction
        else:
            msg = 'Error when choosing a predefined threshold.\n'
            msg += 'You must choose among the following options :\n'
            for i in ok_values:
                msg += '\t{0}. {1}\n'.format(i, DEFAULT_CORRECTIONS[i])
            sys.exit(msg)
    elif isinstance(index, str):
        return get_predefined_threshold(index=int(index))
    else:
        sys.exit('Unknown type "{0}" for choosing a predefined threshold'.format(type(index)))


def apply_correction_to_list_statistical_maps(statistical_maps, correction):
    """
    For a correction instance, apply the correction to every statistical map in the list of statistical maps.
    :param statistical_maps: list, paths to statistical maps
    :param correction: Correction instance
    :return: the list of thresholded statistical maps, and the list of z thresholds
    """
    thresholded_maps = []
    z_thresholds = []
    for stat_map in statistical_maps:
        thr_map, z_thresh = correction.compute_threshold(stat_map=stat_map)
        thresholded_maps.append(thr_map)
        z_thresholds.append(z_thresh)
    return thresholded_maps, z_thresholds


def get_t_value_from_p_value(p_value, spm_file):
    """

    :param p_value:
    :param spm_file:
    :return:
    """
    if not ope(spm_file):
        msg = 'Error trying to calculate t-value from p-value : SPM.mat file does not exist in the directory ' + opd(
            spm_file)
        sys.exit(msg)
    SPM = loadmat(spm_file)
    # From the SPM file, get the degrees of freedom
    erdf = SPM['SPM'][0, 0]['xX']['erdf'][0, 0][0][0]  # effective residual degrees of freedom
    return scipy.stats.t.isf(p_value, erdf)


def identify_stat_map_type(stat_map):
    if isinstance(stat_map, str):
        associated_spm_file = opj(opd(stat_map), 'SPM.mat')
        if ope(associated_spm_file):
            return 'SPM'
        else:
            return 'nilearn'
    elif isinstance(stat_map, nibabel.Nifti1Image):
        return 'nilearn'
    else:
        msg = 'Unknown type for correcting this statistical map : ' + str(type(stat_map))
        sys.exit(msg)

