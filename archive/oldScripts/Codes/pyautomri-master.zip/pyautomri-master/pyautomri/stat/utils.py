from pyautomri.roi.Operations import get_data_in_roi
from pyautomri.stat.CorrectionStatisticalMaps import Correction
import numpy as np


def count_number_of_voxels_above_threshold_in_roi(stat_map, correction, roi):
    """
    Given a statistical map, a correction strategy and a ROI. Computes number of voxels above threshold inside the ROI
    :param stat_map: str, path to a nifti file
    :param correction: Correction method (threshold is computed)
    :param roi: str, ROI file
    :return:
    """
    _, thr_val = correction.compute_threshold(stat_map)
    X = np.asarray(get_data_in_roi(image_file=stat_map, roi_file=roi))
    return (X > thr_val).sum()


def compute_laterality_index(stat_map, roi_1, roi_2, correction=None):
    """
    Computes a laterality index as (n1-n2)/(n1+n2) where n1 and n2 are number of "activated" voxels.
    Activated voxels are computed as number of voxels above a certain threshold (defined by a correction method)
    :param stat_map: str, statistical map
    :param roi_1: str, roi file
    :param roi_2: str, roi file
    :param correction: Correction instance, correction of the statistical map
    :return: li, float between -1 and 1 representing laterality index (1 is fully on roi1, -1 fully on roi2)
    """
    if correction is None:
        correction = Correction(alpha=0.05, height_control=None, k=0)
    n1 = count_number_of_voxels_above_threshold_in_roi(stat_map=stat_map, correction=correction, roi=roi_1)
    n2 = count_number_of_voxels_above_threshold_in_roi(stat_map=stat_map, correction=correction, roi=roi_2)
    if n1 == 0.0 and n2 == 0.0:
        li = 0
    else:
        li = (n1 - n2) / (n1 + n2)
    return li


def compute_auc_all_thresholds(stat_map, roi):
    """
    Loads data (statistical values) within a ROI. Sorts the statistical values and computes the AUC (area under the
    curve). The curve being y (number of voxels) vs x (thresholds).
    This is achieved by setting every t-value present
    in the ROIs as a threshold and record the number of voxels with value above the threshold.
    :param stat_map: str, statistical map
    :param roi: str, ROI file
    :return:
    """
    x_stat = np.asarray(get_data_in_roi(image_file=stat_map, roi_file=roi))
    # Keep only positive statistics
    x_stat = x_stat[x_stat > 0]
    # Sort the stats
    thresholds = np.sort(x_stat)
    # Count number of voxels above threshold
    counts = np.empty(shape=(len(thresholds)), dtype=int)
    for i, t in enumerate(thresholds):
        counts[i] = np.sum(x_stat > t)
    return np.trapz(y=counts, x=thresholds)


def compute_auc_laterality_index(stat_map, roi_1, roi_2):
    """
    Computation of a laterality index between two symmetric regions from a statistical map.

    Implementation of the method described in "Implementation of clinically relevant and robust fMRI-based language
    lateralization: Choosing the laterality index calculation method" (Brumer et al 2020, PLoS ONE)

    Another way of looking at the difference in activation in left and right ROI is to consider the number of voxels
    with values above the threshold for all possible thresholds [42]. This is achieved by setting every t-value present
    in the ROIs as a threshold and record the number of voxels with value above the threshold.
    The cumulative histograms of the obtained number of voxel vs threshold for left and right ROI, can then be compared.
    The new method we propose in this work calculates the areas under these histograms and
    quantitatively compares them using the following formula:

    AUCLI  = (AUCL - AUCR)/(AUCL + AUCR)

    :param stat_map: str, statistical map
    :param roi_1: str, ROI file
    :param roi_2: str, ROI file
    :return:
    """
    auc_1 = compute_auc_all_thresholds(stat_map=stat_map, roi=roi_1)
    auc_2 = compute_auc_all_thresholds(stat_map=stat_map, roi=roi_2)
    if auc_1 == 0.0 and auc_2 == 0.0:
        auc_li = 0
    else:
        auc_li = (auc_1 - auc_2) / (auc_1 + auc_2)
    return auc_li



def calculate_fernandez_2001_li(stat_map, roi):
    """
    (Fernandez et al 2001) Language mapping in less than 15 minutes: Real-time functional MRI during routine clinical investigation.

    For each subject, we had to adjust the threshold for the identification of activated pixels because of intersubject variability in
    general activation levels. This was achieved by firstly calculating a mean maximum t-value defined as the mean of those 5% of voxels
    showing the highest level of activation in each VOI of both hemispheres. The threshold for inclusion in the calculation of the
    lateralization indices was then set at 50% of this mean maximum t value. Finally, the sum of t-values of voxels with values above
    this threshold entered the formula used to produce weighted lateralization indices .
    """
    x_stat = np.asarray(get_data_in_roi(image_file=stat_map, roi_file=roi))
    # Keep only positive statistics
    x_stat = x_stat[x_stat > 0]
    # Sort the stats
    thresholds = np.sort(x_stat)
    n = int(len(thresholds)*5/100) # Select top 5%
    top_five_percent = thresholds[-n:]
    mean_max_t_value = np.mean(top_five_percent)
    stat_threshold = .5 * mean_max_t_value
    val = np.sum(thresholds[thresholds>stat_threshold])
    return val

def compute_fernandez_2001_laterality_index(stat_map, roi_1, roi_2):
    """
    (Fernandez et al 2001) Language mapping in less than 15 minutes: Real-time functional MRI during routine clinical investigation.
    """
    val1 = calculate_fernandez_2001_li(stat_map=stat_map, roi=roi_1)
    val2 = calculate_fernandez_2001_li(stat_map=stat_map, roi=roi_2)
    if val1 == 0.0 and val2 == 0.0:
        li = 0
    else:
        li = (val1 - val2) / (val1 + val2)
    return li