from os.path import exists as ope, join as opj, basename as opb
import sys, warnings
import nibabel
import nilearn
import pandas as pd
warnings.filterwarnings("ignore", message="The nilearn.glm module is experimental. It may change in any future release of Nilearn.")
from nilearn.glm.second_level.second_level import SecondLevelModel

from pyautomri.stat.Clusters import convert_cluster_data_frame_to_latex_table, NilearnClusterReporter
from pyautomri.utils.utils import create_dirs, remove_nifti_extension
from pyautomri.plot.StatisticalMapping import MosaicActivationMap, ConjunctionPlot


def perform_simple_second_level(contrast_maps, output_stat_filename, design_matrix=None, output_type='z_score'):
    """
    Performs a very simple second level by performing a one sample t-test onto list of contrast maps
    :param contrast_maps:  list of contrast maps
    :param output_stat_filename: output statistical filename, saved as z-score
    :return:
    """
    if not ope(output_stat_filename):
        if not isinstance(design_matrix, pd.DataFrame):
            if not design_matrix or design_matrix.empty:
                design_matrix = pd.DataFrame(data=[1] * len(contrast_maps), columns=['intercept'])
        second_level_model = SecondLevelModel().fit(contrast_maps, design_matrix=design_matrix)
        # Compute statistical map
        stat_map = second_level_model.compute_contrast(second_level_stat_type='t', output_type=output_type)
        nibabel.save(stat_map, filename=output_stat_filename)


class CSV2DataMaps:
    """
    Reads csv file containing contrast maps
    """

    def __init__(self, csv_file):
        """
        Initializes the class with a
        :param csv_file: string, path to the CSV file
        """
        self.csv_file = csv_file
        self.list_input_maps = []
        self.list_subjects = []
        self.__check_csv_file__()
        self.__check_csv_headers__()
        self.__check_csv_content__()

    def __str__(self):
        """
        :return:
        """
        msg = 'List of Inputs maps CSV reader \n'
        msg += '  -CSV file : ' + self.csv_file + '\n'
        msg += '  -{0} input maps \n'.format(len(self.list_input_maps))
        for f, f_map in enumerate(self.list_input_maps):
            msg += '\tMap {0}, subject {1} : {2}\n'.format(f + 1, self.list_subjects[f], f_map)
        return msg

    def __check_csv_file__(self):
        """
        Check whether this is a correct CSV file.
        :return: Meaningful error message to the user
        """
        if not ope(self.csv_file):
            sys.exit('The provided contrast-maps CSV file does not exist\n\t' + self.csv_file)
        if not self.csv_file.endswith('.csv'):
            sys.exit('The provided contrast-maps file is not a CSV file : ' + self.csv_file)

    def __check_csv_headers__(self):
        """
        Looks for a header name containing "file".
        Defines the column attribute c_file
        """
        # Now the CSV filename is correct, read it with pandas
        self.df = pd.read_csv(self.csv_file)
        # Try to find column in the csv file
        self.c_file, self.c_subject = '', ''
        for col in self.df.columns:
            if 'file' in col:
                self.c_file = col
            elif 'subject' in col:
                self.c_subject = col
            elif 'Subject' in col:
                self.c_subject = col
            else:
                print('Column {0} from csv file {1} is ignored because it is an unrecognized header name'.format(col,
                                                                                                                 self.csv_file))  # Check headers are correct
        # Stop if columns are not set
        if not self.c_file:
            sys.exit('Your csv file must define a column header with "file" inside to define the input files.')
        if not self.c_subject:
            sys.exit('Your csv file must define a column header with "subject" inside to define the subject ID.')

    def __check_csv_content__(self):
        """
        Checks whether all input maps exist, and store them into the attribute list_input_maps
        """
        for index, row in self.df.iterrows():
            input_map = row[self.c_file]
            subject = row[self.c_subject]
            if not ope(input_map):
                sys.exit('Map number {0} does not exist : {1}'.format(index + 1, input_map))
            else:
                self.list_input_maps.append(input_map)
            self.list_subjects.append(subject)

    def get_list_input_maps(self):
        """
        :return: list of input maps
        """
        return self.list_input_maps

    def get_list_subjects(self):
        """
        :return: list of subject IDs
        """
        return self.list_subjects


class SecondLevelAnalysis:
    """
    Class to perform a second level analysis.
    This class also implements functions to
        1) Export clusters information
        2) plot statistical maps
        3) TODO : create automatic report
    """

    def __init__(self, contrast_maps, output_dir):
        """

        :param contrast_maps:
        """
        self.contrast_maps = contrast_maps
        self.output_dir = output_dir
        self.__set_defaults__()

    def __str__(self):
        return 'Second Level Analysis with {0} maps. Results stored in {1}'.format(len(self.contrast_maps),
                                                                                   self.output_dir)

    def __set_defaults__(self):
        """

        :return:
        """
        # Todo : pass the param file to a csv file (for further use)
        self.design_matrix = pd.DataFrame(data=[1] * len(self.contrast_maps), columns=['intercept'])
        self.stat_map_filename = opj(self.output_dir, 'default_2nd_level_filename.nii.gz')
        self.param_file = opj(self.output_dir, 'default_2nd_level_param_file.txt')

    def set_design_matrix(self, design_matrix):
        """

        :param design_matrix:
        :return:
        """
        self.design_matrix = design_matrix

    def set_output_statistical_map_basename(self, basename):
        """
        The user defines an output basename
        :param basename:
        :return:
        """
        self.basename = basename
        self.stat_map_filename = opj(self.output_dir, self.basename + '.nii.gz')
        self.param_file = opj(self.output_dir, self.basename + '_params.txt')
        self.basename_clusters_table = self.basename + '_clusters_'

    def get_statistical_map(self):
        return self.stat_map_filename

    def compute_statistical_map(self, output_type='z_score', second_level_contrast=None, msg_to_print='', force=False):
        """

        :param output_type:
        :param force: force recomputing
        :return:
        """
        if not ope(self.stat_map_filename) or not ope(self.param_file) or force:
            if msg_to_print:
                print(msg_to_print)
            second_level_model = SecondLevelModel().fit(self.contrast_maps, design_matrix=self.design_matrix)
            self.nifti_stat_map = second_level_model.compute_contrast(second_level_stat_type='t',
                                                                      second_level_contrast=second_level_contrast,
                                                                      output_type=output_type)
            self.save()

    def save(self):
        """
        Save results of the analysis
        :return:
        """
        self.save_statistical_map()
        self.save_parameter_file()

    def save_statistical_map(self):
        """
        Saves the statistical map into a nifti file
        :return:
        """
        nibabel.save(self.nifti_stat_map, filename=self.stat_map_filename)

    def save_parameter_file(self):
        """
        Saves the parameter file into a text file
        :return:
        """
        f = open(self.param_file, 'w')
        txt = 'Contrast maps :\n'
        txt += '\n'.join(self.contrast_maps)
        txt += '\n\nDesign Matrix:'
        txt += '\n' + str(self.design_matrix)
        f.write(txt)
        f.close()

    def __init_cluster_reports__(self):
        self.ncr = NilearnClusterReporter(stat_map=self.stat_map_filename)
        self.clusters_dir = create_dirs(opj(self.output_dir, 'clusters'))

    def get_clusters_table_csv_filename(self, correction):
        self.__init_cluster_reports__()
        basename = self.basename_clusters_table + correction.get_suffix() + '.csv'
        return opj(self.clusters_dir, basename)

    def get_clusters_dataframe(self, correction):
        csv_file = self.get_clusters_table_csv_filename(correction=correction)
        if not ope(csv_file):
            df, thresh = self.ncr.compute_clusters_table(correction=correction, add_anatomical_labels=True)
        else:
            df = pd.read_csv(csv_file)
        return df

    def get_clusters_table_latex(self, correction):
        df = self.get_clusters_dataframe(correction)
        return convert_cluster_data_frame_to_latex_table(df)

    def export_clusters_tables(self, correction):
        """

        :param correction:
        :return:
        """
        self.__init_cluster_reports__()
        csv_file = self.get_clusters_table_csv_filename(correction=correction)
        if not ope(csv_file):
            df = self.get_clusters_dataframe(correction=correction)
            df.to_csv(csv_file)

    def plot_clusters(self, correction, fig_suffix):
        df = self.get_clusters_dataframe(correction=correction)
        cluster_plot_dir = create_dirs(opj(self.clusters_dir, 'cluster_plots', correction.get_suffix()))
        self.ncr.plot_clusters(df=df, out_dir=cluster_plot_dir, fig_suffix=fig_suffix, alpha=correction)

    def __init_plot_stat_map__(self):
        self.stat_map_plot_dir = create_dirs(opj(self.output_dir, 'stat_map_plots'))

    def plot_stat_map(self, correction, title='', mosaic_parameters=None, atlas=None):
        """
        Make a mosaic plot
        :param correction:
        :param title:
        :param mosaic_parameters: The user can specify specific cut coordinates for the MosaicPlot
        :param atlas: ROIAtlas: provide a ROIAtlas if ROIS must be plotted on top of the statistical map (as contours)
        :return:
        """
        self.__init_plot_stat_map__()
        basename = '_'.join([self.basename, correction.get_suffix()]) + '.png'
        out_file = opj(self.stat_map_plot_dir, basename)
        if not ope(out_file):
            thr_stat_map, z_thresh = correction.compute_threshold(stat_map=self.stat_map_filename)
            mam = MosaicActivationMap(stat_map=thr_stat_map, out_file=out_file, mosaic_parameters=mosaic_parameters)
            mam.set_threshold(threshold=z_thresh)
            mam.set_title(title=title)
            if atlas:
                mam.set_atlas(atlas=atlas)
                mam.set_alpha(1)
            mam.plot()
        return out_file


class ConjunctionMap:
    def __init__(self, stat_map_1, stat_map_2):
        self.stat_map_1 = stat_map_1
        self.stat_map_2 = stat_map_2
        self.img_1 = nibabel.load(self.stat_map_1)
        self.img_2 = nibabel.load(self.stat_map_2)
        self.label_1 = remove_nifti_extension(opb(self.stat_map_1))
        self.label_2 = remove_nifti_extension(opb(self.stat_map_2))
        self.correction = None
        self.threshold = None
        self.threshold_1 = None
        self.threshold_2 = None
        self.mask_1 = None
        self.mask_2 = None
        self.conjunction_map = None

    def set_label_1(self, label_1):
        self.label_1 = label_1

    def set_label_2(self, label_2):
        self.label_2 = label_2

    def set_correction(self, correction):
        self.correction = correction

    def set_threshold_1(self, threshold_1):
        self.threshold_1 = threshold_1

    def set_threshold_2(self, threshold_2):
        self.threshold_2 = threshold_2

    def set_threshold(self, threshold):
        self.threshold = threshold

    def compute_mask_1(self):
        thr = 0
        if self.correction or self.threshold or self.threshold_1:
            if self.correction:
                (self.img_1, thr) = self.correction.compute_threshold(self.stat_map_1)
            if self.threshold_1:
                thr = self.threshold_1
            if self.threshold:
                thr = self.threshold
        else:
            sys.exit('Conjunction map can not be calculated. You must either define a correction, a threshold or two.')
        self.mask_1 = 1 * (nilearn.image.get_data(self.img_1) > thr)

    def compute_mask_2(self):
        thr = 0
        if self.correction:
            (self.img_2, thr) = self.correction.compute_threshold(self.stat_map_2)
        if self.threshold_2:
            thr = self.threshold_2
        if self.threshold:
            thr = self.threshold
        self.mask_2 = 2 * (nilearn.image.get_data(self.img_2) > thr)

    def compute_conjunction_map(self):
        self.compute_mask_1()
        self.compute_mask_2()
        self.conjunction_map = nilearn.image.new_img_like(ref_niimg=self.img_1, data=self.mask_1 + self.mask_2)
        return self.conjunction_map

    def save(self, out_file):
        nibabel.save(img=self.conjunction_map, filename=out_file)

    def plot(self, out_file, black_bg=True):
        self.compute_conjunction_map()
        cp = ConjunctionPlot(conjunction_map=self.conjunction_map, output_file=out_file)
        cp.set_colorbar_labels(colorbar_labels=[self.label_1, self.label_2, "Both"])
        if black_bg:
            cp.set_black_background()
        cp.plot()
        cp.save()
