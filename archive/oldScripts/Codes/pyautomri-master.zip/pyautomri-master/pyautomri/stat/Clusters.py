import math, warnings
import nibabel
import numpy as np
import seaborn as sns
import sys
warnings.filterwarnings("ignore", message="Fetchers from the nilearn.datasets module will be updated in version 0.9 to return python strings instead of bytes and Pandas dataframes instead of Numpy arrays.")
warnings.filterwarnings("ignore", message="The nilearn.glm module is experimental. It may change in any future release of Nilearn.")
from os.path import join as opj, exists as ope
from nilearn.regions import connected_regions
from nilearn.glm.thresholding import threshold_stats_img
from nilearn.image.resampling import resample_to_img
import nibabel as nib
from nilearn.reporting import get_clusters_table
from pyautomri.utils.anat_from_mni import find_structure
from pyautomri.utils.utils import create_dir
from pyautomri.roi.Atlas import ROIAtlas, CSV2Atlas
from nilearn.plotting import plot_prob_atlas
import matplotlib.pyplot as plt


class ClustersAnalyzer:
    """
    Takes a statistical map and provides tools to further analyze the clusters
    """
    def __init__(self, stat_map):
        """
        Initializes the class with a statistical map.
        Default clusters extraction parameters are set.
        :param stat_map: path to the statistical map filename.
        """
        self.stat_map = stat_map
        self.k = 20
        self.alpha = 0.001
        self.corr_type = 'fpr'
        self.min_region_size = 1500  # mm3, default option for the connected_regions method
        self.threshold = None
        self.voxel_value_as_cluster_number = False
        self.n_clusters = None
        self.thr_img = None  # thresholded statistical map
        self.cluster_masks_filenames = []  # list containing paths to the exported cluster masks

    def set_correction_parameters(self, k, alpha, corr_type):
        self.set_cluster_threshold(k=k)
        self.set_alpha(alpha=alpha)
        self.set_corr_type(corr_type=corr_type)

    def set_cluster_threshold(self, k):
        self.k = k

    def set_alpha(self, alpha):
        self.alpha = alpha

    def set_corr_type(self, corr_type):
        self.corr_type = corr_type

    def set_min_region_size(self, min_region_size):
        self.min_region_size = min_region_size

    def set_threshold(self, threshold):
        self.threshold = threshold

    def set_voxel_value_as_cluster_number(self):
        self.voxel_value_as_cluster_number = True

    def threshold_image(self):
        # print(self.alpha, self.threshold, self.corr_type, self.k)
        if self.threshold:
            self.thr_img, thresh = threshold_stats_img(self.stat_map, threshold=self.threshold, height_control=None, cluster_threshold=self.k)
        else:
            self.thr_img, thresh = threshold_stats_img(self.stat_map, threshold=3.29)
            #self.thr_img, thresh = threshold_stats_img(self.stat_map, alpha=self.alpha, height_control=self.corr_type, cluster_threshold=self.k)
        print('Threshold is', thresh, 'when exporting clusters')
        ## TESTING
        
        #nilearn.plotting.plot_stat_map(self.thr_img, cut_coords=[45,-61,40])
        # plt.show()
        # sys.exit()

    def extract_connected_regions(self):
        self.threshold_image()
        # TODO : comprendre pourquoi ca plante quand pas de clusters + ?
        # TODO : ou trouver une solution pour contourner ca
        #self.regions_value_img, index = connected_regions(self.thr_img, min_region_size=self.min_region_size, extract_type='local_regions', smoothing_fwhm=None)
        self.regions_value_img, index = connected_regions(self.thr_img, min_region_size=self.min_region_size)
        # CC1 = [30,40,50]
        # plot_prob_atlas(self.regions_value_img, bg_img=self.thr_img, view_type="contours", display_mode="z", cut_coords=CC1, title='')
        # plt.show()
        # sys.exit()

    def save_individual_clusters_as_individual_masks(self, export_dir, basename='cluster_mask', target_img=None):
        """
        Saves the list of individual clusters as individual nifti masks within the same export_dir
        :param export_dir: path to the directory where masks will be saved
        :param basename: string, basename for the individual masks
        :param target_img: path or nii object, reference Image if resampling is required
        :return:
        """
        create_dir(export_dir)
        list_clusters = self.get_list_individual_clusters_as_nifti_objects()
        for i, nii_img in enumerate(list_clusters):
            save_file = opj(export_dir, basename + '_{0}.nii.gz'.format(str(i + 1).zfill(2)))
            if not ope(save_file):
                if target_img:
                    res_img = resample_to_img(nii_img, target_img, interpolation='nearest', copy=True, order='F', clip=False, fill_value=0, force_resample=False)
                    nib.save(res_img, save_file)
                else:
                    nib.save(nii_img, save_file)
            self.cluster_masks_filenames.append(save_file)
        return self.cluster_masks_filenames

    def get_list_individual_clusters_as_nifti_objects(self):
        """

        :return:
        """
        self.extract_connected_regions()
        clusters = self.regions_value_img.get_data()
        self.n_clusters = clusters.shape[3]
        print(f'Found {self.n_clusters} clusters for (a={self.alpha}, k>{self.k}, {self.corr_type}, min region size {self.min_region_size}) for {self.stat_map}')
        list_nifti_masks = []
        for i in range(self.n_clusters):
            # Extract from X the i-st volume
            Y = clusters[..., i]
            # Convert to mask : all values are then set to either 1 or cluster number
            if self.voxel_value_as_cluster_number:
                Y[Y != 0] = i + 1
            else:
                Y[Y != 0] = 1
            # Create a nifti image and save it
            nii_img = nib.Nifti1Image(Y, affine=self.regions_value_img.affine, header=self.regions_value_img.header)
            list_nifti_masks.append(nii_img)
        return list_nifti_masks

    def export_clusters_as_roi_atlas(self, roi_atlas_name, csv_filename, cluster_basename='Cluster', seed_col=None):
        """
        Export the calculated clusters as
        :param roi_atlas_name: ROIAtlas name
        :param csv_filename: output CSV filnename
        :param cluster_basename: basename for each cluster (Cluster_01, Cluster_02, etc...), you may specify the effect name
        :param seed_col:
        :return:
        """
        if len(self.cluster_masks_filenames) > 0:
            if ope(csv_filename):
                ra = CSV2Atlas(csv_file=csv_filename).get_atlas()
            else:
                ra = ROIAtlas(name=roi_atlas_name)
                for c, cluster_file in enumerate(self.cluster_masks_filenames):
                    roi_name = cluster_basename + '_{}'.format(str(c+1).zfill(2))
                    ra.add_roi(roi_name=roi_name, roi_file=cluster_file)
                if seed_col:
                    pal = sns.dark_palette(color=seed_col, n_colors=self.n_clusters, reverse=True, as_cmap=False)
                    ra.set_palette(pal)
                ra.save_to_csv_file(out_file=csv_filename)
            return ra
        else:
            sys.exit('You must first save individual clusters as individual masks before creating a ROIAtlas.')


def add_anatomical_labels_to_clusters_table(df):
    """
    Add 6 columns for 6 atlas and sets the label names to each peak and subpeak into the pandas data frame
    :param df:
    :return:
    """
    atlas_names = ['hemisphere', 'lobe', 'label_extended_modified', 'type', 'brodmann', 'aal_MNI_V4']
    n_peaks = df.shape[0]
    label_names = np.empty((n_peaks, len(atlas_names)), dtype=object)
    for i, row in df.iterrows():
        one_line, table = find_structure([row['X'], row['Y'], row['Z']])
        for a, label_name in enumerate(table[0]):
            label_names[i, a] = label_name.replace('undefined', '?')

    # Sets the label names to the pandas data frame (reverse order = AAL first)
    for a, atlas_name in enumerate(atlas_names[::-1]):
        df[atlas_name] = list(label_names[:, len(atlas_names) - a - 1])  # Inverting order (aal_MNI_V4 first)
    return df


def plot_clusters_views_from_data_frame(df, stat_map, out_dir, fig_suffix, correction):
    """
    Create a little figure per cluster, centered on the peak
    :param df: provide the data frame
    :param stat_map: corresponding statistical map
    :param out_dir: str, path to the output directory where the list of figures will be saved
    :param fig_suffix: non-changing end of filename
    :param correction: correction method
    :return: number of clusters
    """
    from pyautomri.plot.StatisticalMapping import ActivationPlot
    n = 0
    n_clusters = df.shape[0]
    # Get the thresholded statistical map
    # TO DO
    thresh_stat_map, threshold = correction.compute_threshold(stat_map=stat_map)
    # Get Voxel Volume
    nii_img = nibabel.load(stat_map)
    header_info = nii_img.header
    voxel_volume = header_info['pixdim'][1] * header_info['pixdim'][2] * header_info['pixdim'][3]
    for c in range(n_clusters):
        # Retrieve cluster information
        x, y, z = df['X'][c], df['Y'][c], df['Z'][c]
        cl_id, cl_size, aal = df['Cluster ID'][c], float(df['Cluster Size (mm3)'][c]), df['aal_MNI_V4'][c]
        n_voxels_in_cluster = cl_size / voxel_volume
        # Keep only clusters that have more voxels than the alpha threshold cluster size
        if n_voxels_in_cluster > correction.get_k() or math.isnan(cl_size):
            out_file = opj(out_dir, '_'.join(['cluster', str(c + 1).zfill(3), str(cl_id), fig_suffix]) + '.png')
            if not ope(out_file):
                ap = ActivationPlot(stat_map=thresh_stat_map, output_file=out_file)
                ap.set_display_mode(dm='ortho')
                ap.set_threshold(threshold)
                ap.set_cut_coords(cut_coords=[x, y, z])
                ap.set_title('{0}. {1} '.format(cl_id, aal))
                ap.plot()
                ap.add_markers(coords=[[x, y, z]], marker_color='r', marker_size=50)
                ap.save()
                n += 1
    return n


def convert_cluster_data_frame_to_latex_table(df, longtable=True):
    n_clusters = df.shape[0]
    t_sep = ' & '
    if longtable:
        tablename = 'longtable'
        endline = r' \tabularnewline'
    else:
        tablename = 'tabular'
        endline = r' \\'
    # Latex table
    latex_table = r'\begin{' + tablename + '}{| l | c c c | c | c | l |}' + '\n'
    latex_table += '\hline \n'
    headers = ['ID', 'x', 'y', 'z', 'Z', 'Volume (mm$^3$)', 'AAL']
    latex_table += t_sep.join([r'\textbf{' + h + '}' for h in headers]) + endline + '\n'
    latex_table += '\hline \n'
    for c in range(n_clusters):
        # Retrieve cluster information
        x, y, z = df['X'][c], df['Y'][c], df['Z'][c]
        cl_id = df['Cluster ID'][c]
        cl_size = df['Cluster Size (mm3)'][c]
        aal = df['aal_MNI_V4'][c]
        if cl_size:
            if np.isnan(cl_size):
                cl_size = ''
            else:
                cl_size = int(cl_size)
        else:
            cl_size = ''
        peak_stat = df['Peak Stat'][c]
        aal = aal.replace(' (aal)', '').replace('_', ' ')
        # Update Latex table
        line = [cl_id, int(x), int(y), int(z), round(peak_stat, 2), cl_size, aal.replace(' (aal)', '')]
        latex_table += t_sep.join([str(e) for e in line]) + endline + '\n'
    latex_table += '\hline \n'
    latex_table += '\end{' + tablename + '}\n\n'
    return latex_table


class NilearnClusterReporter:
    """
    This class takes a statistical map and provides functions to explore the results.
        - threshold statistical map
        - exports clusters table associated to the thresholding option
        - exports clusters views
    """

    def __init__(self, stat_map):
        """

        :param stat_map: path to the NIFTI statistical map
        """
        self.stat_map = stat_map

    def __str__(self):
        return 'NilearnClusterReporter for map : ' + self.stat_map

    def load_nifti_map(self):
        """
        Loads the nifti map, and keeps
        :return:
        """
        # Load the nifti image for the get_clusters_table function
        self.nii_img = nibabel.load(self.stat_map)
        header_info = self.nii_img.header
        self.voxel_volume = header_info['pixdim'][1] * header_info['pixdim'][2] * header_info['pixdim'][3]

    def compute_clusters_table(self, correction, add_anatomical_labels=True):
        """

        :param correction: Correction instance
        :param add_anatomical_labels:
        :return:
        """
        self.load_nifti_map()
        # Compute the threshold
        stat_map, thresh = correction.compute_threshold(stat_map=self.stat_map)
        # Get the clusters table and save it
        self.df = get_clusters_table(stat_img=self.nii_img, stat_threshold=thresh)
        if add_anatomical_labels:
            self.df = add_anatomical_labels_to_clusters_table(self.df)
        return self.df, thresh

    def plot_clusters(self, df, out_dir, fig_suffix, alpha):
        """
        Create a little figure per cluster, centered on the peak
        :param df: provide the data frame
        :param out_dir: str, path to the output directory where the list of figures will be saved
        :param fig_suffix: non-changing end of filename
        :param alpha: correction method
        :return: number of clusters
        """
        n = plot_clusters_views_from_data_frame(df, stat_map=self.stat_map, out_dir=out_dir, fig_suffix=fig_suffix,
                                                correction=alpha)
        return n