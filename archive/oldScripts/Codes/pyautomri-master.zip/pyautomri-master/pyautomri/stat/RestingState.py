import sys
from os.path import basename as opb
from nilearn.decomposition import CanICA, DictLearning
from nilearn.maskers import NiftiMasker, NiftiSpheresMasker
from nilearn.signal import clean

# todo : provide utilities to perform Canonical ICA on functional files
# todo : class to perform correlation analysis (seed/ROI-to-voxel maps)


class SeedToVoxelMapping:
    """
    Perform correlation analysis within a seed-based approach
    """
    def __init__(self, rs_fn_file):
        """

        :param rs_fn_file:
        """
        self.rs_fn_file = rs_fn_file
        self.seed = None
        self.is_roi, self.is_seed = False, False
        self.seed_name = None
        self.radius = None
        # Default Masker parameters
        self.masker = None
        self.detrend = True
        self.standardize = True
        self.low_pass = 0.1
        self.high_pass = 0.01
        self.tr = None

    def set_detrend(self, detrend):
        self.detrend = detrend

    def set_standardize(self, standardize):
        self.standardize = standardize

    def set_low_pass(self, low_pass):
        self.low_pass = low_pass

    def set_high_pass(self, high_pass):
        self.high_pass = high_pass

    def set_tr(self, tr):
        self.tr = tr

    def set_roi_seed(self, roi_file, seed_name=None):
        if not isinstance(roi_file, str):
            sys.exit('Setting a ROI seed is ')
        self.seed = roi_file
        self.is_roi, self.is_seed = True, False
        if seed_name is None:
            self.seed_name = opb(roi_file)
        else:
            self.seed_name = seed_name

    def set_spherical_seed(self, mni_coords, radius=6, seed_name=None):
        self.seed = mni_coords
        self.is_roi, self.is_seed = False, True
        self.radius = radius
        if seed_name is None:
            self.seed_name = 'seed_x_{0}_y_{1}_z_{2}'.format(self.seed[0], self.seed[1], self.seed[2])
        else:
            self.seed_name = seed_name

    def extract_time_series(self):
        if self.is_roi:
            self.masker = NiftiMasker(mask_img=self.seed, detrend=self.detrend, standardize=self.standardize,
                                      low_pass=self.low_pass, high_pass=self.high_pass, t_r=self.tr, verbose=0)
        elif self.is_seed:
            self.masker = NiftiSpheresMasker([self.seed], radius=self.radius, detrend=self.detrend,
                                             standardize=self.standardize, low_pass=self.low_pass,
                                             high_pass=self.high_pass, t_r=self.tr, verbose=0)
        else:
            sys.exit('You must define either a seed ROI or a spherical seed')