# pyautomri
`pyautomri` is a python project providing tools for processing 1st level fMRI results and reporting/plotting group level analyses.

It is mainly (but not exclusively) designed to match automri (MATLAB package) BOLD projects.

## Binaries are divided into two types
### pyautomri_*.py tools 
These tools allow to further process 1st level results of an automri project.
They depend on a configuration file (`pyautomri_config.json`) that the user must fill to give a minimum indications to the software regarding the project name, groups, subjects...

#### Configuring my project
The configuration file must be stored ___at the root of your `automri` project___.

A template configuration file is provided in `resources` folder. See below the content of this template file.
```json
{
    "study":
    {
        "name":"MySuperProject",
        "design_name": "d02"
    },
    "groups":
    [
      {
        "name": "healthy_controls",
        "subjects": ["HC_01","HC_02","HC_03","HC_04"],
        "user_design_file":"relative_path_to/user_design_d02.m"
      },
      {
        "name": "patients",
        "subjects": ["P_01","P_02","P_03","P_04"],
        "user_design_file":"relative_path_to/user_design_d02.m"
      }
    ],
    "Analysis":
    {
      "ROI": "relative_path_to/ROIAtlas_Amygdala.csv"
    },
    "StatisticalMappingDisplayOptions":
    {
      "z": [45, 48, 52, 55, 59, 62, 66, 70]
    }
}

```

#### Testing whether my configuration file is ok
Write your `pyautomri_config.json` and run `pyautomri_get_study_info.py`. A good configuration will result in a message summarizing your project properties in the terminal.

#### List of pyautomri tools
- `pyautomri_generate_pdf_report.py` Generate a Latex pdf report of your `pyautomri` analyses
- `pyautomri_get_study_info.py` simple tool that checks whether the configuration is ok.
- `pyautomri_list_contrasts.py` lists the contrasts that are configures in the project (relative to the provided user design file)
- `pyautomri_list_subjects.py` lists the subjects that are currently involved in the project (edit configuration file to add new subject)
- `pyautomri_montage_individual_statistical_maps.py` allows to create a montage of individual statistical map figures  
- `pyautomri_perform_roi_analysis.py` Perform a ROI analysis (the user must define a `ROIS_XXX.csv` file, see the `resources/ROIS_Template.csv`)
- `pyautomri_perform_second_level_analysis.py` Performs a group level analysis for each group defined in the configuration file
- `pyautomri_plot_all_group_statistical_maps.py` Plots all group statistical maps
- `pyautomri_plot_all_individual_statistical_maps.py` Plots all individual statistical maps
- `pyautomri_plot_individual_statistical_map.py`  Plots a specific individual statistical map given a subject, and a contrast
- `pyautomri_report_clusters_tables_to_csv_files.py` Saves the list of clusters of all your group statistical maps into a csv file 

### Other tools
These scripts/functions can be used with any other data
- `compute_laterality_index.py` computes LI index on statistical map given two symmetric ROIs
- `create_atlas.py` allows to create a ROIAtlas csv file by manually selecting a list of ROIs
- `flip_nifti_volume.py` Flips a nifti volume along the given axis
- `mrimage_info.py` prints information concerning a Nitfi file (image affine, shape, resolution)  
- `perform_roi_analysis.py` Perform a ROI analysis given a ROI csv file, and a contrast maps csv file.
- `perform_simple_single_group_analysis.py` Perform a single group analysis given a list of contrast maps defined in a csv file
- `plot_atlas.py`  Creates a simple ortho plot (3 views) to show the ROIs defined in the csv file
- `plot_roi.py`  Creates a simple plot for a ROI file  
- `plot_stat_map.py`  Plots a statistical map (many options)
- `print_clusters_table.py` Prints the lists of clusters in the terminal given a statistical map, and a thresholding option


# To do list
- [ ] `plot_anat.py`
- [X] Glass Brain
- [X] LongitudinalAutofmriStudyAnalyzer (for HEMISFER for example) (try a branch)
- [ ] Regions of interest (ROIs)
  - [ ] Deal with multiple values masks for creating ROIAtlas (label column)
  - [ ] Add a "center on ROI"/"center on atlas" option to the `plot_stat_map.py` utility
  - [ ] Add the possibility of using multiple ROIAtlas files to the StudyAnalyzer
- [ ] Analyses  
    - [ ] Implement between groups analysis
    - [ ] Implement an automated/interactive way to pre-fill the configuration file by "guessing" data from the automri folder contents
    - [ ] Retrieve threshold value when thresholding p<0.05 (FWE) from spm maps and SPM.mat
- [ ] Statistical Maps
    - [ ] Use the new 'mosaic' display mode available in nilearn 0.7.1
- [ ] Other
    - [ ] Understand the way the package is installed
- [ ] Configuration file
    - [X] Add a display section with z slices, mosaic params...
    - 