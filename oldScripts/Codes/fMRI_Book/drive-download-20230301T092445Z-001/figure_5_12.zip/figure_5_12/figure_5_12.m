%illustrate orthogonalization

%cd to the directory with this code, since a file from that directory will
%be read in below.
cd /Users/jeanettemumford/Documents/Research/Writing/Book/book/img/StatisticalModelingFIrstLevel/CorrRegressorEx

%add the path to SPM, since spm_hrf is used below
addpath /Users/jeanettemumford/Documents/Research/matlabcode/


t=0:1:100;

hrf=spm_hrf(1);

stim=zeros(size(t));
stim(1:15:end)=1;

stim_conv=conv(stim, hrf);
stim_conv=stim_conv(1:length(t))';


resp=zeros(size(t));
resp(3:15:end)=1;
resp_conv=conv(resp, hrf);
resp_conv=resp_conv(1:length(t))';


N=length(t);

%dat=.25*stim_conv+.25*resp_conv+normrnd(0,.05,N,1);
%load in data that were used in figure (or you can use the commented out
%code above to randomly generate some new data).
dat=load('dat.txt', '-ascii');



subplot(1,1,1)
plot(dat)

s_orth_r=stim_conv-resp_conv*pinv(resp_conv)*stim_conv;
r_orth_s=resp_conv-stim_conv*pinv(stim_conv)*resp_conv;


fs=20;
fst=24;
fsl=18;

%plots
subplot(4,1,1)
plot(t, dat, 'b-', 'linewidth', 2)
xlabel('Time (s)', 'fontsize', 12, 'fontsize', fs)
axis([0 100 -.2 .25])
title('Data', 'fontsize', fst)

subplot(4,1,2)
plot(t, stim_conv, 'g-', 'linewidth', 2)
hold on
plot(t, resp_conv, 'r-', 'linewidth', 2)
hold off
axis([0 100 -0.15, .6])
xlabel('Time(s)', 'fontsize', fs)
leg=legend('Stim', 'Resp')
set(leg, 'fontsize', fsl)


subplot(4,1,3)
plot(t, s_orth_r, 'g-.', 'linewidth', 3)
hold on
plot(t, resp_conv, 'r-', 'linewidth', 2)
hold off
axis([0 100 -0.15, .6])
xlabel('Time(s)', 'fontsize', fs)
leg=legend('Stim \perp Resp', 'Resp')
set(leg, 'fontsize', fsl)



subplot(4,1,4)
plot(t, stim_conv, 'g-', 'linewidth', 2)
hold on
plot(t, r_orth_s, 'r-.', 'linewidth', 3)
hold off
axis([0 100 -0.15, .6])
xlabel('Time(s)', 'fontsize', fs)
leg=legend('Stim ', 'Resp \perp Stim')
set(leg, 'fontsize', fsl)


% Calculate t statistics

%original
X=[stim_conv, resp_conv];
dimX=size(X);
df=dimX(1)-dimX(2);

res=dat-X*inv(X'*X)*X'*dat;
resvar=sum(res.^2)/df;

T=inv(X'*X)*X'*dat./(diag(inv(X'*X))*resvar).^.5

%s_orth_r
X=[s_orth_r, resp_conv];
dimX=size(X);
df=dimX(1)-dimX(2);

res=dat-X*inv(X'*X)*X'*dat;
resvar=sum(res.^2)/df;

T=inv(X'*X)*X'*dat./(diag(inv(X'*X))*resvar).^.5


%r_orth_s
X=[stim_conv, r_orth_s];
dimX=size(X);
df=dimX(1)-dimX(2);

res=dat-X*inv(X'*X)*X'*dat;
resvar=sum(res.^2)/df;

T=inv(X'*X)*X'*dat./(diag(inv(X'*X))*resvar).^.5










